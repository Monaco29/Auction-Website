<!DOCTYPE html>
<html lang="en">
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: admin_login.php');
    exit();
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        /* Theme Modes */
        body.light-mode {
            background-color: #ffffff;
            color: #212529;
        }

        body.dark-mode {
            background-color: #121212;
            color: #e4e6eb;
        }

        .light-mode .card {
            background-color: #ffffff;
            color: #000;
        }

        .dark-mode .card {
            background-color: #1f1f1f;
            color: #e4e6eb;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #343a40 !important;
            color: white;
            padding-top: 20px;
        }

        .sidebar a {
            color: white;
            display: flex;
            align-items: center;
            padding: 10px 15px;
            margin-bottom: 8px;
            border-radius: 8px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .sidebar a:hover {
            background-color: #17a2b8;
            transform: translateY(-2px) scale(1.02);
            color: #ffffff;
        }

        .sidebar .active {
            background-color: #007bff;
            color: #ffffff;
        }

        .sidebar a i {
            margin-right: 10px;
        }

        /* Main Content */
        .content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .content {
                margin-left: 0;
            }
        }

        /* Cards */
        .card {
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card-body {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 20px;
        }

        .users-card {
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            /* Indigo to lavender blue */
            color: white;
        }

        .categories-card a.btn {
            background-color: rgba(255, 255, 255, 0.2);
            color: #fff;
            border: 2px solid #ffffff;
        }

        .categories-card a.btn:hover {
            background-color: #ffffff;
            color: #00b09b;
        }

        .items-card {
            background: linear-gradient(135deg, #00c9ff, #92fe9d);
            /* Aqua to mint green */
            color: white;
        }

        .auctions-card {
            background: linear-gradient(135deg, #f7971e, #ffd200);
            /* Orange to yellow (was in bids) */
            color: white;
        }

        .bids-card {
            background: linear-gradient(135deg, #ff6a00, #ee0979);
            /* Sunset orange to pink */
            color: white;
        }

        /* Equal Height Cards */
        .row.equal {
            display: flex;
            flex-wrap: wrap;
        }

        .row.equal>[class*='col-'] {
            display: flex;
            flex-direction: column;
            padding: 10px;
        }

        /* Theme Toggle Switch */
        .mode-toggle {
            margin: 10px auto;
            display: block;
        }

        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 25px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            border-radius: 25px;
            cursor: pointer;
            transition: 0.4s;
        }

        .slider:before {
            content: "";
            position: absolute;
            height: 18px;
            width: 18px;
            left: 4px;
            bottom: 3.5px;
            background-color: white;
            border-radius: 50%;
            transition: 0.4s;
        }

        input:checked+.slider {
            background-color: #2196F3;
        }

        input:checked+.slider:before {
            transform: translateX(24px);
        }

        /* Base button style for all cards */
        .card a.btn {
            border-radius: 25px;
            font-weight: bold;
            transition: all 0.3s ease;
            padding: 8px 20px;
        }

        /* Users card button (Indigo to lavender blue) */
        .users-card a.btn {
            background-color: rgba(255, 255, 255, 0.2);
            color: #fff;
            border: 2px solid #ffffff;
        }

        .users-card a.btn:hover {
            background-color: #ffffff;
            color: #4e54c8;
        }

        /* Items card button (Aqua to mint green) */
        .items-card a.btn {
            background-color: rgba(255, 255, 255, 0.2);
            color: #fff;
            border: 2px solid #ffffff;
        }

        .items-card a.btn:hover {
            background-color: #ffffff;
            color: #00c9ff;
        }

        /* Auctions card button (Orange to yellow) */
        .auctions-card a.btn {
            background-color: rgba(255, 255, 255, 0.2);
            color: #fff;
            border: 2px solid #ffffff;
        }

        .auctions-card a.btn:hover {
            background-color: #ffffff;
            color: #f7971e;
        }

        /* Bids card button (Sunset orange to pink) */
        .bids-card a.btn {
            background-color: rgba(255, 255, 255, 0.2);
            color: #fff;
            border: 2px solid #ffffff;
        }

        .bids-card a.btn:hover {
            background-color: #ffffff;
            color: #ee0979;
        }
    </style>

</head>

<body id="page-body">

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-3 col-lg-2 sidebar">
                <h3 class="text-center text-white mb-3">Admin Dashboard</h3>


                <a href="#" class="active"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
                <a href="users/manage_user.php"><i class="fas fa-users"></i>Manage Users</a>
                <a href="items/manage_items.php"><i class="fas fa-box-open icon"></i>Manage Items</a>
                <a href="category/manage_category.php"><i class="fas fa-tags"></i>Manage Categories</a>

                <a href="users/verify_sellers.php"><i class="fas fa-user-check"></i>Verify Seller</a>
                <a href="auction/manage_auction.php"><i class="fas fa-gavel"></i>Manage Auctions</a>
                <a href="menu_dashboard.php"><i class="fas fa-chart-bar"></i>Reports</a>
                <a href="admin_logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
                <div class="text-center text-white mt-5">
                    <label class="switch">
                        <input type="checkbox" id="mode-switch">
                        <span class="slider round"></span>
                    </label>
                    <p class="mt-2" id="mode-label">Light Mode</p>
                </div>
            </nav>

            <main class="col-md-9 col-lg-10 content">
                <h1>Welcome, Admin!</h1>
                <p>Here you can manage all aspects of the auction system.</p>
                <div class="row equal">
                    <div class="col-md-3">
                        <div class="card users-card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-users"></i> Users</h5>
                                <p class="card-text">Manage user accounts and roles.</p>
                                <a href="users/manage_user.php" class="btn btn-light mt-auto">Go to Users</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card categories-card"
                            style="background: linear-gradient(135deg, #00b09b, #96c93d); color: white;">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-tags"></i> Categories</h5>
                                <p class="card-text">Manage item categories.</p>
                                <a href="category/manage_category.php" class="btn btn-light mt-auto">Go to
                                    Categories</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card items-card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-box-open"></i> Items</h5>
                                <p class="card-text">Manage items listed for auction.</p>
                                <a href="items/manage_items.php" class="btn btn-light mt-auto">Go to Items</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card auctions-card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-gavel"></i> Auctions</h5>
                                <p class="card-text">Manage ongoing and upcoming auctions.</p>
                                <a href="auction/manage_auction.php" class="btn btn-light mt-auto">Go to Auctions</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bids-card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-user-check"></i> Seller</h5>
                                <p class="card-text">Manage bids placed on items.</p>
                                <a href="users/verify_sellers.php" class="btn btn-light mt-auto">Go to Bids</a>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        const body = document.getElementById('page-body');
        const switchInput = document.getElementById('mode-switch');
        const modeLabel = document.getElementById('mode-label');

        // Load saved theme
        const savedTheme = localStorage.getItem('theme') || 'light';
        body.classList.add(`${savedTheme}-mode`);
        if (savedTheme === 'dark') {
            switchInput.checked = true;
            modeLabel.textContent = "Dark Mode";
        } else {
            modeLabel.textContent = "Light Mode";
        }

        // Handle switch toggle
        switchInput.addEventListener('change', () => {
            if (switchInput.checked) {
                body.classList.replace('light-mode', 'dark-mode');
                localStorage.setItem('theme', 'dark');
                modeLabel.textContent = "Dark Mode";
            } else {
                body.classList.replace('dark-mode', 'light-mode');
                localStorage.setItem('theme', 'light');
                modeLabel.textContent = "Light Mode";
            }
        });
    </script>

</body>

</html>