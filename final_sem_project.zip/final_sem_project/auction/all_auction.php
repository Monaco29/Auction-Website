<?php
require_once("../bridge.php");

// Fetch auctions from DB
$sql = "SELECT a.*,i.picture FROM auction a
        JOIN item i ON i.item_id = a.item_id";
$result = mysqli_query($connect, $sql);

$ongoing = $upcoming = $closed = $paid = [];

while ($row = mysqli_fetch_assoc($result)) {
    if ($row['status'] == 'Ongoing') {
        $ongoing[] = $row;
    } elseif ($row['status'] == 'Upcoming') {
        $upcoming[] = $row;
    } elseif ($row['status'] == 'Closed') {
        // Get winner info
        $auction_id = $row['auction_id'];
        $winner_query = "SELECT b.buyer_id, u.username, MAX(b.bid_amount) as winning_amount
                         FROM bid b
                         JOIN buyer be ON b.buyer_id = be.buyer_id
                         JOIN user u ON u.user_id = be.user_id
                         WHERE b.auction_id = $auction_id
                         GROUP BY b.buyer_id
                         ORDER BY winning_amount DESC
                         LIMIT 1";
        $winner_result = mysqli_query($connect, $winner_query);
        $winner_data = mysqli_fetch_assoc($winner_result);
        $row['winner_id'] = $winner_data['buyer_id'] ?? 'N/A';
        $row['winner_name'] = $winner_data['username'] ?? 'No bids';
        $row['winning_amount'] = $winner_data['winning_amount'] ?? '0';
        $closed[] = $row;
    } elseif ($row['status'] == 'Paid') {
        $paid[] = $row;
    }
}
?>
<style>
    /* Main Container */
    .auction-container {
        background: #f8f9fa;
        border-radius: 16px;
        padding: 30px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
    }

    /* Header Section */
    .auction-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        padding-bottom: 15px;
        border-bottom: 1px solid #e0e0e0;
    }

    .auction-header h2 {
        font-weight: 700;
        color: #2c3e50;
        font-size: 1.8rem;
        margin: 0;
    }

    .add-auction-btn {
        background: linear-gradient(135deg, #00c9ff 0%, #92fe9d 100%);
        border: none;
        padding: 10px 20px;
        border-radius: 50px;
        font-weight: 600;
        box-shadow: 0 4px 15px rgba(0, 201, 255, 0.3);
        transition: all 0.3s ease;
    }

    .add-auction-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0, 201, 255, 0.4);
    }

    /* Section Headers */
    .section-header {
        font-weight: 600;
        font-size: 1.4rem;
        margin: 30px 0 20px;
        padding-left: 15px;
        border-left: 5px solid;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .ongoing-header {
        color: #3498db;
        border-color: #3498db;
    }

    .upcoming-header {
        color: #f39c12;
        border-color: #f39c12;
    }

    .closed-header {
        color: #e74c3c;
        border-color: #e74c3c;
    }

    .paid-header {
        color: #2ecc71;
        border-color: #2ecc71;
    }

    /* Auction Cards */
    .auction-card {
        border: none;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        margin-bottom: 25px;
        height: 100%;
    }

    .auction-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
    }

    .card-body {
        padding: 20px;
    }

    .status-badge {
        font-size: 0.75rem;
        padding: 5px 10px;
        border-radius: 20px;
        font-weight: 700;
        letter-spacing: 0.5px;
        margin-bottom: 15px;
        display: inline-block;
    }

    .ongoing-badge {
        background: rgba(52, 152, 219, 0.1);
        color: #3498db;
    }

    .upcoming-badge {
        background: rgba(243, 156, 18, 0.1);
        color: #f39c12;
    }

    .closed-badge {
        background: rgba(231, 76, 60, 0.1);
        color: #e74c3c;
    }

    .paid-badge {
        background: rgba(46, 204, 113, 0.1);
        color: #2ecc71;
    }

    .card-title {
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 15px;
        font-size: 1.2rem;
    }

    .card-text {
        color: #7f8c8d;
        font-size: 0.9rem;
        margin-bottom: 8px;
    }

    .winner-info {
        background: #f8f9fa;
        padding: 12px;
        border-radius: 8px;
        margin: 15px 0;
    }

    .winner-info p {
        margin-bottom: 5px;
        font-size: 0.85rem;
    }

    .winner-label {
        font-weight: 600;
        color: #2c3e50;
    }

    .edit-btn {
        border-radius: 8px;
        padding: 6px 15px;
        font-size: 0.85rem;
        font-weight: 500;
        border-width: 2px;
        transition: all 0.3s ease;
    }

    .ongoing-btn {
        border-color: #3498db;
        color: #3498db;
    }

    .upcoming-btn {
        border-color: #f39c12;
        color: #f39c12;
    }

    .closed-btn {
        border-color: #e74c3c;
        color: #e74c3c;
    }

    .paid-btn {
        border-color: #2ecc71;
        color: #2ecc71;
    }

    .edit-btn:hover {
        color: white;
    }

    .ongoing-btn:hover {
        background: #3498db;
    }

    .upcoming-btn:hover {
        background: #f39c12;
    }

    .closed-btn:hover {
        background: #e74c3c;
    }

    .paid-btn:hover {
        background: #2ecc71;
    }

    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 40px 20px;
        background: #f8f9fa;
        border-radius: 12px;
        margin: 30px 0;
    }

    .empty-state i {
        font-size: 3rem;
        color: #bdc3c7;
        margin-bottom: 20px;
    }

    .empty-state p {
        color: #7f8c8d;
        font-size: 1.1rem;
    }
</style>

<div class="container mt-4 auction-container">
    <div class="auction-header">
        <h2>🛒 Auction Management</h2>
        <a href="insert_auction.php" class="btn btn-primary add-auction-btn">
            <i class="fas fa-plus"></i> Create New Auction
        </a>
    </div>

    <!-- Ongoing Auctions -->
    <h4 class="section-header ongoing-header">
        <i class="fas fa-check-circle"></i> Active Auctions
    </h4>
    <?php if (!empty($ongoing)): ?>
        <div class="row">
            <?php foreach ($ongoing as $auction): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card auction-card">
                        <div class="card-body">
                            <span class="status-badge ongoing-badge">LIVE NOW</span>
                            <h5 class="card-title"><?= htmlspecialchars($auction['title']) ?></h5>
                            <!-- Display item image in your item listing page -->
                            <img src="../uploaded_images/<?= htmlspecialchars($auction['picture']) ?>"
                                alt="<?= htmlspecialchars($auction['title']) ?>"
                                style="max-width: 300px;">
                            <p class="card-text">
                                <i class="far fa-clock text-primary"></i> Ends: <?= date('M j, Y g:i A', strtotime($auction['auction_end'])) ?>
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <a href="view_bids.php?id=<?= $auction['auction_id'] ?>" class="text-primary small">
                                    View Bids <i class="fas fa-arrow-right"></i>
                                </a>
                                <a href="edit_auction.php?id=<?= $auction['auction_id'] ?>" class="btn btn-outline-primary edit-btn ongoing-btn">
                                    <i class="fas fa-edit"></i> Manage
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-calendar-times"></i>
            <p>No active auctions currently running</p>
        </div>
    <?php endif; ?>

    <!-- Upcoming Auctions -->
    <h4 class="section-header upcoming-header">
        <i class="fas fa-clock"></i> Scheduled Auctions
    </h4>
    <?php if (!empty($upcoming)): ?>
        <div class="row">
            <?php foreach ($upcoming as $auction): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card auction-card">
                        <div class="card-body">
                            <span class="status-badge upcoming-badge">COMING SOON</span>
                            <h5 class="card-title"><?= htmlspecialchars($auction['title']) ?></h5>
                            <img src="../uploaded_images/<?= htmlspecialchars($auction['picture']) ?>"
                                alt="<?= htmlspecialchars($auction['title']) ?>"
                                style="max-width: 300px;">
                            <p class="card-text">
                                <i class="far fa-calendar-alt text-warning"></i> Starts: <?= date('M j, Y g:i A', strtotime($auction['auction_start'])) ?>
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="badge bg-light text-dark small">
                                    <?= date_diff(new DateTime(), new DateTime($auction['auction_start']))->format('%a days %h hrs') ?> left
                                </span>
                                <a href="edit_auction.php?id=<?= $auction['auction_id'] ?>" class="btn btn-outline-warning edit-btn upcoming-btn">
                                    <i class="fas fa-edit"></i> Prepare
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-calendar-plus"></i>
            <p>No upcoming auctions scheduled</p>
        </div>
    <?php endif; ?>

    <!-- Closed Auctions -->
    <h4 class="section-header closed-header">
        <i class="fas fa-times-circle"></i> Completed Auctions
    </h4>
    <?php if (!empty($closed)): ?>
        <div class="row">
            <?php foreach ($closed as $auction): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card auction-card">
                        <div class="card-body">
                            <span class="status-badge closed-badge">COMPLETED</span>
                            <h5 class="card-title"><?= htmlspecialchars($auction['title']) ?></h5>
                            <img src="../uploaded_images/<?= htmlspecialchars($auction['picture']) ?>"
                                alt="<?= htmlspecialchars($auction['title']) ?>"
                                style="max-width: 300px;">
                            <div class="winner-info">
                                <p><span class="winner-label">Winner:</span> <?= htmlspecialchars($auction['winner_name']) ?></p>
                                <p><span class="winner-label">Winning Bid:</span> ₹<?= number_format($auction['winning_amount'], 2) ?></p>
                                <p><span class="winner-label">Ended:</span> <?= date('M j, Y', strtotime($auction['auction_end'])) ?></p>
                            </div>
                            <div class="d-flex justify-content-between">
                                <a href="view_bids.php?id=<?= $auction['auction_id'] ?>" class="text-danger small">
                                    View Results <i class="fas fa-arrow-right"></i>
                                </a>
                                <a href="edit_auction.php?id=<?= $auction['auction_id'] ?>" class="btn btn-outline-danger edit-btn closed-btn">
                                    <i class="fas fa-file-invoice"></i> Invoice
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-calendar-check"></i>
            <p>No completed auctions yet</p>
        </div>
    <?php endif; ?>

    <!-- Paid Auctions -->
    <h4 class="section-header paid-header">
        <i class="fas fa-check-double"></i> Paid Auctions
    </h4>
    <?php if (!empty($paid)): ?>
        <div class="row">
            <?php foreach ($paid as $auction): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="card auction-card">
                        <div class="card-body">
                            <span class="status-badge paid-badge">PAID</span>
                            <h5 class="card-title"><?= htmlspecialchars($auction['title']) ?></h5>
                            <img src="../uploaded_images/<?= htmlspecialchars($auction['picture']) ?>"
                                alt="<?= htmlspecialchars($auction['title']) ?>"
                                style="max-width: 300px;">
                            <div class="winner-info">
                                <p><span class="winner-label">Payment Date:</span> <?= date('M j, Y', strtotime($auction['payment_date'] ?? 'now')) ?></p>
                                <p><span class="winner-label">Amount:</span> ₹<?= number_format($auction['winning_amount'] ?? 0, 2) ?></p>
                            </div>
                            <div class="d-flex justify-content-between">
                                <a href="payment_details.php?id=<?= $auction['auction_id'] ?>" class="text-success small">
                                    Payment Details <i class="fas fa-arrow-right"></i>
                                </a>
                                <a href="edit_auction.php?id=<?= $auction['auction_id'] ?>" class="btn btn-outline-success edit-btn paid-btn">
                                    <i class="fas fa-receipt"></i> Receipt
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-wallet"></i>
            <p>No paid auctions to display</p>
        </div>
    <?php endif; ?>
</div>