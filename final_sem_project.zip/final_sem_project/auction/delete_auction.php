<?php
require_once("../bridge.php");

if (isset($_GET['id'])) {
    $auction_id = $_GET['id'];

    $sql = "DELETE FROM auction WHERE auction_id = '$auction_id'";
    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('auction deleted successfully.')</script>";
        header("Location: manage_auction.php");
        exit();
    } else {
        echo "<script>alert('Error: " . mysqli_error($connect) . ")</script>";
        header("Location: manage_auction.php");
        exit();
    }
} else {
    echo "Invalid request.";
}
