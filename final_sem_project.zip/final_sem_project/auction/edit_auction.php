<?php
require_once("../bridge.php");

// Fetch auction details
if (isset($_GET['id'])) {
    $auction_id = intval($_GET['id']);
    $auctionQuery = mysqli_query($connect, "SELECT * FROM auction WHERE auction_id = $auction_id");
    $auction = mysqli_fetch_assoc($auctionQuery);

    if (!$auction) {
        echo "<script>alert('Auction not found.'); window.location.href='manage_auction.php';</script>";
        exit;
    }

    // Dropdown data
    $items = mysqli_query($connect, "SELECT item_id, name FROM item");
    $categories = mysqli_query($connect, "SELECT category_id, name FROM category");
    $sellers = mysqli_query($connect, "SELECT seller_id, business_name FROM seller");
} else {
    echo "<script>alert('Invalid Request'); window.location.href='manage_auction.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Auction</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #8e44ad, #3498db);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #fff;
            padding: 30px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        h1 {
            font-weight: bold;
            color: #fff;
        }

        label {
            color: #eee;
        }

        .form-control {
            border-radius: 10px;
        }

        .btn-success {
            background: #2ecc71;
            border: none;
        }
    </style>
</head>

<body>

    <h1>Edit Auction</h1>
    <div class="card mt-4">
        <form method="POST" action="update_auction.php">
            <input type="hidden" name="auction_id" value="<?= $auction['auction_id'] ?>">

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label>Item</label>
                    <select name="item_id" class="form-control" required>
                        <?php while ($item = mysqli_fetch_assoc($items)) {
                            $selected = $item['item_id'] == $auction['item_id'] ? "selected" : "";
                            echo "<option value='{$item['item_id']}' $selected>{$item['item_id']} - {$item['name']}</option>";
                        } ?>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label>Category</label>
                    <select name="category_id" class="form-control" required>
                        <?php while ($cat = mysqli_fetch_assoc($categories)) {
                            $selected = $cat['category_id'] == $auction['category_id'] ? "selected" : "";
                            echo "<option value='{$cat['category_id']}' $selected>{$cat['category_id']} - {$cat['name']}</option>";
                        } ?>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label>Seller</label>
                    <select name="seller_id" class="form-control" required>
                        <?php while ($seller = mysqli_fetch_assoc($sellers)) {
                            $selected = $seller['seller_id'] == $auction['seller_id'] ? "selected" : "";
                            echo "<option value='{$seller['seller_id']}' $selected>{$seller['seller_id']} - {$seller['business_name']}</option>";
                        } ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Auction Title</label>
                <input type="text" name="title" class="form-control" value="<?= $auction['title'] ?>" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" rows="3" class="form-control" required><?= $auction['description'] ?></textarea>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>Auction Start</label>
                    <input type="datetime-local" name="auction_start" class="form-control" value="<?= date('Y-m-d\TH:i', strtotime($auction['auction_start'])) ?>" required>
                </div>
                <div class="form-group col-md-6">
                    <label>Auction End</label>
                    <input type="datetime-local" name="auction_end" class="form-control" value="<?= date('Y-m-d\TH:i', strtotime($auction['auction_end'])) ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control">
                    <?php
                    $statuses = ['Upcoming', 'OnGoing', 'Closed', 'Paid'];
                    foreach ($statuses as $status) {
                        $selected = $status == $auction['status'] ? "selected" : "";
                        echo "<option value='$status' $selected>$status</option>";
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-success">💾 Update Auction</button>
            <a href="manage_auction.php" class="btn btn-light">Cancel</a>
        </form>
    </div>
</body>

</html>