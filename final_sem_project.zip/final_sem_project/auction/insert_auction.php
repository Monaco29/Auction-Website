<?php
require_once("../bridge.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item_id = mysqli_real_escape_string($connect, $_POST['item_id']);
    $category_id = mysqli_real_escape_string($connect, $_POST['category_id']);
    $seller_id = mysqli_real_escape_string($connect, $_POST['seller_id']);
    $title = mysqli_real_escape_string($connect, $_POST['title']);
    $description = mysqli_real_escape_string($connect, $_POST['description']);
    $auction_start = mysqli_real_escape_string($connect, $_POST['auction_start']);
    $auction_end = mysqli_real_escape_string($connect, $_POST['auction_end']);
    $status = mysqli_real_escape_string($connect, $_POST['status']);
    $registration_required = mysqli_real_escape_string($connect, $_POST['registration_required']);

    $sql = "INSERT INTO auction (
                item_id, category_id, seller_id, title, description, auction_start, auction_end, status, registration_required
            ) VALUES ($item_id, $category_id, $seller_id, '$title', '$description', '$auction_start', '$auction_end', '$status')";

    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('Auction inserted successfully.'); window.location.href='manage_auction.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($connect) . "'); window.location.href='manage_auction.php';</script>";
    }
}
?>

<?php
require_once("../bridge.php");

$itemQuery = mysqli_query($connect, "SELECT item_id, name FROM item");
$categoryQuery = mysqli_query($connect, "SELECT category_id, name FROM category");
$sellerQuery = mysqli_query($connect, "SELECT seller_id, business_name FROM seller");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Auctions</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #283c86, #45a247);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #fff;
            padding: 30px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        h1 {
            font-weight: bold;
            color: #fff;
        }

        label {
            color: #eee;
        }

        .form-control {
            border-radius: 10px;
        }


        .btn-primary {
            background: #3498db;
            border: none;
        }
    </style>
</head>

<body>

    <h1 class="mb-4">➕ Add Auctions</h1>

    <!-- Add Auction -->
    <div class="card">
        <h4>Add New Auction</h4>
        <form method="POST" action="insert_auction.php">
            <div class="form-row">
                <div class="form-group col-md-4">
                    <label>Item</label>
                    <select name="item_id" class="form-control" required>
                        <option value="" disabled selected>-- Select Item --</option>
                        <?php while ($item = mysqli_fetch_assoc($itemQuery)) {
                            echo "<option value='{$item['item_id']}'>{$item['item_id']} - {$item['name']}</option>";
                        } ?>
                    </select>
                </div>

                <div class="form-group col-md-4">
                    <label>Category</label>
                    <select name="category_id" class="form-control" required>
                        <option value="" disabled selected>-- Select Category --</option>
                        <?php while ($cat = mysqli_fetch_assoc($categoryQuery)) {
                            echo "<option value='{$cat['category_id']}'>{$cat['category_id']} - {$cat['name']}</option>";
                        } ?>
                    </select>
                </div>

                <div class="form-group col-md-4">
                    <label>Seller</label>
                    <select name="seller_id" class="form-control" required>
                        <option value="" disabled selected>-- Select Seller --</option>
                        <?php while ($seller = mysqli_fetch_assoc($sellerQuery)) {
                            echo "<option value='{$seller['seller_id']}'>{$seller['seller_id']} - {$seller['business_name']}</option>";
                        } ?>
                    </select>
                </div>

            </div>
            <div class="form-group">
                <label>Auction Title</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" rows="3" class="form-control" required></textarea>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label>Auction Start</label>
                    <input type="datetime-local" name="auction_start" class="form-control" required>
                </div>
                <div class="form-group col-md-6">
                    <label>Auction End</label>
                    <input type="datetime-local" name="auction_end" class="form-control" required>
                </div>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="Upcoming">Upcoming</option>
                    <option value="OnGoing">OnGoing</option>
                    <option value="Closed">Closed</option>
                    <option value="Paid">Paid</option>
                </select>
            </div>
            <div class="form-group">
                <label>Require Registration?</label>
                <select name="registration_required" class="form-control">
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">➕ Add Auction</button>
        </form>
    </div>

</body>

</html>