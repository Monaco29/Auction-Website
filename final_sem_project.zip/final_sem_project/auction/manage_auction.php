<?php
require_once("../bridge.php");

$itemQuery = mysqli_query($connect, "SELECT item_id, name FROM item");
$categoryQuery = mysqli_query($connect, "SELECT category_id, name FROM category");
$sellerQuery = mysqli_query($connect, "SELECT seller_id, business_name FROM seller");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Auctions</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #283c86, #45a247);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #fff;
            padding: 30px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        h1 {
            font-weight: bold;
            color: #fff;
        }

        label {
            color: #eee;
        }

        .form-control {
            border-radius: 10px;
        }

        table {
            background-color: rgba(0, 0, 0, 0.2);
            color: white;
        }

        thead th {
            background-color: #1abc9c;
        }

        .btn-primary {
            background: #3498db;
            border: none;
        }

        .btn-danger {
            background: #e74c3c;
            border: none;
        }

        .btn-warning {
            background: #f39c12;
            border: none;
            color: white;
        }
    </style>
</head>

<body>

    <h1 class="mb-4">📋 Manage Auctions</h1>
    <a href='insert_auction.php' class='btn btn btn-primary'>➕ Add Auction</a>
    <!-- Auction List -->
    <div class="card">
        <h4>📝 Existing Auctions</h4>
        <div class="table-responsive">
            <table class="table table-bordered table-hover text-white">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Item ID</th>
                        <th>Title</th>
                        <th>Status</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = mysqli_query($connect, "SELECT * FROM auction");
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>{$row['auction_id']}</td>";
                        echo "<td>{$row['item_id']}</td>";
                        echo "<td>{$row['title']}</td>";
                        echo "<td>{$row['status']}</td>";
                        echo "<td>{$row['auction_start']}</td>";
                        echo "<td>{$row['auction_end']}</td>";
                        echo "<td>
                            <a href='edit_auction.php?id={$row['auction_id']}' class='btn btn-warning btn-sm'>Edit</a>
                            <a href='delete_auction.php?id={$row['auction_id']}' class='btn btn-danger btn-sm'>Delete</a>
                        </td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</body>

</html>