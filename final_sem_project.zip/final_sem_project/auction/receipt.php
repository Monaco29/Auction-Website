<?php
// Fetch receipt data
$stmt = $pdo->prepare("
    SELECT r.*, i.*, t.*, item.name AS item_name 
    FROM receipt r
    JOIN invoice i ON r.invoice_id = i.invoice_id
    JOIN transections t ON i.transaction_id = t.transection_id
    JOIN auction a ON t.bid_id = a.auction_id
    JOIN item ON a.item_id = item.item_id
    WHERE r.receipt_id = ?
");
$stmt->execute([$_GET['id']]);
$receipt = $stmt->fetch();
?>

<div class="receipt">
    <h2>Payment Receipt #<?= $receipt['receipt_id'] ?></h2>
    <div class="item-info">
        <p>Item: <?= htmlspecialchars($receipt['item_name']) ?></p>
        <p>Amount Paid: $<?= number_format($receipt['amount'], 2) ?></p>
        <p>Payment Date: <?= date('M j, Y H:i', strtotime($receipt['payment_date'])) ?></p>
    </div>
    <!-- Add download button -->
    <a href="generate_pdf.php?receipt_id=<?= $receipt['receipt_id'] ?>"
        class="btn btn-primary">
        Download PDF
    </a>
</div>