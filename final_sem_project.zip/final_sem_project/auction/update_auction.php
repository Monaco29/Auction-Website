<?php
require_once("../bridge.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $auction_id = intval($_POST['auction_id']);
    $item_id = mysqli_real_escape_string($connect, $_POST['item_id']);
    $category_id = mysqli_real_escape_string($connect, $_POST['category_id']);
    $seller_id = mysqli_real_escape_string($connect, $_POST['seller_id']);
    $title = mysqli_real_escape_string($connect, $_POST['title']);
    $description = mysqli_real_escape_string($connect, $_POST['description']);
    $auction_start = mysqli_real_escape_string($connect, $_POST['auction_start']);
    $auction_end = mysqli_real_escape_string($connect, $_POST['auction_end']);
    $status = mysqli_real_escape_string($connect, $_POST['status']);

    $sql = "UPDATE auction SET
                item_id = $item_id,
                category_id = $category_id,
                seller_id = $seller_id,
                title = '$title',
                description = '$description',
                auction_start = '$auction_start',
                auction_end = '$auction_end',
                status = '$status' 
            WHERE auction_id = $auction_id";

    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('Auction updated successfully.'); window.location.href='manage_auction.php';</script>";
    } else {
        echo "<script>alert('Update failed: " . mysqli_error($connect) . "'); window.location.href='manage_auction.php';</script>";
    }
}
