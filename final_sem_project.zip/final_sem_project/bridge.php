<?php
$connect = mysqli_connect("Localhost:3307", "root", "", "project_auction");
if (!$connect) {
    echo mysqli_connect_errno();
}
