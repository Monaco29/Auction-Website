<?php
require_once("../bridge.php");

// Check if category ID is passed via GET
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $category_id = $_GET['id'];

    // Prepare DELETE query
    $sql = "DELETE FROM category WHERE category_id = $category_id";

    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('Category deleted successfully.'); window.location.href='manage_category.php';</script>";
    } else {
        echo "<script>alert('Error deleting category: " . mysqli_error($connect) . "'); window.location.href='manage_category.php';</script>";
    }
} else {
    echo "<script>alert('Invalid category ID.'); window.location.href='manage_category.php';</script>";
}

mysqli_close($connect);
