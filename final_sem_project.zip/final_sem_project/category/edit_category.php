<?php
require_once("../bridge.php");

// Fetch data when opening the page for editing
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $category_id = $_GET['id'];
    $result = mysqli_query($connect, "SELECT * FROM category WHERE category_id = '$category_id'");
    $category = mysqli_fetch_assoc($result);
}

// Update the category
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id = $_POST['category_id'];
    $name = mysqli_real_escape_string($connect, $_POST['name']);
    $description = mysqli_real_escape_string($connect, $_POST['description']);

    $sql = "UPDATE category SET name = '$name', description = '$description' WHERE category_id = '$category_id'";
    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('Category updated successfully.'); window.location.href='manage_category.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($connect) . "'); window.location.href='manage_category.php';</script>";
    }
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Category</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #2c3e50, #4ca1af);
            color: #fff;
            padding: 30px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            padding: 30px;
        }

        h2 {
            font-weight: 600;
            color: #ffffff;
            text-shadow: 1px 1px 3px #000;
            margin-bottom: 30px;
        }

        .form-control {
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: white;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 5px #00c3ff;
        }

        .btn-primary {
            background: linear-gradient(90deg, #6a11cb, #2575fc);
            border: none;
            padding: 10px 20px;
            border-radius: 12px;
            font-weight: 600;
        }

        .btn-primary:hover {
            background: linear-gradient(90deg, #2575fc, #6a11cb);
        }

        .btn-warning {
            float: right;
        }
    </style>
</head>

<body>
    <div class="container">
        <a href="manage_category.php" class="btn btn-warning">⬅ Back</a>
        <h2>✏️ Edit Category</h2>
        <div class="card">
            <form action="edit_category.php" method="POST">
                <input type="hidden" name="category_id" value="<?php echo $category['category_id']; ?>">

                <div class="form-group">
                    <label for="name">Category Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $category['name']; ?>" required>
                </div>

                <div class="form-group">
                    <label for="description">Category Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" required><?php echo $category['description']; ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">💾 Update Category</button>
            </form>
        </div>
    </div>
</body>

</html>