<?php
require_once("../bridge.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($connect, $_POST['name']);
    $description = mysqli_real_escape_string($connect, $_POST['description']);

    // Insert query
    $query = "INSERT INTO category (name, description) VALUES ('$name', '$description')";

    if (mysqli_query($connect, $query)) {
        // Redirect back to manage_category with success message
        header("Location: manage_category.php?msg=success");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($connect);
    }
}
