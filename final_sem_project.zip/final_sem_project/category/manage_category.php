<?php
require_once("../bridge.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Categories</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
    <style>
        /* Global Base Styles */
        *,
        *::before,
        *::after {
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #2c3e50, #4ca1af);
            color: #fff;
            padding: 30px;
            margin: 0;
        }

        h1 {
            font-weight: bold;
            margin-bottom: 20px;
            text-shadow: 1px 1px 3px #000;
        }

        label {
            color: #ffffff;
        }

        /* Card Styling */
        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 20px;
            margin-bottom: 30px;
            overflow: hidden;
        }

        .card-body {
            padding: 20px;
        }

        /* Form Controls & Buttons */
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: white;
            border-radius: 10px;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 5px #00c3ff;
        }

        .btn-primary {
            background: linear-gradient(90deg, #6a11cb, #2575fc);
            border: none;
        }

        .btn-warning {
            background-color: #f39c12;
        }

        .btn-danger {
            background-color: #e74c3c;
        }

        /* Table Styling */
        table {
            background-color: rgba(0, 0, 0, 0.3);
            color: white;
            margin-bottom: 0;
        }

        thead th {
            background: linear-gradient(to right, #00c3ff, #8e2de2);
            color: white;
        }

        tbody td {
            color: white;
        }

        /* Responsive Media Queries */
        @media (max-width: 992px) {
            body {
                padding: 20px;
            }

            h1 {
                font-size: 1.8rem;
            }

            .card-body {
                padding: 15px;
            }

            .form-control {
                font-size: 0.95rem;
            }
        }

        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            h1 {
                font-size: 1.6rem;
            }

            .card-body {
                padding: 10px;
            }

            .btn {
                padding: 8px 12px;
                margin-top: 5px;
                font-size: 0.9rem;
            }

            .form-control {
                font-size: 0.9rem;
            }

            table {
                font-size: 0.85rem;
            }
        }

        @media (max-width: 576px) {
            body {
                padding: 10px;
            }

            h1 {
                font-size: 1.4rem;
            }

            .card-body {
                padding: 10px;
            }

            .btn {
                padding: 6px 10px;
                font-size: 0.8rem;
            }

            .form-control {
                font-size: 0.8rem;
            }

            table {
                font-size: 0.75rem;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1>📁 Manage Categories</h1>
            </div>
        </div>

        <!-- Add Category Card -->
        <div class="row mb-3">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-white mb-3">➕ Add New Category</h5>
                        <form action="insert_category.php" method="POST">
                            <div class="form-group">
                                <label>Category Name</label>
                                <input type="text" class="form-control" name="name" required>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control" name="description" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Add Category</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Category List Card -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="text-white mb-3">📋 Category List</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Created At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $sql = "SELECT * FROM category";
                                    $res = mysqli_query($connect, $sql);
                                    while ($row = mysqli_fetch_assoc($res)) {
                                        echo "<tr>";
                                        echo "<td>{$row['name']}</td>";
                                        echo "<td>{$row['description']}</td>";
                                        echo "<td>{$row['created_at']}</td>";
                                        echo "<td>
                            <a href='edit_category.php?id={$row['category_id']}' class='btn btn-warning btn-sm'>✏️ Edit</a>
                            <a href='delete_category.php?id={$row['category_id']}' class='btn btn-danger btn-sm'>🗑️ Delete</a>
                          </td>";
                                        echo "</tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Toast & JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'success'): ?>
        <script>
            toastr.success("Category added successfully!");
        </script>
    <?php endif; ?>
</body>

</html>