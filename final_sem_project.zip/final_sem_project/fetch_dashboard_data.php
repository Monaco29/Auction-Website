<?php
require_once("bridge.php");

// Fetch total users
$totalUsersResult = mysqli_query($connect, "SELECT COUNT(*) AS totalUsers FROM user");
$totalUsers = mysqli_fetch_assoc($totalUsersResult)['totalUsers'];

// Fetch total items
$totalItemsResult = mysqli_query($connect, "SELECT COUNT(*) AS totalItems FROM item");
$totalItems = mysqli_fetch_assoc($totalItemsResult)['totalItems'];

// Fetch ongoing auctions
$ongoingAuctionsResult = mysqli_query($connect, "SELECT COUNT(*) AS ongoingAuctions FROM auction WHERE status = 'OnGoing' OR status = 'Active'");
$ongoingAuctions = mysqli_fetch_assoc($ongoingAuctionsResult)['ongoingAuctions'];

// Fetch total bids
$totalBidsResult = mysqli_query($connect, "SELECT COUNT(*) AS totalBids FROM bid");
$totalBids = mysqli_fetch_assoc($totalBidsResult)['totalBids'];

// Fetch total revenue (example, adjust as needed)
$totalRevenueResult = mysqli_query($connect, "SELECT SUM(Amount) AS totalRevenue FROM transections");
$totalRevenue = mysqli_fetch_assoc($totalRevenueResult)['totalRevenue'];

// Sample data for revenue and user growth charts
$revenueData = [
    'labels' => ['January', 'February', 'March', 'April', 'May'],
    'values' => [1200, 1500, 1800, 2000, 2200]
];

$userGrowthData = [
    'labels' => ['January', 'February', 'March', 'April', 'May'],
    'values' => [100, 200, 300, 400, 500]
];

// Prepare response
$response = [
    'totalUsers' => $totalUsers,
    'totalItems' => $totalItems,
    'ongoingAuctions' => $ongoingAuctions,
    'totalBids' => $totalBids,
    'totalRevenue' => $totalRevenue,
    'revenueData' => $revenueData,
    'userGrowthData' => $userGrowthData
];

echo json_encode($response);

mysqli_close($connect);
?>