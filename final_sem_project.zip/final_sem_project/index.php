<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>

    <!-- Google Fonts & Bootstrap -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Style -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            height: 100vh;
            margin: 0;
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            padding: 15px;
        }

        .login-card {
            width: 100%;
            max-width: 400px;
            background: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            animation: fadeInUp 0.8s ease;
        }

        .login-card .card-header {
            background: transparent;
            border: none;
            text-align: center;
            padding-top: 30px;
        }

        .login-card h3 {
            font-weight: 600;
        }

        .form-group label {
            font-weight: 500;
        }

        .btn-primary {
            background-color: #667eea;
            border: none;
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #5a67d8;
        }

        .extra-links {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
        }

        .shake {
            animation: shake 0.3s ease-in-out;
        }

        .password-wrapper {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            top: 70%;
            right: 12px;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 1rem;
        }

        @keyframes shake {
            0% {
                transform: translateX(0);
            }

            25% {
                transform: translateX(-5px);
            }

            50% {
                transform: translateX(5px);
            }

            75% {
                transform: translateX(-5px);
            }

            100% {
                transform: translateX(0);
            }
        }

        @keyframes fadeInUp {
            0% {
                transform: translateY(40px);
                opacity: 0;
            }

            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @media (max-width: 576px) {
            .login-card {
                margin: 0 10px;
            }
        }
    </style>
</head>

<body>

    <div class="login-container">
        <div class="card login-card">
            <div class="card-header">
                <h3>Admin Login</h3>
            </div>
            <div class="card-body">
                <form id="loginForm" method="POST">
                    <div class="form-group">
                        <label for="adminEmail">Email address</label>
                        <input type="email" class="form-control" id="adminEmail" name="email" required>
                    </div>
                    <div class="form-group password-wrapper">
                        <label for="adminPassword">Password</label>
                        <input type="password" class="form-control" id="adminPassword" name="password" required>
                        <span class="toggle-password" onclick="togglePassword()">👁️</span>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                    <div id="error-message" class="text-danger text-center mt-2" style="display: none;"></div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#loginForm').on('submit', function(e) {
                e.preventDefault();
                var email = $('#adminEmail').val();
                var password = $('#adminPassword').val();
                console.log(email);
                console.log(password);
                $.post('validate_admin.php', {
                    email: email,
                    password: password
                }, function(response) {
                    if (response.trim() === 'success') {
                        window.location.href = 'admin_dashboard.php';
                    } else {
                        $('#error-message')
                            .text('Invalid email or password.')
                            .fadeIn();

                        $('.card').addClass('shake');
                        setTimeout(() => {
                            $('.card').removeClass('shake');
                        }, 500);
                    }
                });
            });
        });

        function togglePassword() {
            var passwordField = document.getElementById("adminPassword");
            var icon = document.querySelector(".toggle-password");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                icon.textContent = "🙈";
            } else {
                passwordField.type = "password";
                icon.textContent = "👁️";
            }
        }
    </script>
</body>

</html>