<?php
require_once("../bridge.php");

if (isset($_GET['id'])) {
    $item_id = $_GET['id'];

    $sql = "DELETE FROM item WHERE item_id = '$item_id'";
    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('Item deleted successfully.')</script>";
        header("Location: manage_items.php");
        exit();
    } else {
        echo "<script>alert('Error: " . mysqli_error($connect) . ")</script>";
        header("Location: manage_items.php");
        exit();
    }
    mysqli_close($connect);
} else {
    echo "Invalid request.";
}
?>
