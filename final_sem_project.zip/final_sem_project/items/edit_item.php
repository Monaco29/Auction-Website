<?php
require_once("../bridge.php");

$item_id = 0;
if (isset($_GET['id'])) {
    $item_id = $_GET["id"];
}

$result = mysqli_query($connect, "SELECT * FROM item WHERE item_id = $item_id");
$item = mysqli_fetch_assoc($result);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Item</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #2c3e50, #4ca1af);
            color: #fff;
            padding: 30px;
        }

        body.dark-mode {
            background: linear-gradient(135deg, #1f1f1f, #3a3a3a);
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(10px);
            padding: 30px;
        }

        h2 {
            font-weight: 600;
            color: #ffffff;
            text-shadow: 1px 1px 3px #000;
            margin-bottom: 30px;
        }

        label {
            color: #ffffff;
        }

        .form-control,
        .form-control-file {
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: white;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 5px #00c3ff;
        }

        .btn-primary {
            background: linear-gradient(90deg, #6a11cb, #2575fc);
            border: none;
            padding: 10px 20px;
            border-radius: 12px;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: linear-gradient(90deg, #2575fc, #6a11cb);
            transform: translateY(-2px);
        }

        .btn-secondary {
            float: right;
            margin-bottom: 15px;
        }

        .toggle-btn {
            float: right;
            margin-left: 10px;
        }

        /* For devices up to 992px wide (medium screens) */
        @media (max-width: 992px) {
            body {
                padding: 20px;
            }

            .card {
                padding: 20px;
            }

            h2 {
                font-size: 1.8rem;
            }

            .btn {
                font-size: 0.95rem;
                padding: 8px 16px;
            }
        }

        /* For devices up to 768px wide (small screens) */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            .card {
                padding: 15px;
            }

            h2 {
                font-size: 1.6rem;
            }

            .btn {
                font-size: 0.9rem;
                padding: 6px 12px;
            }

            .form-control,
            .form-control-file {
                font-size: 0.9rem;
            }
        }

        /* For devices up to 576px wide (extra small screens) */
        @media (max-width: 576px) {
            body {
                padding: 10px;
            }

            .card {
                padding: 10px;
            }

            h2 {
                font-size: 1.4rem;
            }

            .btn {
                font-size: 0.8rem;
                padding: 5px 10px;
            }

            .form-control,
            .form-control-file {
                font-size: 0.8rem;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="mb-3">
            <button class="btn btn-secondary toggle-btn" onclick="document.body.classList.toggle('dark-mode')">Toggle Theme</button>
            <a href="manage_items.php" class="btn btn-warning">⬅ Back</a>
        </div>

        <h2>🖊️ Edit Item</h2>
        <div class="card">
            <form action="update_item.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="item_id" value="<?php echo $item['item_id']; ?>">
                <div class="form-group">
                    <label for="name">Item Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $item['name']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control" id="description" name="description" required><?php echo $item['description']; ?></textarea>
                </div>
                <div class="form-group">
                    <label for="start_price">Start Price</label>
                    <input type="number" step="0.01" class="form-control" id="start_price" name="start_price" value="<?= $item["start_price"]; ?>" required>
                </div>
                <div class="form-group">
                    <label for="picture">Picture</label>
                    <input type="file" class="form-control-file" id="picture" name="picture">
                </div>
                <button type="submit" class="btn btn-primary">💾 Update Item</button>
            </form>
        </div>
    </div>
</body>

</html>