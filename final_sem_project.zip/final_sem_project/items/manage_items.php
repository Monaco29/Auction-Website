<?php
require_once("../bridge.php");
$result = mysqli_query($connect, "SELECT * FROM item");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>📦 Manage Items</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #2c3e50, #4ca1af);
            color: #fff;
            padding: 30px;
        }

        body.dark-mode {
            background: linear-gradient(135deg, #1f1f1f, #3a3a3a);
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(10px);
            padding: 30px;
        }

        h2 {
            font-weight: 600;
            color: #ffffff;
            text-shadow: 1px 1px 3px #000;
            margin-bottom: 30px;
        }

        .btn-primary,
        .btn-warning,
        .btn-danger {
            border: none;
            border-radius: 10px;
            font-weight: 600;
            padding: 6px 12px;
            transition: 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(90deg, #6a11cb, #2575fc);
        }

        .btn-primary:hover {
            background: linear-gradient(90deg, #2575fc, #6a11cb);
            transform: translateY(-2px);
        }

        .btn-warning:hover {
            transform: scale(1.05);
        }

        .btn-danger:hover {
            transform: scale(1.05);
        }

        .logout {
            float: right;
        }

        .table {
            color: #fff;
        }

        .table th,
        .table td {
            vertical-align: middle !important;
        }

        .table thead th {
            background-color: rgba(255, 255, 255, 0.1);
        }

        img {
            border-radius: 8px;
            border: 2px solid #fff;
        }

        .toggle-btn {
            float: right;
            margin-left: 10px;
        }

        /* For devices up to 992px wide (medium devices) */
        @media (max-width: 992px) {
            body {
                padding: 20px;
            }

            h2 {
                font-size: 1.8rem;
                margin-bottom: 20px;
            }

            .card {
                padding: 20px;
            }

            .btn {
                font-size: 0.9rem;
                padding: 6px 8px;
            }
        }

        /* For devices up to 768px wide (small devices) */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            h2 {
                font-size: 1.6rem;
            }

            .card {
                padding: 15px;
            }

            .btn {
                font-size: 0.85rem;
                padding: 5px 8px;
            }

            .table {
                font-size: 0.85rem;
            }

            img {
                width: 80px;
                /* adjust image width to suit smaller screens */
            }
        }

        /* For devices up to 576px wide (extra small devices) */
        @media (max-width: 576px) {
            body {
                padding: 10px;
            }

            h2 {
                font-size: 1.4rem;
            }

            .card {
                padding: 10px;
            }

            .btn {
                font-size: 0.8rem;
                padding: 4px 6px;
            }

            .table {
                font-size: 0.8rem;
            }

            img {
                width: 60px;
                /* further reduce image width on very small devices */
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="mb-3">
            <button class="btn btn-secondary toggle-btn" onclick="document.body.classList.toggle('dark-mode')">🌓 Toggle Theme</button>
            <a href="../admin_logout.php" class="btn btn-danger logout">Logout</a>
        </div>

        <h2>📦 Manage Items</h2>
        <div class="card">
            <?php if (mysqli_num_rows($result) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Description</th>
                                <th>Start Price</th>
                                <th>Picture</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['description']; ?></td>
                                    <td>₹<?php echo $row['start_price']; ?></td>
                                    <td>
                                        <img src="../uploaded_images/<?php echo $row['picture']; ?>" alt="<?php echo $row['name']; ?>" width="100">
                                    </td>
                                    <td>
                                        <a href="edit_item.php?id=<?php echo $row['item_id']; ?>" class="btn btn-warning btn-sm">✏️ Edit</a>
                                        <a href="delete_item.php?id=<?php echo $row['item_id']; ?>" class="btn btn-danger btn-sm">🗑️ Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No items found in the database.</p>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>