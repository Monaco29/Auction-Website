<?php
require_once("../bridge.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $item_id = $_POST['item_id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $start_price = $_POST['start_price'];
    $sql = "";
    if(isset($_FILES['picture']) && $_FILES['picture']['error'] == UPLOAD_ERR_OK)
    {
        $picture = $_FILES['picture']['name'];
        $target_dir = "../uploaded_images/";
        $target_file = $target_dir . basename($picture);
        move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file);
        $sql = "UPDATE item SET name = '$name', description = '$description', start_price = $start_price, picture = '$picture' WHERE item_id = $item_id";
    }
    else
    {
        $sql = "UPDATE item SET name = '$name', description = '$description', start_price = $start_price WHERE item_id = $item_id";
    }
    
    if (mysqli_query($connect, $sql)) {
        header("location: manage_items.php");
        exit();
    } else {
        echo "<script>alert('Error: " . mysqli_error($connect) . "'); window.location.href='manage_item.php';</script>";
    }
            
}
mysqli_close($connect);
?>