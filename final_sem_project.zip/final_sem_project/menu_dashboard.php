<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }

        .card {
            margin-bottom: 20px;
            border-radius: 20px;
            padding: 20px;
            color: white;
            position: relative;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.25);
        }

        .card-body {
            padding: 0;
        }

        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .highlight-number {
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0;
        }

        .card .card-icon {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 3rem;
            opacity: 0.15;
        }

        .users-card {
            background: linear-gradient(135deg, #6a11cb, #2575fc);
        }

        .items-card {
            background: linear-gradient(135deg, #ff758c, #ff7eb3);
        }

        .auctions-card {
            background: linear-gradient(135deg, #43cea2, #185a9d);
        }

        .bids-card {
            background: linear-gradient(135deg, #f7971e, #ffd200);
            color: #333;
        }

        .chart-card {
            background-color: #fff;
            border-left: 5px solid #ffc107;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .chart-container {
            padding: 20px;
        }

        .chart-title {
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 20px;
            color: #333;
        }

        canvas {
            max-width: 100%;
            height: auto;
        }

        /* Responsive adjustments for small screens */
        @media (max-width: 576px) {
            body {
                padding: 10px;
            }

            .card {
                padding: 15px;
            }

            .card-title {
                font-size: 1rem;
            }

            .highlight-number {
                font-size: 2rem;
            }

            .card .card-icon {
                font-size: 2rem;
                top: 10px;
                right: 15px;
            }

            .chart-container {
                padding: 10px;
            }
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <h1 class="mb-4">Statistical Analysis</h1>
        <div class="row">
            <div class="col-md-3">
                <div class="card users-card">
                    <div class="card-body">
                        <h5 class="card-title">Total Users</h5>
                        <p class="highlight-number" id="totalUsers">0</p>
                        <i class="fas fa-users card-icon"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card items-card">
                    <div class="card-body">
                        <h5 class="card-title">Total Items</h5>
                        <p class="highlight-number" id="totalItems">0</p>
                        <i class="fas fa-box-open card-icon"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card auctions-card">
                    <div class="card-body">
                        <h5 class="card-title">Ongoing Auctions</h5>
                        <p class="highlight-number" id="ongoingAuctions">0</p>
                        <i class="fas fa-gavel card-icon"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bids-card">
                    <div class="card-body">
                        <h5 class="card-title">Total Bids</h5>
                        <p class="highlight-number" id="totalBids">0</p>
                        <i class="fas fa-hand-paper card-icon"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card chart-card">
                    <div class="card-body chart-container">
                        <h5 class="chart-title">Daily revenue generated</h5>
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card chart-card">
                    <div class="card-body chart-container">
                        <h5 class="chart-title">Monthly revenue generated</h5>
                        <canvas id="revenueMonthChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        fetchDashboardData();

        function fetchDashboardData() {
            fetch('fetch_dashboard_data.php')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('totalUsers').textContent = data.totalUsers;
                    document.getElementById('totalItems').textContent = data.totalItems;
                    document.getElementById('ongoingAuctions').textContent = data.ongoingAuctions;
                    document.getElementById('totalBids').textContent = data.totalBids;
                })
                .catch(error => console.error('Error fetching dashboard data:', error));
        }

        // Function to fetch revenue data and update chart
        async function loadRevenueChart() {
            try {
                // Fetch data from server
                const response = await fetch('revenue_endpoint.php');
                const revenueData = await response.json();

                // Update the chart with the fetched data
                updateRevenueChart(revenueData);
            } catch (error) {
                console.error('Error loading revenue data:', error);
            }
        }

        // Your existing function (modified slightly for reusability)
        function updateRevenueChart(revenueData) {
            const ctx = document.getElementById('revenueChart').getContext('2d');

            // Destroy previous chart instance if it exists
            if (window.revenueChart instanceof Chart) {
                window.revenueChart.destroy();
            }

            window.revenueChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: revenueData.labels,
                    datasets: [{
                        label: 'Revenue',
                        data: revenueData.values,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Revenue Amount'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Time Period'
                            }
                        }
                    }
                }
            });
        }

        // -------------------------------------------------------------------------------------
        async function loadRevenueMonthChart() {
            try {
                // Fetch data from server
                const response = await fetch('revenue_month_endpoint.php');
                const revenueData = await response.json();

                // Update the chart with the fetched data
                updateRevenueMonthChart(revenueData);
            } catch (error) {
                console.error('Error loading revenue data:', error);
            }
        }

        // Your existing function (modified slightly for reusability)
        function updateRevenueMonthChart(revenueData) {

            const ctx = document.getElementById('revenueMonthChart').getContext('2d');

            // Destroy previous chart instance if it exists
            if (window.revenueMonthChart instanceof Chart) {
                window.revenueMonthChart.destroy();
            }

            window.revenueMonthChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: revenueData.labels,
                    datasets: [{
                        label: 'Revenue',
                        data: revenueData.values,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Revenue Amount'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Time Period'
                            }
                        }
                    }
                }
            });
        }

        // Load the chart when the page loads
        document.addEventListener('DOMContentLoaded', () => {
            loadRevenueChart();
            loadRevenueMonthChart();
        });
    </script>

    <!-- Bootstrap and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>