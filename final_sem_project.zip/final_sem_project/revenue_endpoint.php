<?php
// revenue_endpoint.php

// Database connection
$db = new PDO('mysql:host=localhost:3307;dbname=project_auction', 'root', '');

// Query to get revenue data (example: group by month)
$query = "SELECT 
    DATE(generated_at) AS day, 
    SUM(revenue_amount) AS total_revenue 
FROM revenue 
GROUP BY DATE(generated_at) 
ORDER BY generated_at";

$stmt = $db->prepare($query);
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Prepare data for chart
$labels = [];
$values = [];

foreach ($results as $row) {
    $labels[] = $row['day'];
    $values[] = $row['total_revenue'];
}

// Return as JSON
header('Content-Type: application/json');
echo json_encode([
    'labels' => $labels,
    'values' => $values
]);
