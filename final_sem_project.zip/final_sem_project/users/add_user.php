<?php
require_once("../bridge.php"); // Adjusted path to parent directory
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash password
    $contact_number = $_POST['contact_number'];
    $address = $_POST['address'];

    $sql = "INSERT INTO user (username, email, password, contect_number, address) VALUES ('$username', '$email', '$password', '$contact_number', '$address')";
    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('User added successfully.')</script>";
        header("Location: manage_user.php");
        exit();
    } else {
        echo "<script>alert('Error: " . mysqli_error($connect) . ")</script>";
        header("Location: manage_user.php");
        exit();
    }
    mysqli_close($connect);
}
?>
