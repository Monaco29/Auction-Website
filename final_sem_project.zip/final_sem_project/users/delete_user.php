<?php
require_once("../bridge.php");

if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    $sql = "DELETE FROM user WHERE user_id = '$user_id'";
    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('User deleted successfully.')</script>";
        header("Location: manage_user.php");
        exit();
    } else {
        echo "<script>alert('Error: " . mysqli_error($connect) . ")</script>";
        header("Location: manage_user.php");
        exit();
    }
    mysqli_close($connect);
} else {
    echo "Invalid request.";
}
?>
