<?php
require_once("../bridge.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $seller_id = $_POST['seller_id'];
    $verified = isset($_POST['verified']) ? 1 : 0;

    $sql = "UPDATE seller SET verified = $verified WHERE seller_id = $seller_id";
    if(mysqli_query($connect, $sql))
    {
        header("Location: verify_sellers.php");
        exit();
    }
    else
    {
        echo "<script>alert('Not done yet')</script>";
    }
}
?>
