<?php
require_once("../bridge.php");
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['id'])) {
    $user_id = $_GET['id'];
    $result = mysqli_query($connect, "SELECT * FROM user WHERE user_id = '$user_id'");
    $user = mysqli_fetch_assoc($result);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $contact_number = $_POST['contact_number'];
    $address = $_POST['address'];

    $sql = "UPDATE user SET username = '$username', email = '$email', contect_number = '$contact_number', address = '$address' WHERE user_id = '$user_id'";
    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('User updated successfully.'); window.location.href='manage_user.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($connect) . "'); window.location.href='manage_user.php';</script>";
    }
    mysqli_close($connect);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #2c3e50, #4ca1af);
            color: #fff;
            padding: 30px;
        }

        body.dark-mode {
            background: linear-gradient(135deg, #1f1f1f, #3a3a3a);
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(10px);
            padding: 30px;
        }

        h2 {
            font-weight: 600;
            color: #ffffff;
            text-shadow: 1px 1px 3px #000;
            margin-bottom: 30px;
        }

        label {
            color: #ffffff;
        }

        .form-control {
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: white;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 5px #00c3ff;
        }

        .btn-primary {
            background: linear-gradient(90deg, #6a11cb, #2575fc);
            border: none;
            padding: 10px 20px;
            border-radius: 12px;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: linear-gradient(90deg, #2575fc, #6a11cb);
            transform: translateY(-2px);
        }

        .btn-secondary {
            float: right;
            margin-bottom: 15px;
        }

        .toggle-btn {
            float: right;
            margin-left: 10px;
        }

        /* Additional Media Queries for Edit User Page */

        /* For medium devices (tablets and below, 992px and down) */
        @media (max-width: 992px) {
            .container {
                padding: 20px;
            }

            h2 {
                font-size: 1.8rem;
            }

            .card {
                padding: 25px;
            }
        }

        /* For small devices (landscape phones and below, 768px and down) */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }

            h2 {
                font-size: 1.6rem;
            }

            .card {
                padding: 20px;
            }

            .btn-primary,
            .btn-warning,
            .btn-secondary {
                padding: 8px 16px;
                font-size: 0.9rem;
            }

            .form-control {
                padding: 0.5rem;
                font-size: 0.9rem;
            }
        }

        /* For extra small devices (portrait phones and below, 576px and down) */
        @media (max-width: 576px) {
            .container {
                padding: 10px;
            }

            h2 {
                font-size: 1.4rem;
            }

            .card {
                padding: 15px;
            }

            .btn-primary,
            .btn-warning,
            .btn-secondary {
                padding: 6px 12px;
                font-size: 0.8rem;
            }

            .form-control {
                padding: 0.4rem;
                font-size: 0.8rem;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="mb-3">
            <button class="btn btn-secondary toggle-btn" onclick="document.body.classList.toggle('dark-mode')">Toggle Theme</button>
            <a href="manage_user.php" class="btn btn-warning">⬅ Back</a>
        </div>

        <h2>🛠️ Edit User</h2>
        <div class="card">
            <form action="edit_user.php" method="POST">
                <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo $user['username']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="contact_number">Contact Number</label>
                    <input type="text" class="form-control" id="contact_number" name="contact_number" value="<?php echo $user['contect_number']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea class="form-control" id="address" name="address" required><?php echo $user['address']; ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">💾 Update User</button>
            </form>
        </div>
    </div>
</body>

</html>