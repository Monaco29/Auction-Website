<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Online Auction System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f9ff;
      color: #2d2d2d;
    }

    .navbar {
      background-color: #001f3f;
    }

    .navbar-brand {
      color: #00d4ff;
      font-size: 1.8rem;
      font-weight: bold;
    }

    .navbar-nav .nav-link {
      color: #e0e0e0;
    }

    .navbar-nav .nav-link:hover {
      color: #00d4ff;
    }

    .banner {
      background: linear-gradient(135deg, #0066cc, #00c9ff);
      color: white;
      text-align: center;
      padding: 100px 20px;
    }

    .banner h1 {
      font-size: 3.5rem;
      font-weight: bold;
    }

    .banner p {
      font-size: 1.25rem;
      margin-top: 15px;
    }

    .info-box {
      background: #e3f2fd;
      color: #01579b;
      border-left: 6px solid #00c9ff;
      padding: 1rem 1.5rem;
      border-radius: 8px;
      margin-bottom: 2rem;
    }

    .card {
      border: none;
      border-radius: 15px;
      overflow: hidden;
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card-img-top {
      height: 220px;
      object-fit: cover;
    }

    .card-title {
      font-size: 1.25rem;
      font-weight: bold;
    }

    .btn-view {
      background-color: #001f3f;
      color: white;
      border-radius: 25px;
      padding: 8px 20px;
      transition: all 0.3s;
    }

    .btn-view:hover {
      background-color: #00c9ff;
      color: #000;
    }

    .category-icons i {
      font-size: 3rem;
      color: #00c9ff;
    }

    .stats {
      display: flex;
      justify-content: space-around;
      padding: 40px 0;
      background-color: #00c9ff;
      color: white;
    }

    .stat {
      text-align: center;
    }

    .form-inline input[type="email"] {
      max-width: 300px;
    }

    footer {
      background-color: #001f3f;
    }

    footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <a class="navbar-brand" href="#"><i class="bi bi-gem"></i> Auction House</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto">
          <li class="nav-item"><a class="nav-link active" href="#">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Auctions</a></li>
          <li class="nav-item"><a class="nav-link" href="#">My Account</a></li>
        </ul>
        <ul class="navbar-nav">
          <li class="nav-item" id="signInNav"><a class="nav-link" href="#">Sign In</a></li>
          <li class="nav-item" id="signUpNav"><a class="nav-link" href="#">Sign Up</a></li>
          <li class="nav-item dropdown" id="userDropdown" style="display: none;">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
              <img src="user_image.jpg" class="rounded-circle user-img" alt="User" width="30" height="30" />
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="#">Profile</a></li>
              <li><a class="dropdown-item" href="#">Logout</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <section class="banner">
    <div class="container">
      <h1>Welcome to Auction House!</h1>
      <p>Discover unique treasures and bid your way to ownership!</p>
      <button class="btn btn-light mt-3" id="learnMoreBtn"><i class="bi bi-info-circle-fill"></i> Learn More</button>
    </div>
  </section>

  <div class="container mt-5">
    <div class="info-box">
      <strong>Note:</strong> Please <a href="#" class="alert-link">Sign In</a> or <a href="#" class="alert-link">Sign Up</a> to participate in auctions and access more features.
    </div>

    <div class="input-group mb-4">
      <input type="text" class="form-control" placeholder="Search auctions...">
      <button class="btn btn-info">Search</button>
    </div>

    <h2>Top Categories</h2>
    <div class="row text-center category-icons mb-4">
      <div class="col"><i class="fas fa-gem"></i>
        <p>Jewelry</p>
      </div>
      <div class="col"><i class="fas fa-car"></i>
        <p>Vehicles</p>
      </div>
      <div class="col"><i class="fas fa-laptop"></i>
        <p>Electronics</p>
      </div>
      <div class="col"><i class="fas fa-paint-brush"></i>
        <p>Art</p>
      </div>
    </div>

    <h2 class="mb-4">Featured Auctions</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card">
          <img src="example.jpg" class="card-img-top" alt="Auction Item">
          <div class="card-body">
            <h5 class="card-title">Vintage Watch</h5>
            <p class="card-text">A rare Swiss vintage watch in pristine condition.</p>
            <a href="#" class="btn btn-view">View Auction</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="example.jpg" class="card-img-top" alt="Auction Item">
          <div class="card-body">
            <h5 class="card-title">Antique Vase</h5>
            <p class="card-text">Beautiful hand-crafted porcelain from the Qing dynasty.</p>
            <a href="#" class="btn btn-view">View Auction</a>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="example.jpg" class="card-img-top" alt="Auction Item">
          <div class="card-body">
            <h5 class="card-title">Collector’s Coin</h5>
            <p class="card-text">Limited edition gold coin from 1920s collection.</p>
            <a href="#" class="btn btn-view">View Auction</a>
          </div>
        </div>
      </div>
    </div>

    <h3 class="mt-5">Why Choose Us?</h3>
    <div class="row">
      <div class="col-md-3 text-center">🔐 Secure Bidding</div>
      <div class="col-md-3 text-center">✅ Verified Sellers</div>
      <div class="col-md-3 text-center">🕒 24/7 Support</div>
      <div class="col-md-3 text-center">🌐 Global Reach</div>
    </div>

    <div class="stats mt-5">
      <div class="stat">
        <h3>2500+</h3>
        <p>Auctions Held</p>
      </div>
      <div class="stat">
        <h3>10,000+</h3>
        <p>Registered Users</p>
      </div>
      <div class="stat">
        <h3>500+</h3>
        <p>Live Auctions</p>
      </div>
    </div>

    <div class="text-center mt-5">
      <h4>Subscribe for Updates</h4>
      <form class="form-inline justify-content-center">
        <input type="email" class="form-control mr-2" placeholder="Enter your email">
        <button class="btn btn-outline-primary">Subscribe</button>
      </form>
    </div>
  </div>

  <footer class="text-white pt-4 pb-3 mt-5">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <h5 class="text-info">Auction House</h5>
          <p>Bid smart. Win big. Discover unique items every day on our trusted online auction platform.</p>
        </div>
        <div class="col-md-4 mb-3">
          <h5 class="text-info">Quick Links</h5>
          <ul class="list-unstyled">
            <li><a href="#" class="text-white-50">Home</a></li>
            <li><a href="#" class="text-white-50">Auctions</a></li>
            <li><a href="#" class="text-white-50">My Account</a></li>
            <li><a href="#" class="text-white-50">Contact Us</a></li>
          </ul>
        </div>
        <div class="col-md-4 mb-3">
          <h5 class="text-info">Contact</h5>
          <p>Email: support@auctionhouse.com</p>
          <p>Phone: +1 234 567 890</p>
          <div>
            <a href="#" class="text-white-50 me-2"><i class="fab fa-facebook"></i></a>
            <a href="#" class="text-white-50 me-2"><i class="fab fa-twitter"></i></a>
            <a href="#" class="text-white-50"><i class="fab fa-instagram"></i></a>
          </div>
        </div>
      </div>
      <hr class="bg-secondary">
      <div class="text-center">
        <small>&copy; 2025 Auction House. All rights reserved.</small>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>