<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #2c3e50, #4ca1af);
            color: #fff;
            padding: 30px;
            transition: background 0.5s ease;
        }

        body.dark-mode {
            background: linear-gradient(135deg, #1f1f1f, #3a3a3a);
        }

        h1 {
            font-weight: 600;
            color: #ffffff;
            text-shadow: 1px 1px 3px #000;
        }

        .logout {
            text-align: right;
            margin-bottom: 20px;
        }

        .btn-danger {
            background-color: #ff4d4f;
            border: none;
            transition: all 0.3s ease;
        }

        .btn-danger:hover {
            background-color: #e60000;
        }

        .btn-primary {
            background: linear-gradient(90deg, #6a11cb, #2575fc);
            border: none;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            background: linear-gradient(90deg, #2575fc, #6a11cb);
            transform: translateY(-2px);
        }

        .btn-warning {
            background-color: #f39c12;
            border: none;
            color: white;
        }

        .toggle-btn {
            float: right;
            margin-left: 10px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 20px;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(10px);
            padding: 20px;
            margin-bottom: 30px;
        }

        label {
            color: #ffffff;
        }

        .form-control {
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: white;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 5px #00c3ff;
        }

        table {
            background-color: rgba(198, 198, 198, 0.3);
            color: white;
            border-radius: 10px;
        }

        thead th {
            background: linear-gradient(to right, #00c3ff, #8e2de2);
            color: white;
        }

        tbody tr {
            animation: fadeInSlide 0.5s ease;
        }

        @keyframes fadeInSlide {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .table-responsive {
            overflow-x: auto;
        }


        /* Additional Media Queries for Responsiveness */

        /* For medium devices (tablets, 992px and below) */
        @media (max-width: 992px) {
            .container {
                padding: 15px;
            }

            h1 {
                font-size: 1.8rem;
            }
        }

        /* For small devices (landscape phones, 768px and below) */
        @media (max-width: 768px) {
            .btn {
                margin-top: 5px;
            }

            .card {
                padding: 15px;
            }

            h1 {
                font-size: 1.6rem;
            }

            .form-control {
                font-size: 0.9rem;
            }

            table {
                font-size: 0.85rem;
            }
        }

        /* For extra small devices (portrait phones, 576px and below) */
        @media (max-width: 576px) {
            body {
                padding: 10px;
            }

            h1 {
                font-size: 1.4rem;
            }

            .card {
                padding: 10px;
                margin-bottom: 15px;
            }

            .form-control {
                font-size: 0.85rem;
            }

            table {
                font-size: 0.8rem;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="logout">
            <button class="btn btn-secondary toggle-btn" onclick="toggleDarkMode()">🌓 Toggle Theme</button>
            <a href="../admin_logout.php" class="btn btn-danger">Logout</a>
        </div>

        <h1 class="mb-4">✨ Manage Users</h1>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title text-white">Add New User</h5>
                <form action="add_user.php" method="POST" onsubmit="showToast('User added successfully!', 'success')">
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="contact_number">Contact Number</label>
                            <input type="text" class="form-control" id="contact_number" name="contact_number" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="2" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">➕ Add User</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title text-white">User List</h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover text-white">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Contact Number</th>
                                <th>Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            require_once("../bridge.php");
                            $result = mysqli_query($connect, "SELECT * FROM user");
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['username'] . "</td>";
                                echo "<td>" . $row['email'] . "</td>";
                                echo "<td>" . $row['contect_number'] . "</td>";
                                echo "<td>" . $row['address'] . "</td>";
                                echo "<td>";
                                echo "<a href='edit_user.php?id=" . $row['user_id'] . "' class='btn btn-warning btn-sm' onclick=\"showToast('Edit user clicked!', 'info')\">✏️ Edit</a> ";
                                echo "<a href='delete_user.php?id=" . $row['user_id'] . "' class='btn btn-danger btn-sm' onclick=\"showToast('User deleted!', 'error')\">🗑️ Delete</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        function toggleDarkMode() {
            document.body.classList.toggle("dark-mode");
        }

        function showToast(message, type) {
            toastr.options = {
                "closeButton": true,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "timeOut": "3000"
            };
            toastr[type](message);
        }
    </script>
</body>

</html>