<?php
require_once("../bridge.php");

session_start();
$user_id = $_SESSION['user_id'] ?? 1;

if (!$user_id) {
    echo "<script>alert('User not logged in'); window.location.href='login.php';</script>";
    exit;
}

$sql = "SELECT * FROM user_address WHERE user_id = '$user_id' ORDER BY created_at DESC";
$result = mysqli_query($connect, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>My Delivery Addresses</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #3a6073, #16222A);
            color: #fff;
            padding: 30px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
        }

        .card h5 {
            color: #fff;
            font-weight: 600;
        }

        .card p {
            color: #ddd;
            margin: 5px 0;
        }

        .btn-primary {
            background: linear-gradient(90deg, #00c6ff, #0072ff);
            border: none;
            border-radius: 12px;
            padding: 8px 15px;
        }

        h2 {
            font-weight: 600;
            margin-bottom: 30px;
        }
    </style>
</head>

<body>
    <div class="container">
        <a href="add_address.php" class="btn btn-primary mb-3">➕ Add New Address</a>
        <h2>📦 My Delivery Addresses</h2>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
        ?>
                <div class="card">
                    <h5>📍 Address ID: <?= $row['address_id'] ?></h5>
                    <p><strong>Address:</strong> <?= nl2br($row['address']) ?></p>
                    <p><strong>City:</strong> <?= $row['city'] ?></p>
                    <p><strong>State:</strong> <?= $row['state'] ?></p>
                    <p><strong>Pincode:</strong> <?= $row['pincode'] ?></p>
                    <p><strong>Country:</strong> <?= $row['country'] ?></p>
                    <p><strong>Created At:</strong> <?= $row['created_at'] ?></p>
                </div>
        <?php
            }
        } else {
            echo "<p>No addresses found. Please <a href='add_address.php' class='text-warning'>add a new one</a>.</p>";
        }
        mysqli_close($connect);
        ?>
    </div>
</body>

</html>