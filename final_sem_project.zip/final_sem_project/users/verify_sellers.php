<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sellers</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
        }

        .container {
            max-width: 1200px;
            margin-top: 30px;
        }

        .logout {
            text-align: right;
            margin-bottom: 20px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(10px);
            padding: 30px;
        }


        .card-title {
            font-weight: 600;
            font-size: 1.25rem;
            color: #333;
        }

        .table th,
        .table td {
            vertical-align: middle !important;
            font-size: 0.95rem;
        }

        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 26px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 20px;
            width: 20px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked+.slider {
            background-color: #28a745;
        }

        input:checked+.slider:before {
            transform: translateX(24px);
        }

        .btn-warning {
            padding: 4px 10px;
            font-size: 0.85rem;
        }

        /* For medium screens (up to 992px) */
        @media (max-width: 992px) {
            .container {
                padding: 20px;
            }

            .card {
                padding: 20px;
            }

            .card-title {
                font-size: 1.1rem;
            }

            .table th,
            .table td {
                font-size: 0.9rem;
            }
        }

        /* For small screens (up to 768px) */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }

            .card {
                padding: 15px;
            }

            h2 {
                font-size: 1.6rem;
            }

            .card-title {
                font-size: 1rem;
            }

            .table th,
            .table td {
                font-size: 0.85rem;
            }

            .logout {
                text-align: center;
                margin-bottom: 10px;
            }
        }

        /* For extra small screens (up to 576px) */
        @media (max-width: 576px) {
            .container {
                padding: 10px;
            }

            h2 {
                font-size: 1.4rem;
            }

            .card {
                padding: 10px;
            }

            .card-title {
                font-size: 0.95rem;
            }

            .table th,
            .table td {
                font-size: 0.8rem;
            }

            .btn-warning {
                font-size: 0.75rem;
                padding: 3px 8px;
            }

            .btn-danger {
                font-size: 0.75rem;
            }

            /* Adjust the toggle switch size on tiny devices */
            .switch {
                width: 40px;
                height: 22px;
            }

            .slider:before {
                height: 16px;
                width: 16px;
                left: 3px;
                bottom: 3px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="logout">
            <a href="../admin_logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
        <h2 class="text-center mb-4">Manage Sellers</h2>
        <div class="card p-3">
            <h5 class="card-title">Seller List</h5>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered mt-3">
                    <thead class="thead-dark">
                        <tr>
                            <th>Seller ID</th>
                            <th>User ID</th>
                            <th>Business Name</th>
                            <th>Business Address</th>
                            <th>Business Email</th>
                            <th>Average Rating</th>
                            <th>Total Sales</th>
                            <th>Verified</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require_once("../bridge.php");
                        $result = mysqli_query($connect, "SELECT * FROM seller");
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['seller_id'] . "</td>";
                            echo "<td>" . $row['user_id'] . "</td>";
                            echo "<td>" . $row['business_name'] . "</td>";
                            echo "<td>" . $row['business_address'] . "</td>";
                            echo "<td>" . $row['business_email'] . "</td>";
                            echo "<td>" . $row['average_rating'] . "</td>";
                            echo "<td>" . $row['total_sales'] . "</td>";
                            echo "<td>";
                            echo "<label class='switch'>";
                            echo "<input type='checkbox' name='verified' " . ($row['verified'] ? "checked" : "") . " form='form_" . $row['seller_id'] . "'>";
                            echo "<span class='slider'></span>";
                            echo "</label>";
                            echo "</td>";
                            echo "<td>";
                            echo "<form id='form_" . $row['seller_id'] . "' action='edit_seller_verification.php' method='POST'>";
                            echo "<input type='hidden' name='seller_id' value='" . $row['seller_id'] . "'>";
                            echo "<input type='hidden' name='user_id' value='" . $row['user_id'] . "'>";
                            echo "<input type='hidden' name='verified_status' value='" . ($row['verified'] ? "1" : "0") . "'>";
                            echo "<button type='submit' class='btn btn-warning btn-sm'>Update</button>";
                            echo "</form>";
                            echo "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script>
        $(document).ready(function() {
            $('input[type="checkbox"][name="verified"]').on('change', function() {
                const isChecked = $(this).is(':checked') ? 1 : 0;
                const form = $(this).closest('form');
                form.find('input[name="verified_status"]').val(isChecked);
            });
        });
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>