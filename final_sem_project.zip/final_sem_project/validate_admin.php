<?php
require_once("bridge.php");
require_once("mail_helper.php"); // ✅ Add this to use sendMail()
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $email = mysqli_real_escape_string($connect, $email);
    $password = mysqli_real_escape_string($connect, $password);

    $sql = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($connect, $sql);

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['admin'] = $email;

        // ✅ Send Login Notification Email
        $subject = "Admin Login Notification";
        $body = "<h3>Admin Login Successful</h3>
                 <p><strong>Email:</strong> $email</p>
                 <p><strong>Time:</strong> " . date("Y-m-d H:i:s") . "</p>
                 <p>This is an automatic login alert from your auction system.</p>";

        // sendMail($email, $subject, $body); // Sends email to admin themselves

        echo 'success';
    }

    mysqli_close($connect);
}
?>