<?php
include('../bridge.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $auctionID = $_POST["auction_id"];
    $buyerID = $_POST["buyer_id"];
    $itemID = $_POST["item_id"];

    $get_amount = "SELECT MAX(bid_amount) AS Amount FROM bid WHERE auction_id = $auctionID";
    $r = mysqli_fetch_assoc(mysqli_query($connect, $get_amount));
    $higherAmount = $r["Amount"];

    $fQry = "UPDATE item SET end_price = $higherAmount WHERE item_id = $itemID";
    $query = "DELETE FROM active_bidders WHERE auction_id = $auctionID AND buyer_id = $buyerID";
    $qry = "UPDATE auction SET status = 'Closed' WHERE auction_id = $auctionID";
    $statusUpdate = "UPDATE bid SET has_won = 1 WHERE auction_id = $auctionID AND bid_amount = $higherAmount";

    if (mysqli_query($connect, $query) && mysqli_query($connect, $qry) && mysqli_query($connect, $statusUpdate) && mysqli_query($connect, $fQry)) {
        echo json_encode([
            'status' => 'success',
            'message' => 'You have successfully exited the auction.'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to exit the auction. Please try again later.'
        ]);
    }
    mysqli_close($conn);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method.'
    ]);
}
?>