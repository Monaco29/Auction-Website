<?php
require_once("../bridge.php");
session_start();

if (isset($_SESSION["buyer_id"]) && isset($_SESSION["item_id"]) && isset($_SESSION["auction_id"])) {
    $buyerID = $_SESSION["buyer_id"];
    $itemID = $_SESSION["item_id"];
    $auctionID = $_SESSION["auction_id"];
} else {
    header("Location: ../home.php");
    exit();
}

// Fetch item details
$query = "SELECT * FROM item WHERE item_id = $itemID";
$result = mysqli_query($connect, $query);
$item = mysqli_fetch_assoc($result);

// Fetch current highest bid or fallback to starting bid
$currentBidQuery = "SELECT MAX(bid_amount) AS highest_bid FROM bid WHERE auction_id = $auctionID";
$currentBidResult = mysqli_query($connect, $currentBidQuery);
$currentBidRow = mysqli_fetch_assoc($currentBidResult);
$highestBid = $currentBidRow["highest_bid"] ?? $item["start_price"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Buyer Auction Room</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .buyer-container {
            background-color: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

    <div class="container-fluid">
        <!-- Top Section -->
        <div class="row bg-primary text-white text-center py-2">
            <div class="col-10">
                <h2><?php echo htmlspecialchars($item["name"]); ?> Auction</h2>
            </div>
            <div class="col-2 text-end">
                <button class="btn btn-danger">
                    <a href="../home.php" class="text-white text-decoration-none">Exit</a>
                </button>
            </div>
        </div>

        <!-- Main Content Section -->
        <div class="row mt-3">
            <!-- Buyers List (Left) -->
            <div class="col-md-3 bg-light p-3" style="overflow-y: auto; max-height: 400px;">
                <h5>Joined Buyers</h5>
                <div id="buyer-list">
                    <!-- Buyers will be populated dynamically here -->
                </div>
            </div>

            <!-- Item Details (Center) -->
            <div class="col-md-6 text-center">
                <h4><?php echo htmlspecialchars($item["name"]); ?></h4>
                <img src="../../final_sem_project/uploaded_images/<?php echo htmlspecialchars($item["picture"]); ?>"
                    class="img-fluid" alt="Auction Item">
                <p><?php echo htmlspecialchars($item["description"]); ?></p>
                <h5>Starting Bid: $<?php echo htmlspecialchars($item["start_price"]); ?></h5>
                <h5>Current Bid: $<span id="current-bid"><?php echo htmlspecialchars($highestBid); ?></span></h5>
            </div>

            <!-- Live Bid Feed (Right) -->
            <div class="col-md-3 bg-light p-3">
                <h5>Live Bids</h5>
                <ul class="list-group" id="bid-feed">
                    <!-- Live bid updates will be populated dynamically here -->
                </ul>
            </div>
        </div>

        <!-- Bottom Section -->
        <div class="row mt-3 text-center">
            <div class="col-md-6">
                <h5>Bid Timer: 00:00</h5>
            </div>
            <div class="col-md-6">
                <input type="number" class="form-control d-inline w-50" id="bid-input" placeholder="Enter your bid"
                    min="<?php echo htmlspecialchars($highestBid + 1); ?>" step="1">
                <button class="btn btn-success" onclick="placeBid()">Place Bid</button>
                <p id="validation-message" class="text-danger mt-2"></p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Fetch active buyers dynamically and update the list
        function fetchActiveBuyers() {
            $.ajax({
                url: 'fetch_buyers.php',
                method: 'GET',
                data: { auction_id: "<?php echo $auctionID; ?>" },
                success: function (response) {
                    var buyerList = $('#buyer-list');
                    buyerList.empty(); // Clear previous buyers

                    response.forEach(function (buyer) {
                        var buyerDiv = `
                            <div class="buyer-container border p-2 mb-2 d-flex align-items-center">
                                <img src="../../final_sem_project/uploaded_images/${buyer.profile_pic}" class="rounded-circle me-2" alt="${buyer.buyer_name}" style="width: 40px; height: 40px;">
                                <strong>${buyer.buyer_name}</strong>
                            </div>`;
                        buyerList.append(buyerDiv);
                    });
                },
                error: function (xhr, status, error) {
                    console.error("Error fetching buyers:", error);
                }
            });
        }

        // Fetch the current highest bid dynamically
        function fetchCurrentBid(callback) {
            $.ajax({
                url: 'fetch_highest_bid.php',
                method: 'GET',
                data: { auction_id: "<?php echo $auctionID; ?>" },
                dataType: 'json', // Ensures response is treated as JSON
                success: function (response) {
                    console.log("Parsed Response:", response); // Log response
                    var currentBid = response.highest_bid || <?php echo $item["start_price"]; ?>; // Fallback to starting bid
                    console.log("Current Bid:", currentBid); // Verify parsed bid
                    callback(currentBid); // Pass the bid to callback
                },
                error: function (xhr, status, error) {
                    console.error("AJAX Error:", {
                        status: status,
                        error: error,
                        responseText: xhr.responseText // Raw response text
                    });
                    alert("Error fetching the current bid. Please check the console.");
                }
            });
        }

        // Place a bid after validating the entered amount
        function placeBid() {
            var bidAmount = parseInt(document.getElementById("bid-input").value, 10);

            // Validate bid amount as an integer
            if (!Number.isInteger(bidAmount)) {
                document.getElementById("validation-message").innerText = "Please enter a valid integer bid amount.";
                return;
            }

            // Fetch the latest highest bid and validate
            fetchCurrentBid(function (currentBid) {
                if (bidAmount > currentBid) {
                    // Proceed to place the bid
                    $.ajax({
                        url: 'place_bid.php',
                        method: 'POST',
                        data: { bid_amount: bidAmount },
                        success: function (response) {
                            console.log("Server Response:", response); // Debugging output

                            try {
                                var result = typeof response === 'string' ? JSON.parse(response) : response;
                                alert(result.message); // Display success or failure message
                            } catch (error) {
                                console.error("JSON Parse Error:", error);
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error("AJAX Error Details:", {
                                status: status, 
                                error: error,
                                responseText: xhr.responseText 
                            });
                            alert("An error occurred while placing the bid. Please check the console for details.");
                        }
                    });
                } else {
                    // Validate that the DOM element exists
                    var validationMessage = document.getElementById("validation-message");
                    if (validationMessage) {
                        // Display validation message if the DOM element exists
                        validationMessage.innerText =
                            `Bid amount must be greater than $${currentBid}`;
                    } else {
                        console.error("Element with ID 'validation-message' not found!");
                    }
                    console.log("Current Bid:", currentBid); // Log current bid value
                }
            });
        }

        // Fetch and update the live bid feed after a successful bid
        function fetchLiveBids() {
            $.ajax({
                url: 'fetch_bid_feed.php', // Server-side script to fetch live bid feed
                method: 'GET',
                data: { auction_id: "<?php echo $auctionID; ?>" },
                success: function (response) {
                    var bids = JSON.parse(response);
                    var bidFeed = $('#bid-feed');
                    bidFeed.empty(); // Clear previous bids

                    bids.forEach(function (bid) {
                        var bidItem = `<li class="list-group-item">${bid.buyer_name}: $${bid.bid_amount}</li>`;
                        bidFeed.append(bidItem);
                    });
                },
                error: function (xhr, status, error) {
                    console.error("Error fetching live bids:", error);
                }
            });
        }

        function startOrResetTimer() {
            clearInterval(timerInterval); // Clear any existing timer
            timeLeft = 55; // Reset timer to 55 seconds
            timerInterval = setInterval(() => {
                if (timeLeft <= 0) {
                    clearInterval(timerInterval); // Stop the timer
                    console.log("Auction closed. No higher bids placed.");
                    alert("Auction closed"); // Show popup message
                    disableBidding(); // Disable further bidding
                } else {
                    document.getElementById("number").innerText = `${timeLeft}s`; // Update timer display
                    timeLeft--; // Decrease timer
                }
            }, 1000);
        }

        fetchActiveBuyers();

        setInterval(fetchActiveBuyers, 2000);
    </script>
</body>

</html>