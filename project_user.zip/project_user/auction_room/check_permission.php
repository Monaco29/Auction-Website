<?php
require_once("../bridge.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $auctionID = $_POST["auction_id"];
    $qry = "SELECT * FROM auction_permission WHERE auction_id = $auctionID";
    $result = mysqli_query($connect, $qry);
    $row = mysqli_fetch_assoc($result);
    if ($row["start_auction"] == 1) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error']);
    }
}

?>