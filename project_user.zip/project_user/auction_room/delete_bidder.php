<?php
include('../bridge.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $auctionID = $_POST['auction_id']; 
    $userID = $_POST['buyer_id'];

    $query = "DELETE FROM active_bidders WHERE auction_id = $auctionID AND buyer_id = $userID";

    if (mysqli_query($connect, $query)) {
        echo json_encode([
            'status' => 'success',
            'message' => 'You have successfully exited the auction.'
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to exit the auction. Please try again later.'
        ]);
    }
    mysqli_close($conn);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request method.'
    ]);
}
?>
