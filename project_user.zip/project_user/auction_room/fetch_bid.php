<?php
// Database connection
$host = 'Localhost:3307';
$dbname = 'project_auction';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}

// Validate auction_id
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $auctionId = isset($_GET['auction_id']) ? intval($_GET['auction_id']) : 0;

    if ($auctionId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid auction ID.']);
        exit;
    }

    try {
        // Fetch bids for the specified auction
        $stmt = $conn->prepare("
            SELECT b.bid_id, b.auction_id, b.buyer_id, b.bid_amount, b.bid_time, 
                   COALESCE(u.username, 'Anonymous') AS username
            FROM bid b
            LEFT JOIN user u ON b.buyer_id = u.user_id
            WHERE b.auction_id = :auction_id
            ORDER BY b.bid_amount DESC, b.bid_time ASC
        ");
        $stmt->bindParam(':auction_id', $auctionId, PDO::PARAM_INT);
        $stmt->execute();

        $bids = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch the highest bid
        $stmt = $conn->prepare("SELECT MAX(bid_amount) AS highest_bid FROM bid WHERE auction_id = :auction_id");
        $stmt->bindParam(':auction_id', $auctionId, PDO::PARAM_INT);
        $stmt->execute();
        $highestBid = $stmt->fetchColumn();

        $highestBid = $highestBid ?: 0;

        echo json_encode([
            'status' => 'success',
            'message' => 'Bids fetched successfully.',
            'bids' => $bids,
            'highest_bid' => $highestBid
        ]);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
