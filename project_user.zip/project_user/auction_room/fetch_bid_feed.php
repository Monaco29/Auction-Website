<?php
require_once("../bridge.php");

if (isset($_GET["auction_id"])) {
    $auctionID = $_GET["auction_id"];

    // Query to fetch the bid feed
    $query = "SELECT b.bid_amount,b.bid_time, u.username AS buyer_name, u.profile_pic 
              FROM bid b
              JOIN buyer a ON a.buyer_id = b.buyer_id
              JOIN user u ON u.user_id = a.user_id 
              WHERE b.auction_id = $auctionID
              ORDER BY b.bid_amount DESC";
    $result = mysqli_query($connect, $query);

    $bids = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $bids[] = [
            "bid_amount" => number_format($row["bid_amount"]),
            "buyer_name" => $row["buyer_name"],
            "bid_time" => $row["bid_time"],
            "profile_pic" => $row["profile_pic"],
        ];
    }

    echo json_encode($bids);
} else {
    echo json_encode(["error" => "Auction ID not provided"]);
}
?>