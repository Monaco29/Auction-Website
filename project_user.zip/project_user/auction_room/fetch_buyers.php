<?php
require_once("../bridge.php");

// error_reporting(E_ALL);
// ini_set('display_errors', 1);

if (isset($_GET["auction_id"])) {
    $auctionID = $_GET["auction_id"];

    // Query buyers from database
    $query = "SELECT b.buyer_id, b.is_typing, bu.user_id, u.username AS buyer_name, u.profile_pic 
          FROM active_bidders AS b
          JOIN buyer AS bu ON b.buyer_id = bu.buyer_id
          JOIN user AS u ON bu.user_id = u.user_id
          WHERE b.auction_id = $auctionID";

    $result = mysqli_query($connect, $query);

    // Check for SQL errors
    if (!$result) {
        echo json_encode(["error" => "Database query failed: " . mysqli_error($connect)]);
        exit();
    }

    $buyers = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $buyers[] = ["buyer_id" => $row["buyer_id"], "buyer_name" => $row["buyer_name"],"profile_pic" => $row["profile_pic"], "is_typing" => $row["is_typing"]];
    }

    header('Content-Type: application/json');
    echo json_encode($buyers);
} else {
    echo json_encode(["error" => "Auction ID not provided"]);
}
?>