<?php
require_once("../bridge.php");

header('Content-Type: application/json');

// Debug Log
file_put_contents("debug_log.txt", "Fetch Highest Bid PHP Script Called.\n", FILE_APPEND);

if (isset($_GET["auction_id"])) {
    $auctionID = $_GET["auction_id"];
    file_put_contents("debug_log.txt", "Auction ID: $auctionID\n", FILE_APPEND);

    $query = "SELECT MAX(bid_amount) AS highest_bid FROM bid WHERE auction_id = $auctionID";
    $result = mysqli_query($connect, $query);
    file_put_contents("debug_log.txt", "Query Result: " . ($result ? "Success" : "Failure") . "\n", FILE_APPEND);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $highestBid = $row["highest_bid"];

        if ($highestBid === null) {
            // Fallback to starting bid
            $startingBidQuery = "SELECT start_price FROM item WHERE item_id = (SELECT item_id FROM auction WHERE auction_id = $auctionID)";
            $startingBidResult = mysqli_query($connect, $startingBidQuery);
            $startingBidRow = mysqli_fetch_assoc($startingBidResult);
            $highestBid = $startingBidRow["start_price"];
        }

        file_put_contents("debug_log.txt", "Highest Bid: $highestBid\n", FILE_APPEND);
        echo json_encode(["highest_bid" => $highestBid]);
    } else {
        file_put_contents("debug_log.txt", "SQL Error: " . mysqli_error($conn) . "\n", FILE_APPEND);
        echo json_encode(["error" => "Database query failed"]);
    }
} else {
    file_put_contents("debug_log.txt", "Auction ID Not Provided.\n", FILE_APPEND);
    echo json_encode(["error" => "Auction ID not provided"]);
}
?>