<?php
require_once("../bridge.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $target_bid = $_POST["bid_id"];
    $qry = "SELECT * FROM bid where bid_id = $target_bid";
    $result = mysqli_query($connect, $qry);
    $row = mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result) > 0) {
        echo json_encode(array("status" => "success", "message" => "Got data..", "bid_id" => $row["bid_id"], "amount" => $row["bid_amount"]));
    } else {
        echo json_encode(array("status" => "error", "message" => "No data found"));
    }
}
?>