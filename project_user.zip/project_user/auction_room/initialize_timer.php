<?php
require_once("../bridge.php");
session_start();

if (isset($_SESSION['auction_id'])) {
    $auctionID = $_SESSION['auction_id'];

    $query = "SELECT auction_start, auction_end FROM auction WHERE auction_id = ?";
    $stmt = mysqli_prepare($connect, $query);
    mysqli_stmt_bind_param($stmt, "i", $auctionID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode(["success" => true, "auction_start" => $row["auction_start"], "auction_end" => $row["auction_end"]]);
    } else {
        echo json_encode(["success" => false, "message" => "Auction not found"]);
    }
    mysqli_stmt_close($stmt);
} else {
    echo json_encode(["success" => false, "message" => "Auction ID not provided"]);
}
?>
