<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sliding Number Animation</title>
  <style>
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
    }

    .counter {
      display: flex;
      font-size: 5rem;
      font-weight: bold;
      overflow: hidden;
      height: 100px; /* Matches the height of the digits */
    }

    .digit {
      position: relative;
      width: 60px; /* Adjust width for consistent alignment */
      text-align: center;
    }

    .digit span {
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      transform: translateY(0);
      transition: transform 0.3s ease-in-out;
    }

    .digit span.next {
      transform: translateY(100%); /* Start below the visible area */
    }

    .digit span.current {
      transform: translateY(0); /* Visible */
    }

    .digit span.old {
      transform: translateY(-100%); /* Move up out of view */
    }
  </style>
</head>
<body>
  <div class="counter" id="counter">
    <div class="digit">
      <span class="current">0</span>
      <span class="next">1</span>
    </div>
  </div>

  <script>
    let currentNumber = 0;

    function updateCounter() {
      const digitElement = document.querySelector(".digit");
      const currentSpan = digitElement.querySelector(".current");
      const nextSpan = digitElement.querySelector(".next");

      // Update the next number
      const nextNumber = (currentNumber + 1) % 10; // Limit to 0-9 for demo
      nextSpan.textContent = nextNumber;

      // Add animation classes
      currentSpan.classList.add("old");
      nextSpan.classList.add("current");

      // Reset the animation after it completes
      setTimeout(() => {
        currentSpan.classList.remove("current", "old");
        nextSpan.classList.remove("next");
        currentSpan.textContent = nextNumber;

        // Swap roles
        currentSpan.classList.add("next");
        nextSpan.classList.add("current");

        currentNumber = nextNumber;
      }, 300); // Matches the CSS transition time
    }

    // Update every second
    setInterval(updateCounter, 1000);
  </script>
</body>
</html>
