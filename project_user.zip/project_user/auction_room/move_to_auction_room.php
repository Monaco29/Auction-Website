<?php
require_once("../bridge.php");
session_start();

if (isset($_GET["item_id"])) {
    $buyer = $_SESSION["buyer_id"];
    $product = $_GET["item_id"];
    $auctionID = $_GET["auction_id"];

    if ($buyer && $product) {
        // Check if buyer is already registered in this auction
        $query = "SELECT * FROM auction_registration WHERE buyer_id = $buyer AND item_id = $product AND status = 'Approved'";
        $result = mysqli_query($connect, $query);

        if (mysqli_num_rows($result) > 0) {
            // Check if the buyer is already active in the auction
            $checkActive = "SELECT * FROM active_bidders WHERE buyer_id = $buyer AND auction_id = $auctionID";
            $activeResult = mysqli_query($connect, $checkActive);

            if (mysqli_num_rows($activeResult) == 0) {
                // Insert buyer into active bidders table
                $insertBuyer = "INSERT INTO active_bidders (buyer_id, auction_id) VALUES ($buyer, $auctionID)";
                mysqli_query($connect, $insertBuyer);
            }

            $_SESSION["item_id"] = $product;
            $_SESSION["auction_id"] = $auctionID;

            echo json_encode(['status' => 'success', 'message' => 'Welcome..']);
        } else {
            echo json_encode(['status' => 'failure', 'message' => 'Not allowed.!']);
        }
    } else {
        echo json_encode(['status' => 'failure', 'message' => 'Invalid request']);
    }
}
?>