<?php
require_once("../bridge.php");
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);


if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["bid_amount"])) {
    $buyerID = $_SESSION["buyer_id"];
    $auctionID = $_SESSION["auction_id"];
    $bidAmount = intval($_POST["bid_amount"]);

    // Fetch the current highest bid
    $query = "SELECT MAX(bid_amount) AS highest_bid FROM bid WHERE auction_id = $auctionID";
    $result = mysqli_query($connect, $query);
    $row = mysqli_fetch_assoc($result);

    // Fetch starting bid if no bids exist
    $currentHighestBid = $row["highest_bid"];
    if ($currentHighestBid === null) {
        $startingBidQuery = "SELECT start_price FROM item WHERE item_id = (SELECT item_id FROM auction WHERE auction_id = $auctionID)";
        $startingBidResult = mysqli_query($connect, $startingBidQuery);
        $startingBidRow = mysqli_fetch_assoc($startingBidResult);
        $currentHighestBid = $startingBidRow["start_price"];
    }

    // Validate the bid
    if ($bidAmount > $currentHighestBid) {
        // Insert the new bid into the database
        $insertBidQuery = "INSERT INTO bid (auction_id, buyer_id, bid_amount, bid_time) VALUES ($auctionID, $buyerID, $bidAmount, NOW())";
        if (mysqli_query($connect, $insertBidQuery)) {
            echo json_encode(["status" => "success", "message" => "Bid placed successfully!"]);
        } else {
            echo json_encode(["status" => "failure", "message" => "Error placing bid. Please try again."]);
        }
    } else {
        echo json_encode(["status" => "failure", "message" => "Your bid must be higher than the current highest bid of $" . $currentHighestBid]);
    }
} else {
    echo json_encode(["status" => "failure", "message" => "Invalid request."]);
}
?>