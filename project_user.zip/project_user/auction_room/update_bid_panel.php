<?php
require_once("../bridge.php");

if (isset($_GET['auction_id'])) {
    $auctionID = $_GET['auction_id'];

    // Query to check the highest bid
    $queryHighestBid = "
        SELECT 
            MAX(bid_amount) AS highest_bid
        FROM 
            bid
        WHERE 
            auction_id = ?
    ";

    $stmt = mysqli_prepare($connect, $queryHighestBid);
    mysqli_stmt_bind_param($stmt, "i", $auctionID); // Bind auction ID
    mysqli_stmt_execute($stmt); // Execute the query
    $resultHighestBid = mysqli_stmt_get_result($stmt);

    $rowHighestBid = mysqli_fetch_assoc($resultHighestBid);

    if ($rowHighestBid && $rowHighestBid["highest_bid"] !== null) {
        // Return the highest bid if exists
        echo json_encode([
            "success" => true,
            "bid_amount" => $rowHighestBid["highest_bid"]
        ]);
    } else {
        // No bids found; fetch the start_price of the auction
        $queryStartPrice = "SELECT a.start_price FROM item a JOIN auction b ON a.item_id = b.item_id WHERE b.auction_id = ?";
        $stmtStartPrice = mysqli_prepare($connect, $queryStartPrice);
        mysqli_stmt_bind_param($stmtStartPrice, "i", $auctionID);
        mysqli_stmt_execute($stmtStartPrice);
        $resultStartPrice = mysqli_stmt_get_result($stmtStartPrice);

        $rowStartPrice = mysqli_fetch_assoc($resultStartPrice);
        if ($rowStartPrice) {
            // Return the start price
            echo json_encode([
                "success" => true,
                "bid_amount" => $rowStartPrice["start_price"]
            ]);
        } else {
            // Failed to find start price
            echo json_encode(["success" => false, "message" => "No start price found for this auction."]);
        }
    }

    mysqli_stmt_close($stmt);
} else {
    echo json_encode(["success" => false, "message" => "Auction ID not provided."]);
}
?>
