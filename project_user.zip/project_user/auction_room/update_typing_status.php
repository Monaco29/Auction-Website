<?php
require_once("../bridge.php");

if (isset($_POST['buyer_id']) && isset($_POST['auction_id']) && isset($_POST['is_typing'])) {
    $buyerID = $_POST['buyer_id'];
    $auctionID = $_POST['auction_id'];
    $isTyping = $_POST['is_typing'];

    // Update the is_typing status in the database
    $query = "
        UPDATE active_bidders 
        SET is_typing = ? 
        WHERE buyer_id = ? AND auction_id = ?
    ";
    $stmt = mysqli_prepare($connect, $query);
    mysqli_stmt_bind_param($stmt, "iii", $isTyping, $buyerID, $auctionID);

    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(["success" => true, "message" => "Typing status updated successfully"]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to update typing status"]);
    }

    mysqli_stmt_close($stmt);
} else {
    echo json_encode(["success" => false, "message" => "Missing parameters"]);
}
?>
