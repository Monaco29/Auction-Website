<?php
require_once("../bridge.php");

if (isset($_GET['auction_id'])) {
    $auctionID = $_GET['auction_id'];

    // Query to fetch winner's username, bid amount, and profile picture
    $query = "
        select bi.bid_id, bi.bid_amount, u.username,u.user_id , u.profile_pic from bid bi join buyer b on bi.buyer_id = b.buyer_id join user u on u.user_id = b.user_id where bi.auction_id = ? order by bi.bid_amount desc limit 1";

    // Prepare the SQL statement
    $stmt = mysqli_prepare($connect, $query);
    mysqli_stmt_bind_param($stmt, "i", $auctionID); // Bind the auction ID
    mysqli_stmt_execute($stmt); // Execute the statement
    $result = mysqli_stmt_get_result($stmt); // Fetch the result
    if ($row = mysqli_fetch_assoc($result)) {
        $userIdd = $row["user_id"];
        $final_insert_qry = "INSERT INTO notification(user_id, message) VALUES($userIdd, '🎉 Victory is Yours! Congratulations on winning the auction! Your bid was unbeatable—enjoy your well-deserved win!')";
        $sub_results = mysqli_query($connect, $final_insert_qry);
        echo json_encode([
            "success" => true,
            "username" => $row["username"],
            "bid_amount" => $row["bid_amount"],
            "profile_pic" => $row["profile_pic"],
            "bid_id" => $row["bid_id"]
        ]);
    } else {
        // No winner data found
        echo json_encode(["success" => false, "message" => "No winner found for this auction."]);
    }

    mysqli_stmt_close($stmt); // Close the statement
} else {
    // Auction ID was not provided
    echo json_encode(["success" => false, "message" => "Auction ID not provided."]);
}
?>