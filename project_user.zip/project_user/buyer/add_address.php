<?php
require_once("../bridge.php");

session_start();
$user_id = $_SESSION['user_id'] ?? 1;

if (!$user_id) {
    echo "<script>alert('User not logged in'); window.location.href='login.php';</script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pincode = $_POST['pincode'];
    $country = $_POST['country'];

    $sql = "INSERT INTO user_address (user_id, address, city, state, pincode, country)
            VALUES ('$user_id', '$address', '$city', '$state', '$pincode', '$country')";

    if (mysqli_query($connect, $sql)) {
        echo "<script>alert('Address added successfully.'); window.location.href='my_addresses.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($connect) . "');</script>";
    }

    mysqli_close($connect);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add Address</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #2c3e50, #4ca1af);
            color: #fff;
            padding: 20px;
            min-height: 100vh;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        .card {
            background: rgba(255, 255, 255, 0.08);
            border: none;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.37);
            backdrop-filter: blur(10px);
            margin-bottom: 30px;
        }

        label {
            color: #ffffff;
            margin-bottom: 8px;
            display: block;
        }

        .form-control {
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            color: white;
            padding: 12px 15px;
            margin-bottom: 15px;
            width: 100%;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 0 5px #00c3ff;
            color: white;
        }

        .btn-primary {
            background: linear-gradient(90deg, #6a11cb, #2575fc);
            border: none;
            padding: 12px 25px;
            border-radius: 12px;
            font-weight: 600;
            width: 100%;
            margin-top: 10px;
        }

        .btn-primary:hover {
            background: linear-gradient(90deg, #2575fc, #6a11cb);
        }

        .btn-warning {
            margin-bottom: 20px;
            padding: 10px 20px;
        }

        h2 {
            color: #fff;
            font-weight: 600;
            margin-bottom: 25px;
            font-size: 28px;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            body {
                padding: 15px;
            }

            .container {
                padding: 10px;
            }

            .card {
                padding: 20px;
                border-radius: 15px;
            }

            h2 {
                font-size: 24px;
                margin-bottom: 20px;
            }

            .form-control {
                padding: 10px 12px;
            }
        }

        @media (max-width: 576px) {
            body {
                padding: 10px;
            }

            h2 {
                font-size: 22px;
            }

            .btn-primary {
                padding: 10px 20px;
            }

            .btn-warning {
                padding: 8px 15px;
                font-size: 14px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <a href="home.php" class="btn btn-warning mb-3">⬅ Back to Addresses</a>
        <h2>📦 Add New Delivery Address</h2>
        <div class="card mt-3">
            <form method="POST" action="">
                <div class="form-group">
                    <label for="address">Full Address</label>
                    <textarea class="form-control" name="address" id="address" required></textarea>
                </div>
                <div class="form-group">
                    <label for="city">City</label>
                    <input type="text" class="form-control" name="city" id="city" required>
                </div>
                <div class="form-group">
                    <label for="state">State</label>
                    <input type="text" class="form-control" name="state" id="state" required>
                </div>
                <div class="form-group">
                    <label for="pincode">Pincode</label>
                    <input type="text" class="form-control" name="pincode" id="pincode" required>
                </div>
                <div class="form-group">
                    <label for="country">Country</label>
                    <input type="text" class="form-control" name="country" id="country" value="India">
                </div>
                <button type="submit" class="btn btn-primary">➕ Add Address</button>
            </form>
        </div>
    </div>
</body>

</html>