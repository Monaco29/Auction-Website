<?php
session_start();
require_once("../bridge.php");
if (!isset($_SESSION["user_id"])) {
    header("Location: /project_user/user_login.php");
    exit();
}
$user_id = $_SESSION["user_id"];
$user_name = $_SESSION["username"];
$buyer_id = $_SESSION["buyer_id"];

$result = mysqli_query($connect, "SELECT * FROM user WHERE user_id = '$user_id'");
$data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .sidebar {
            height: 100vh;
            background-color: #343a40;
            color: white;
            padding-top: 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            transition: all 0.3s;
        }

        .profile-picture-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-pic {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin: 0 auto;
            border: 3px dashed rgb(100, 100, 100);
            padding: 5px;
        }

        .profile-pic img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .username {
            text-align: center;
            margin: 10px 0;
            font-family: cursive;
        }

        .divider {
            border-bottom: 2px solid #495057;
            margin: 10px 20px;
        }

        .sidebar a {
            color: white;
            display: block;
            padding: 10px;
            text-decoration: none;
            position: relative;
            transition: all 0.3s;
        }

        .sidebar a:hover {
            background-color: #495057;
            transform: translateX(10px);
        }

        .sidebar .icon {
            margin-right: 10px;
        }

        #header-username {
            margin-bottom: 10px;
        }

        .stats-box::-webkit-scrollbar {
            width: 8px;
        }

        .stats-box::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .stats-box::-webkit-scrollbar-thumb:hover {
            background-color: rgba(0, 0, 0, 0.2);
        }

        /* Responsive Sidebar */
        @media screen and (max-height: 450px) {
            .sidebar {
                padding-top: 15px;
            }

            .sidebar a {
                font-size: 16px;
            }
        }

        .main-content {
            margin-left: 220px;
            /* Adjust the margin to the width of the sidebar + some padding */
            padding: 20px;
            /* Add some padding for better spacing */
        }

        .second-row {
            margin-bottom: 20px;
        }

        .comprehensive-card {
            width: 100%;
            height: 300px;
            /* Adjust height as needed */
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th,
        table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .mini-pic {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 5px;
            border: 1px solid black;
        }

        /* Add these styles to your existing CSS */

        /* Medium devices (tablets, 768px and up) */
        @media (max-width: 992px) {
            .sidebar {
                width: 70px;
                overflow: hidden;
            }

            .sidebar:hover {
                width: 200px;
                z-index: 1000;
            }

            .sidebar a span {
                display: none;
            }

            .sidebar:hover a span {
                display: inline;
            }

            .profile-picture-container {
                display: none;
            }

            .sidebar:hover .profile-picture-container {
                display: block;
            }

            .main-content {
                margin-left: 90px;
            }

            table {
                font-size: 0.8rem;
            }

            .mini-pic {
                width: 30px;
                height: 30px;
            }
        }

        /* Small devices (landscape phones, 576px and up) */
        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                padding: 0;
            }

            .sidebar.active {
                width: 200px;
                z-index: 1000;
            }

            .main-content {
                margin-left: 20px;
            }

            .comprehensive-card {
                padding: 10px;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            /* Add hamburger menu for mobile */
            .mobile-menu-btn {
                display: block;
                position: fixed;
                top: 10px;
                left: 10px;
                z-index: 1100;
                background: #343a40;
                color: white;
                border: none;
                font-size: 1.5rem;
                padding: 5px 10px;
                border-radius: 5px;
            }
        }

        /* Extra small devices (portrait phones, less than 576px) */

        @media (max-width: 576px) {
            .package-details-table {
                display: block;
                width: 100%;
            }

            .package-details-table tbody,
            .package-details-table tr,
            .package-details-table th,
            .package-details-table td {
                display: block;
                width: 100%;
                box-sizing: border-box;
            }

            .package-details-table th {
                padding-bottom: 0;
                padding-top: 15px;
                background-color: transparent;
                font-weight: bold;
                color: #333;
            }

            .package-details-table td {
                padding-top: 5px;
                padding-bottom: 10px;
            }

            .package-details-table tr {
                border-bottom: 1px solid #e0e0e0;
                padding: 5px 0;
            }

            .package-details-table tr:last-child {
                border-bottom: none;
            }
        }
    </style>
</head>

<body>
    <button class="mobile-menu-btn" id="mobileMenuBtn">
        <i class="fas fa-bars"></i>
    </button>

    <script>
        document.getElementById('mobileMenuBtn').addEventListener('click', function () {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    </script>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="text-center profile-picture-container">
            <div class="profile-pic">
                <img src="/final_sem_project/uploaded_images/<?= $data["profile_pic"]; ?>" alt="No img">
            </div>
            <div class="username"><?= $data["username"]; ?></div>
            <div class="divider"></div>
        </div>
        <a href="home.php"><i class="fas fa-home icon"></i>Home</a>
        <a href="auction_history.php"><i class="fas fa-box-open icon"></i>Auction history</a>
        <a href="../logout.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="second-row">
            <div class="comprehensive-card">
                <h3>Participated auctions</h3>
                <table>
                    <thead>
                        <tr>
                            <th>AuctionId</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Item</th>
                            <th>StartDate</th>
                            <th>EndDate</th>
                            <th>SellerId</th>
                            <th>Seller</th>
                            <th>Category</th>
                            <th>StartPrice</th>
                            <th>FinalPrice</th>
                            <th>Picture</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = mysqli_query($connect, "SELECT a.name AS item_name, a.picture, a.start_price, a.end_price, b.auction_id,b. seller_id, b.auction_start, b.auction_end, b.title, b.description, d.username, f.name AS Category_name FROM item a INNER JOIN auction b ON a.item_id = b.item_id INNER JOIN seller c ON b.seller_id = c.seller_id INNER JOIN user d ON c.user_id = d.user_id INNER JOIN buyer e ON e.buyer_id = $buyer_id INNER JOIN category f ON b.category_id = f.category_id WHERE b.status = 'Closed'");
                        if (mysqli_num_rows($result) > 0) {
                            while ($data = mysqli_fetch_assoc($result)) {
                                echo "<tr>
                                            <td>" . $data["auction_id"] . "</td>
                                            <td>" . $data["title"] . "</td>
                                            <td>" . $data["description"] . "</td>
                                            <td>" . $data["item_name"] . "</td>
                                            <td>" . $data["auction_start"] . "</td>
                                            <td>" . $data["auction_end"] . "</td>
                                            <td>" . $data["seller_id"] . "</td>
                                            <td>" . $data["username"] . "</td>
                                            <td>" . $data["Category_name"] . "</td>
                                            <td>" . $data["start_price"] . "</td>
                                            <td>" . $data["end_price"] . "</td>
                                            <td><img src='../../final_sem_project/uploaded_images/" . $data["picture"] . "' alt='NoImg' class='mini-pic'></td>
                                        </tr>";
                            }
                        } else {
                            echo "<tr>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Second table -->
    <div class="main-content">
        <!-- Second Row -->
        <div class="second-row">
            <div class="comprehensive-card">
                <h3>Ongoing auctions</h3>
                <table>
                    <thead>
                        <tr>
                            <th>AuctionId</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Item</th>
                            <th>StartDate</th>
                            <th>EndDate</th>
                            <th>SellerId</th>
                            <th>Seller</th>
                            <th>Category</th>
                            <th>StartPrice</th>
                            <th>Picture</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = mysqli_query($connect, "SELECT a.name AS item_name, a.picture, a.start_price, b.auction_id,b. seller_id, b.auction_start, b.auction_end, b.title, b.description, d.username, f.name AS Category_name FROM item a INNER JOIN auction b ON a.item_id = b.item_id INNER JOIN seller c ON b.seller_id = c.seller_id INNER JOIN user d ON c.user_id = d.user_id INNER JOIN buyer e ON e.buyer_id = $buyer_id INNER JOIN category f ON b.category_id = f.category_id WHERE b.status = 'OnGoing'");
                        if (mysqli_num_rows($result) > 0) {
                            while ($data = mysqli_fetch_assoc($result)) {
                                echo "<tr>
                                            <td>" . $data["auction_id"] . "</td>
                                            <td>" . $data["title"] . "</td>
                                            <td>" . $data["description"] . "</td>
                                            <td>" . $data["item_name"] . "</td>
                                            <td>" . $data["auction_start"] . "</td>
                                            <td>" . $data["auction_end"] . "</td>
                                            <td>" . $data["seller_id"] . "</td>
                                            <td>" . $data["username"] . "</td>
                                            <td>" . $data["Category_name"] . "</td>
                                            <td>" . $data["start_price"] . "</td>
                                            <td><img src='../../final_sem_project/uploaded_images/" . $data["picture"] . "' alt='NoImg' class='mini-pic'></td>
                                        </tr>";
                            }
                        } else {
                            echo "<tr>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Third table  -->
    <div class="main-content">
        <!-- Second Row -->
        <div class="second-row">
            <div class="comprehensive-card">
                <h3>Upcoming auctions</h3>
                <table>
                    <thead>
                        <tr>
                            <th>AuctionId</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Item</th>
                            <th>StartDate</th>
                            <th>EndDate</th>
                            <th>SellerId</th>
                            <th>Seller</th>
                            <th>Category</th>
                            <th>StartPrice</th>
                            <th>Picture</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = mysqli_query($connect, "SELECT a.name AS item_name, a.picture, a.start_price, b.auction_id,b. seller_id, b.auction_start, b.auction_end, b.title, b.description, d.username, f.name AS Category_name FROM item a INNER JOIN auction b ON a.item_id = b.item_id INNER JOIN seller c ON b.seller_id = c.seller_id INNER JOIN user d ON c.user_id = d.user_id INNER JOIN buyer e ON e.buyer_id = $buyer_id INNER JOIN category f ON b.category_id = f.category_id WHERE b.status = 'Upcoming'");
                        if (mysqli_num_rows($result) > 0) {
                            while ($data = mysqli_fetch_assoc($result)) {
                                echo "<tr>
                                            <td>" . $data["auction_id"] . "</td>
                                            <td>" . $data["title"] . "</td>
                                            <td>" . $data["description"] . "</td>
                                            <td>" . $data["item_name"] . "</td>
                                            <td>" . $data["auction_start"] . "</td>
                                            <td>" . $data["auction_end"] . "</td>
                                            <td>" . $data["seller_id"] . "</td>
                                            <td>" . $data["username"] . "</td>
                                            <td>" . $data["Category_name"] . "</td>
                                            <td>" . $data["start_price"] . "</td>
                                            <td><img src='../../final_sem_project/uploaded_images/" . $data["picture"] . "' alt='NoImg' class='mini-pic'></td>
                                        </tr>";
                            }
                        } else {
                            echo "<tr>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    <td>❗</td>
                                    </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>