<?php
    session_start();
    require_once("../bridge.php");

    $user_id = $_SESSION["user_id"];
    $buyer_id = $_SESSION["buyer_id"];
    $result = mysqli_query($connect, "SELECT a.* FROM notification a INNER JOIN buyer b ON a.user_id = b.user_id WHERE b.buyer_id = $buyer_id ORDER BY a.notification_id DESC");

    $notifications = array();
    if(mysqli_num_rows($result) > 0)
    {
        while($data = mysqli_fetch_assoc($result))
        {
            $notifications[] = $data;
        }
    }
    echo json_encode($notifications);
    mysqli_close($connect);
?>