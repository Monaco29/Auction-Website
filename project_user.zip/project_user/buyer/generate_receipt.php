<?php
require_once("../bridge.php");
$auction_id = $_GET["auction_id"];
$qry = "select a.bid_id, a.bid_amount,b.amount,c.* from bid a join transections b on a.bid_id = b.bid_id join invoice c on b.transection_id = c.transaction_id where a.has_won = 1 and a.auction_id = $auction_id";
$result = mysqli_query($connect, $qry);
$row = mysqli_fetch_assoc($result);

$bid_id = $row["bid_id"];
$bid_amount = $row["bid_amount"];
$transection_id = $row["transaction_id"];
$buyer_id = $row["buyer_id"];
$seller_id = $row["seller_id"];

$seller_details = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM seller WHERE seller_id = $seller_id"));
$buyer_details = mysqli_fetch_assoc(mysqli_query($connect, "SELECT a.*,b.username,b.email, b.contect_number FROM user_address a JOIN user b ON a.user_id = b.user_id JOIN buyer c ON c.user_id = b.user_id WHERE c.buyer_id = $buyer_id"));
$item_details = mysqli_fetch_assoc(mysqli_query($connect, "SELECT a.* FROM item a JOIN auction b ON a.item_id = b.item_id WHERE b.auction_id = $auction_id"));

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&amp;display=swap" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 15px;
            flex-direction: column;
        }

        :root {
            --blue-color: #0c2f54;
            --dark-color: #535b61;
            --white-color: #fff;
        }

        ul {
            list-style-type: none;
        }

        ul li {
            margin: 2px 0;
        }

        /* text colors */
        .text-dark {
            color: var(--dark-color);
        }

        .text-blue {
            color: var(--blue-color);
        }

        .text-end {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .text-start {
            text-align: left;
        }

        .text-bold {
            font-weight: 700;
        }

        /* hr line */
        .hr {
            height: 1px;
            background-color: rgba(0, 0, 0, 0.1);
        }

        /* border-bottom */
        .border-bottom {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }


        .invoice-wrapper {
            min-height: 100vh;
            padding-top: 20px;
            padding-bottom: 20px;
        }

        .invoice {
            max-width: 850px;
            margin-right: auto;
            margin-left: auto;
            background-color: var(--white-color);
            padding: 70px;
            border: 1px solid rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            min-height: 920px;
        }

        .invoice-head-top-left img {
            width: 130px;
        }

        .invoice-head-top-right h3 {
            font-weight: 500;
            font-size: 27px;
            color: var(--blue-color);
        }

        .invoice-head-middle,
        .invoice-head-bottom {
            padding: 16px 0;
        }

        .invoice-body {
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 4px;
            overflow: hidden;
        }

        .invoice-body table {
            border-collapse: collapse;
            border-radius: 4px;
            width: 100%;
        }

        .invoice-body table td,
        .invoice-body table th {
            padding: 12px;
        }

        .invoice-body table tr {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        .invoice-body table thead {
            background-color: rgba(0, 0, 0, 0.02);
        }

        .invoice-body-info-item {
            display: grid;
            grid-template-columns: 80% 20%;
        }

        .invoice-body-info-item .info-item-td {
            padding: 12px;
            background-color: rgba(0, 0, 0, 0.02);
        }

        .invoice-foot {
            padding: 30px 0;
        }

        .invoice-foot p {
            font-size: 12px;
        }

        .invoice-btns {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }

        .invoice-btn {
            padding: 3px 9px;
            color: var(--dark-color);
            font-family: inherit;
            border: 1px solid rgba(0, 0, 0, 0.1);
            cursor: pointer;
        }

        .invoice-head-top,
        .invoice-head-middle,
        .invoice-head-bottom {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            padding-bottom: 10px;
        }

        @media screen and (max-width: 992px) {
            .invoice {
                padding: 40px;
            }
        }

        @media screen and (max-width: 576px) {

            .invoice-head-top,
            .invoice-head-middle,
            .invoice-head-bottom {
                grid-template-columns: repeat(1, 1fr);
            }

            .invoice-head-bottom-right {
                margin-top: 12px;
                margin-bottom: 12px;
            }

            .invoice * {
                text-align: left;
            }

            .invoice {
                padding: 28px;
            }
        }

        .overflow-view {
            overflow-x: scroll;
        }

        .invoice-body {
            min-width: 600px;
        }

        @media print {
            .print-area {
                visibility: visible;
                width: 100%;
                position: absolute;
                left: 0;
                top: 0;
                overflow: hidden;
            }

            .overflow-view {
                overflow-x: hidden;
            }

            .invoice-btns {
                display: none;
            }
        }

        .custom-button {
            width: 40%;
            padding: 12px;
            font-size: 1rem;
            font-weight: bold;
            font-family: 'Poppins', sans-serif;
            border-radius: 8px;
            cursor: pointer;
            color: white;
            /* Button text color */
            border: 2px solidrgb(255, 255, 255);
            /* Blue border */
            background: #007bff;
            /* Blue background */
            margin-top: 20px;
            /* Space between buttons */
            transition: all 0.3s ease-in-out;
            /* Smooth hover effects */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            /* Subtle shadow */
        }

        /* Hover Effect */
        .custom-button:hover {
            background: white;
            /* Invert colors on hover */
            color: #007bff;
            /* Blue text on hover */
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            /* Enhance shadow on hover */
        }

        /* Active Effect */
        .custom-button:active {
            background: #0056b3;
            /* Darker blue when clicked */
            color: white;
            transform: scale(0.98);
            /* Slightly shrink the button */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            /* Reduce shadow */
        }

        .business-name {
            font-size: 36px;
            font-weight: bold;
            color: #4A90E2;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-family: "Poetsen One", sans-serif;
            font-weight: 400;
            font-style: normal;
        }
    </style>
</head>

<body>
    <div class="invoice-wrapper" id="print-area">
        <div class="invoice">
            <div class="invoice-container">
                <div class="invoice-head">
                    <div class="invoice-head-top">
                        <div class="invoice-head-top-left text-start">
                            <div class="business-name"><?= $seller_details["business_name"]; ?></div>
                        </div>
                        <div class="invoice-head-top-right text-end">
                            <h3>Invoice</h3>
                        </div>
                    </div>
                    <div class="hr"></div>
                    <div class="invoice-head-middle">
                        <div class="invoice-head-middle-left text-start">
                            <p><span class="text-bold">Date: </span><?= $row["invoice_date"]; ?></p>
                        </div>
                        <div class="invoice-head-middle-right text-end">
                            <p>
                                <spanf class="text-bold">Invoice No: </span><?= $row["invoice_id"]; ?>
                            </p>
                        </div>
                    </div>
                    <div class="hr"></div>
                    <div class="invoice-head-bottom">
                        <div class="invoice-head-bottom-left">
                            <ul>
                                <li class='text-bold'>Invoiced To:</li>
                                <li><?= $buyer_details["username"]; ?></li>
                                <li><?= $buyer_details["address"]; ?></li>
                                <li><?= $buyer_details["city"]; ?> : <?= $buyer_details["pincode"]; ?></li>
                                <li><?= $buyer_details["state"]; ?>, <?= $buyer_details["country"]; ?></li>
                                <li><?= $buyer_details["email"]; ?>, <?= $buyer_details["contect_number"]; ?></li>
                            </ul>
                        </div>
                        <div class="invoice-head-bottom-right">
                            <ul class="text-end">
                                <li class='text-bold'>Pay To:</li>
                                <li><?= $seller_details["business_name"]; ?></li>
                                <li><?= $seller_details["business_address"]; ?></li>
                                <li><?= $seller_details["business_email"]; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="overflow-view">
                    <div class="invoice-body">
                        <table>
                            <thead>
                                <tr>
                                    <td class="text-bold">Invoice number</td>
                                    <td class="text-bold">Name</td>
                                    <td class="text-bold">QTY</td>
                                    <td class="text-bold">Amount</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?= $row["invoice_id"]; ?></td>
                                    <td><?= $item_details["name"]; ?></td>
                                    <td>1</td>
                                    <td><?= $row["bid_amount"]; ?></td>
                                </tr>

                            </tbody>
                        </table>
                        <div class="invoice-body-bottom">
                            <div class="invoice-body-info-item border-bottom">
                                <div class="info-item-td text-end text-bold">Sub Total:</div>
                                <div class="info-item-td text-end"><?= $row["bid_amount"]; ?></div>
                            </div>
                            <div class="invoice-body-info-item border-bottom">
                                <div class="info-item-td text-end text-bold">GST(18%):</div>
                                <div class="info-item-td text-end"><?= $row["bid_amount"] * 0.18; ?></div>
                            </div>
                            <div class="invoice-body-info-item border-bottom">
                                <div class="info-item-td text-end text-bold">Pltform Charge(4%):</div>
                                <div class="info-item-td text-end"><?= $row["bid_amount"] * 0.04; ?></div>
                            </div>
                            <div class="invoice-body-info-item">
                                <div class="info-item-td text-end text-bold">Total:</div>
                                <div class="info-item-td text-end"><?= $row["amount"]; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="invoice-foot text-center">
                    <p><span class="text-bold text-center">NOTE:&nbsp;</span>This is computer generated receipt and does
                        not require physical signature.</p>

                    <div class="invoice-btns">
                        <button type="button" class="invoice-btn custom-button" onclick="downloadInvoice()">
                            <span>
                                <i class="fa-solid fa-print"></i>
                            </span>
                            <span>🖨️ or 📁</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function downloadInvoice() {
            const element = document.getElementById('print-area');
            let ele =  document.getElementsByClassName("invoice-btns")[0].style.display = 'none';
            var opt = {
                margin: 0.5,
                filename: 'invoice_<?= $buyer_id; ?>.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }
    </script>
</body>

</html>