<?php
require_once("../bridge.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $trackingNumber = $_POST['trackingNumber'];

    $sql = "SELECT * FROM delivery_tracking WHERE tracking_number = '" . mysqli_real_escape_string($connect, $trackingNumber) . "'";
    $result = mysqli_query($connect, $sql);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        $today = date_create(date('Y-m-d'));
        $delivery_date = date_create($row['estimated_delivery_date']);
        $diff = date_diff($today, $delivery_date);
        $days_left = (int) $diff->format("%R%a");

        mysqli_free_result($result);

        header('Content-Type: application/json');
        echo json_encode(['delivery_id' => $row['delivery_id'],
                                 'shipping_address' => $row['shipping_address'],
                                 'city' => $row['city'],
                                 'state' => $row['state'],
                                 'pincode' => $row['pincode'],
                                 'country' => $row['country'],
                                 'current_status' => $row['current_status'],
                                 'tracking_details' => $row['tracking_details'],
                                 'estimated_delivery_date' => $row['estimated_delivery_date'],
                                 'updated_at' => $row['updated_at'],
                                 'tracking_number' => $row['tracking_number'],
                                 'courier_name' => $row['courier_name'],
                                 'days_left' => $days_left]);
    } else {
        echo json_encode(["error" => "Error: " . mysqli_error($connect)]);
    }

    // Close connection
    mysqli_close($connect);
}
?>