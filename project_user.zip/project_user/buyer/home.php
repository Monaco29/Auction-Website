<?php
session_start();
require_once("../bridge.php");
if (!isset($_SESSION["user_id"])) {
    header("Location: /project_user/user_login.php");
    exit();
}
$user_id = $_SESSION["user_id"];
$user_name = $_SESSION["username"];
$buyer_id = $_SESSION["buyer_id"];

$result = mysqli_query($connect, "SELECT * FROM user u JOIN buyer s ON s.user_id = u.user_id WHERE s.buyer_id = $buyer_id");
$data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playwrite+IN:wght@100..400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&family=Playwrite+IN:wght@100..400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&family=Playwrite+IN:wght@100..400&family=Playwrite+VN:wght@100..400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap');

        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .sidebar {
            height: 100vh;
            background-color: #343a40;
            color: white;
            padding-top: 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            transition: all 0.3s;
        }

        .profile-pic {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin: 0 auto;
            border: 3px dashed rgb(100, 100, 100);
            padding: 5px;
        }

        .profile-pic img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .profile-pic-2 {
            width: 250px;
            height: 250px;
            border-radius: 50%;
            margin: 0 50px;
            border: 5px solid rgb(227, 12, 255);
            padding: 10px;
        }

        .profile-pic-2 img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .username {
            text-align: center;
            margin: 10px 0;
            font-family: cursive;
        }

        .divider {
            border-bottom: 2px solid #495057;
            margin: 10px 20px;
        }

        .sidebar a {
            color: white;
            display: block;
            padding: 10px;
            text-decoration: none;
            position: relative;
            transition: all 0.3s;
        }

        .sidebar a:hover {
            background-color: #495057;
            transform: translateX(10px);
        }

        .sidebar .icon {
            margin-right: 10px;
        }

        .content {
            margin-left: 200px;
            padding: 20px;
        }

        .welcome-message {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            font-family: cursive;
        }

        .user-card {
            display: flex;
            align-items: center;
            justify-content: space-evenly;
            flex-direction: row;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .profile-pic-container {
            flex: 0 0 100px;
        }

        .vertical-line {
            border-left: 2px solid rgb(138, 138, 138);
            height: 240px;
            margin: 0 90px;
            flex: 0 0 2px;
        }

        .user-info {
            flex: 1;
            padding-left: 20px;
            font-family: 'Verdana', sans-serif;
        }

        .user-card h2 {
            font-size: 28px;
            font-weight: bold;
            font-family: "Playwrite IN", serif;
        }

        #header-username {
            margin-bottom: 10px;
        }

        .user-card p {
            font-size: 16px;
            margin: 5px 0;
            font-family: 'Courier New', monospace;
        }

        strong {
            font-weight: 100;
            font-family: "Pacifico", serif;
        }

        /* First row -------------------------------- */
        .first-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .left-box,
        .right-box {
            width: 48%;
            height: 370px;
            /* Adjust height as needed */
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th,
        table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        img {
            width: 50px;
            /* Adjust the width */
            height: 50px;
            /* Adjust the height */
            object-fit: cover;
            /* Ensures the image covers the entire area without distorting */
            border-radius: 5px;
            /* Adds a slight corner radius for rounded edges */
            border: 1px solid #ddd;
            /* Adds a border around the image */
        }

        /* Notification panel ----------------------------- */
        .notification-panel {
            width: 48%;
            height: 550px;
            /* Adjust height as needed */
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: white;
            padding: 20px;
            /* Added padding */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .notification-box {
            display: flex;
            flex-direction: column;
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #fff;
            position: relative;
            /* Ensure icon is positioned correctly */
        }

        .tickmark {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 18px;
            color: gray;
            /* Default color for unread notifications */
        }

        .read .tickmark {
            color: blue;
            /* Color for read notifications */
        }


        .notification-box:last-child {
            border-bottom: none;
        }

        .notification-title {
            font-weight: bold;
            font-family: 'Arial', sans-serif;
            font-size: 18px;
            margin: 0;
        }

        .notification-message {
            margin: 10px 0;
            font-size: 16px;
        }

        .notification-time {
            font-size: 12px;
            color: grey;
            position: absolute;
            bottom: 5px;
            right: 10px;
        }

        .notification-panel::-webkit-scrollbar {
            width: 8px;
        }

        .notification-panel::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .notification-panel::-webkit-scrollbar-thumb:hover {
            background-color: rgba(0, 0, 0, 0.2);
        }

        .bottom-sentiel {
            height: 1px;
        }

        .custom-button {
            width: 60%;
            padding: 5px;
            font-size: 13px;
            font-weight: bold;
            font-family: 'Poppins', sans-serif;
            border-radius: 8px;
            cursor: pointer;
            color: white;
            border: 2px solid #007bff;
            background: #007bff;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .custom-button:hover {
            background: white;
            color: #007bff;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .custom-button:active {
            background: #0056b3;
            color: white;
            transform: scale(0.98);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        #target_hyper {
            color: white;
            text-decoration: none;
        }

        #target_hyper:hover {
            color: blue;
        }

        /* Responsive Media Queries */
        /* Enhanced Responsive Media Queries */
        @media (max-width: 1200px) {
            .first-row {
                flex-wrap: wrap;
            }

            .left-box,
            .right-box,
            .notification-panel {
                width: 100%;
                margin-bottom: 20px;
            }

            .profile-pic-2 {
                width: 200px;
                height: 200px;
                margin: 0 30px;
            }

            .vertical-line {
                height: 200px;
                margin: 0 50px;
            }
        }

        @media (max-width: 992px) {
            .sidebar {
                width: 180px;
                padding-top: 15px;
            }

            .content {
                margin-left: 180px;
                padding: 15px;
            }

            .user-card {
                flex-direction: column;
                text-align: center;
                padding: 15px;
            }

            .vertical-line {
                display: none;
            }

            .profile-pic-container {
                margin-bottom: 20px;
            }

            .user-info {
                padding-left: 0;
                text-align: center;
            }

            .welcome-message {
                font-size: 22px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding: 15px 0;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }

            .profile-pic {
                width: 70px;
                height: 70px;
                margin-bottom: 10px;
            }

            .username {
                width: 100%;
                text-align: center;
            }

            .divider {
                width: 80%;
                margin: 10px auto;
            }

            .sidebar a {
                display: inline-block;
                padding: 8px 12px;
                margin: 5px;
                background-color: #495057;
                border-radius: 5px;
                font-size: 14px;
            }

            .sidebar a:hover {
                transform: none;
                background-color: #5a6268;
            }

            .content {
                margin-left: 0;
                padding: 15px;
            }

            .profile-pic-2 {
                width: 150px;
                height: 150px;
                margin: 0 auto 20px;
                border-width: 3px;
            }

            .user-card h2 {
                font-size: 24px;
            }

            table {
                display: block;
                overflow-x: auto;
                white-space: nowrap;
            }

            .first-row {
                gap: 15px;
            }

            .notification-panel {
                height: auto;
                max-height: 400px;
            }
        }

        @media (max-width: 576px) {
            .welcome-message {
                font-size: 20px;
                text-align: center;
            }

            .profile-pic-2 {
                width: 120px;
                height: 120px;
            }

            .user-card h2 {
                font-size: 20px;
            }

            .user-card p {
                font-size: 14px;
            }

            .sidebar a {
                font-size: 13px;
                padding: 6px 10px;
                margin: 3px;
            }

            .left-box,
            .right-box,
            .notification-panel {
                padding: 12px;
                height: auto;
                max-height: 350px;
            }

            table th,
            table td {
                padding: 6px;
                font-size: 13px;
            }

            .custom-button {
                width: 80%;
                padding: 4px;
                font-size: 12px;
            }

            .notification-title {
                font-size: 16px;
            }

            .notification-message {
                font-size: 14px;
            }
        }

        /* Mobile Landscape and Smaller Phones */
        @media (max-width: 480px) {
            .sidebar {
                padding: 10px 0;
            }

            .sidebar a {
                font-size: 12px;
                padding: 5px 8px;
            }

            .profile-pic {
                width: 60px;
                height: 60px;
            }

            .welcome-message {
                font-size: 18px;
            }

            .user-card {
                padding: 10px;
            }

            .profile-pic-2 {
                width: 100px;
                height: 100px;
            }

            .left-box,
            .right-box,
            .notification-panel {
                padding: 10px;
            }

            table th,
            table td {
                padding: 4px;
                font-size: 12px;
            }

            .custom-button {
                width: 90%;
                font-size: 11px;
            }
        }

        /* Very Small Devices (e.g., iPhone 5/SE) */
        @media (max-width: 320px) {
            .sidebar a {
                font-size: 11px;
                padding: 4px 6px;
            }

            .welcome-message {
                font-size: 16px;
            }

            .user-card h2 {
                font-size: 18px;
            }

            .profile-pic-2 {
                width: 80px;
                height: 80px;
            }

            table th,
            table td {
                font-size: 11px;
            }
        }
    </style>
</head>

<body>
    <div class="d-flex">
        <div class="sidebar">
            <div class="text-center">
                <div class="profile-pic">
                    <img src="/final_sem_project/uploaded_images/<?= $data["profile_pic"]; ?>" alt="No img">
                </div>
                <div class="username"><?= $data["username"]; ?></div>
                <div class="divider"></div>
            </div>
            <a href="../home.php"><i class="fas fa-box-open icon"></i>Main Page</a>
            <a href="home.php"><i class="fas fa-home icon"></i>Home</a>
            <a href="auction_history.php"><i class="fas fa-box-open icon"></i>Auction history</a>
            <a href="add_address.php"><i class="fas fa-box-open icon"></i>Add address</a>
            <a href="shipment_tracker.php"><i class="fas fa-box-open icon"></i>Track package</a>
            <a href="../logout.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
        </div>
        <div class="content container-fluid">
            <div class="welcome-message">
                Welcome, <?= $data["username"]; ?>! We're so happy to have you here. 😊
            </div>
            <div class="card user-card">
                <div class="profile-pic-container">
                    <div class="profile-pic-2">
                        <img src="/final_sem_project/uploaded_images/<?= $data["profile_pic"]; ?>" alt="No img">
                    </div>
                </div>
                <div class="vertical-line"></div>
                <div class="user-info">
                    <h2 id="header-username"><?= $data["username"]; ?></h2>
                    <p><strong>Email:</strong> <?= $data["email"]; ?></p>
                    <p><strong>Address:</strong> <?= $data["address"]; ?></p>
                    <p><strong>Contact Number:</strong> <?= $data["contect_number"]; ?></p>
                    <p><strong>Role:</strong> <?= $data["role"]; ?></p>
                </div>
            </div>

            <!-- First Row -->
            <div class="first-row">
                <div class="left-box">
                    <h3>Purchasing History</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Date</th>
                                <th>Amount(₹)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = mysqli_query($connect, "SELECT * FROM transections WHERE buyer_id = $buyer_id");
                            if (mysqli_num_rows($result) > 0) {
                                while ($data = mysqli_fetch_assoc($result)) {
                                    echo "<tr>
                                                <td>" . $data["transection_id"] . "</td>
                                                <td>" . $data["transection_date"] . "</td>
                                                <td>" . $data["amount"] . "</td>
                                            </tr>";
                                }
                            } else {
                                echo "<tr>
                                                <td>❗</td>
                                                <td>❗</td>
                                                <td>❗</td>
                                            </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="right-box">
                    <h3>Transection history</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Auction ID</th>
                                <th>Amount</th>
                                <th>Title</th>
                                <th>GetReceipt</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $result = mysqli_query($connect, "SELECT * FROM bid WHERE buyer_id = $buyer_id AND has_won = 1");
                            if (mysqli_num_rows($result) > 0) {
                                while ($data = mysqli_fetch_assoc($result)) {
                                    $auctionID = $data["auction_id"];
                                    $subResult = mysqli_query($connect, "SELECT title FROM auction WHERE auction_id = $auctionID");
                                    $subResultrow = mysqli_fetch_assoc($subResult);
                                    echo "<tr>
                                        <td>" . $auctionID . "</td>
                                        <td>" . $data["bid_amount"] . "</td>
                                        <td>" . $subResultrow["title"] . "</td>
                                        <td><button class='custom-button'><a href='generate_receipt.php?auction_id=" . $auctionID . "' id='target_hyper'>Get</a></button></td>
                                    </tr>";
                                }
                            } else {
                                echo "<tr>
                                        <td>❗</td>
                                        <td>❗</td>
                                        <td>❗</td>
                                        <td>❗</td>
                                        <td>❗</td>
                                    </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Notification Panel -->
            <div class="notification-panel" id="notification-panel">
                <h3>Notifications</h3>
                <div class="notification-container">
                </div>
                <div class="bottom-sentinel"></div>
                <!-- Additional notification boxes will go here -->
            </div>


        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            console.log("DOM fully loaded and parsed");

            // Fetch and render notifications when the page loads
            fetchNotifications();

            // Create an IntersectionObserver to detect the bottom of the page
            const observer = new IntersectionObserver(handleIntersect, {
                root: null,
                rootMargin: '0px',
                threshold: 1.0
            });

            // Observe the bottom sentinel
            const sentinel = document.querySelector('.bottom-sentinel');
            if (sentinel) {
                observer.observe(sentinel);
            }
        });

        async function fetchNotifications() {
            try {
                const response = await fetch('fetch_notifications.php');
                const notifications = await response.json();
                renderNotifications(notifications);
            } catch (error) {
                console.error('Error fetching notifications:', error);
            }
        }

        function renderNotifications(notifications) {
            const notificationContainer = document.querySelector('.notification-container');
            notificationContainer.innerHTML = ''; // Clear previous notifications

            notifications.forEach(notification => {
                const notificationBox = document.createElement('div');
                notificationBox.className = 'notification-box';
                notificationBox.dataset.id = notification.notification_id;
                notificationBox.dataset.read = notification.is_read ? 'true' : 'false';
                if (notification.is_read === '1') {
                    notificationBox.classList.add('read');
                }
                notificationBox.innerHTML = `
            <p class="notification-title">${notification.message}</p>
            <span class="notification-time">${new Date(notification.sent_time).toLocaleTimeString()}</span>
            <i class="fas fa-check tickmark"></i> <!-- Tickmark icon -->
        `;

                notificationContainer.appendChild(notificationBox);
            });

            console.log("Notifications rendered");
        }

        function handleIntersect(entries, observer) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Delay of 3 seconds before marking notifications as read
                    setTimeout(() => {
                        markAllNotificationsAsRead();
                    }, 3000); // 3-second delay
                }
            });
        }

        function markAllNotificationsAsRead() {
            const notifications = document.querySelectorAll('.notification-box[data-read="false"]');
            notifications.forEach(notification => {
                notification.dataset.read = 'true';
                notification.classList.add('read');
                notification.querySelector('.tickmark').classList.add('read');
            });

            // Send AJAX request to update notifications in the database
            updateNotificationsInDatabase();
        }

        async function updateNotificationsInDatabase() {
            try {
                const response = await fetch('update_notifications.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    }
                });
                const result = await response.json();
                if (result.status === 'success') {
                    console.log("All unread notifications marked as read in the database.");
                } else {
                    console.error("Failed to update notifications in the database.");
                }
            } catch (error) {
                console.error('Error updating notifications in the database:', error);
            }
        }
    </script>
</body>

</html>