<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Package Tracker</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --dark-color: #2c3e50;
            --light-color: #ecf0f1;
        }

        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .tracker-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 3rem 0;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }

        .tracker-header::after {
            content: '';
            position: absolute;
            bottom: -50px;
            left: 0;
            right: 0;
            height: 50px;
            background-color: #f8f9fa;
            clip-path: polygon(0 0, 100% 0, 100% 20%, 0 100%);
        }

        .tracking-card {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border: none;
            overflow: hidden;
            transition: transform 0.3s ease;
            margin-bottom: 2rem;
        }

        .tracking-card:hover {
            transform: translateY(-5px);
        }

        .tracking-input-group {
            position: relative;
            max-width: 600px;
            margin: 0 auto;
        }

        .tracking-input {
            height: 60px;
            border-radius: 30px !important;
            padding-left: 30px;
            font-size: 1.1rem;
            border: 2px solid #ddd;
            transition: all 0.3s ease;
        }

        .tracking-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }

        .tracking-btn {
            position: absolute;
            right: 5px;
            top: 5px;
            height: 50px;
            width: 120px;
            border-radius: 25px !important;
            font-weight: 600;
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            border: none;
            transition: all 0.3s ease;
        }

        .tracking-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(46, 204, 113, 0.4);
        }

        .status-timeline {
            position: relative;
            padding-left: 50px;
            margin-top: 2rem;
        }

        .status-timeline::before {
            content: '';
            position: absolute;
            left: 24px;
            top: 0;
            bottom: 0;
            width: 3px;
            background-color: var(--secondary-color);
            /* Entire line is green */
            z-index: 0;
        }

        /* Gray line that will cover the remaining part */
        .status-timeline::after {
            content: '';
            position: absolute;
            left: 24px;
            top: 0;
            bottom: 0;
            width: 3px;
            background-color: rgba(224, 224, 224, 0.5);
            /* Gray color */
            z-index: 1;
            clip-path: inset(0 0 100% 0);
            /* Initially shows nothing */
            transition: clip-path 0.5s ease;
        }

        .status-item {
            position: relative;
            padding-bottom: 3rem;
        }

        .status-item:last-child {
            padding-bottom: 0;
        }

        .status-icon {
            position: absolute;
            left: -42px;
            top: 0;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: white;
            border: 3px solid #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1;
            transition: all 0.3s ease;
        }

        .status-item.active .status-icon {
            border-color: var(--secondary-color);
            background-color: var(--secondary-color);
            color: white;
            transform: scale(1.1);
            box-shadow: 0 0 0 4px rgba(46, 204, 113, 0.3);
            animation: pulse 2s infinite;
        }

        .status-item.completed .status-icon {
            border-color: var(--secondary-color);
            background-color: var(--secondary-color);
            color: white;
        }

        .status-content {
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            position: relative;
            z-index: 1;
        }

        .status-item.active .status-content {
            border-left: 3px solid var(--secondary-color);
        }

        .status-item.completed .status-content {
            border-left: 3px solid var(--secondary-color);
        }

        .status-date {
            font-size: 0.85rem;
            color: #7f8c8d;
            margin-top: 8px;
            display: flex;
            align-items: center;
        }

        .status-date i {
            margin-right: 5px;
        }

        .package-image {
            height: 200px;
            object-fit: cover;
            border-bottom: 1px solid #eee;
        }

        .delivery-man {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid white;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }

        .progress {
            height: 10px;
            border-radius: 5px;
            margin-bottom: 2rem;
        }

        .progress-bar {
            background: linear-gradient(to right, var(--primary-color), var(--secondary-color));
            transition: width 1s ease;
        }

        .loading-spinner {
            display: none;
            text-align: center;
            margin: 2rem 0;
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .result-container {
            display: none;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .badge-active {
            background-color: rgba(46, 204, 113, 0.2);
            color: var(--secondary-color);
        }

        .badge-completed {
            background-color: rgba(46, 204, 113, 0.2);
            color: var(--secondary-color);
        }

        .badge-pending {
            background-color: rgba(52, 152, 219, 0.2);
            color: var(--primary-color);
        }

        @keyframes pulse {
            0% {
                box-shadow: 0 0 0 0 rgba(46, 204, 113, 0.4);
                transform: scale(1);
            }

            50% {
                box-shadow: 0 0 0 10px rgba(46, 204, 113, 0);
                transform: scale(1.05);
            }

            100% {
                box-shadow: 0 0 0 0 rgba(46, 204, 113, 0);
                transform: scale(1);
            }
        }

        /* --------------------- Final css changed ---------------*/

        .status-icon {
            position: absolute;
            left: -42px;
            top: 0;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: white;
            border: 3px solid #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1;
            /* Above the lines */
            transition: all 0.3s ease;
        }
    </style>
</head>

<body>
    <!-- Header Section -->
    <header class="tracker-header text-center">
        <div class="container">
            <h1 class="display-4 fw-bold mb-4">Track Your Package</h1>
            <p class="lead">Enter your tracking number below to check delivery status</p>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mb-5">
        <!-- Tracking Input Section -->
        <section class="mb-5">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="tracking-input-group">
                        <input type="text" class="form-control tracking-input" id="trackingNumber"
                            placeholder="Enter your tracking number">
                        <button class="btn btn-primary tracking-btn" id="trackBtn">
                            <i class="fas fa-search me-2"></i> Track
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Loading Spinner -->
        <div class="loading-spinner" id="loadingSpinner">
            <div class="spinner"></div>
            <p class="mt-3">Tracking your package...</p>
        </div>

        <!-- Results Section -->
        <div class="result-container" id="resultContainer">
            <div class="row">
                <!-- Package Info Card -->
                <div class="col-md-5 mb-4">
                    <div class="card tracking-card h-100">
                        <div class="card-body">
                            <h5 class="card-title">Your Package Details</h5>
                            <ul class="list-group list-group-flush" style="line-height: 45px;">
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Delivery ID:</span>
                                    <span class="fw-bold" id="displayTrackingNumber">ABC123456789</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Tracking number:</span>
                                    <span class="fw-bold" id="trackNumber">Express Delivery</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Shipment date:</span>
                                    <span class="fw-bold" id="shipDate">Express Delivery</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Delivery date:</span>
                                    <span class="fw-bold" id="delDate">2.5 kg</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Courier agent:</span>
                                    <span class="fw-bold" id="agent">30 × 20 × 15 cm</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Shipping address:</span>
                                    <span class="fw-bold" id="shipAddress">30 × 20 × 15 cm</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>City:</span>
                                    <span class="fw-bold" id="shipCity">30 × 20 × 15 cm</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>State:</span>
                                    <span class="fw-bold" id="shipState">30 × 20 × 15 cm</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Country:</span>
                                    <span class="fw-bold" id="shipCountry">30 × 20 × 15 cm</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between">
                                    <span>Pincode:</span>
                                    <span class="fw-bold" id="shipPinCode">30 × 20 × 15 cm</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <!-- Tracking Progress Card -->
                <div class="col-md-7 mb-4">
                    <div class="card tracking-card h-100">
                        <div class="card-body">
                            <h5 class="card-title mb-4">Delivery Status</h5>

                            <!-- Timeline with 4 stages (In Transit removed) -->
                            <!-- Status Timeline Section -->
                            <div class="status-timeline">
                                <!-- Order Processed -->
                                <div class="status-item" id="statusOrderProcessed">
                                    <div class="status-icon">
                                        <i class="fas fa-warehouse"></i>
                                    </div>
                                    <div class="status-content">
                                        <span class="status-badge badge-pending">
                                            <i class="far fa-clock me-1"></i> Pending
                                        </span>
                                        <h6 class="fw-bold mb-2">Order Processed</h6>
                                        <p class="text-muted mb-1">Your order has been received and is being prepared
                                            for shipment.</p>
                                        <p class="status-date">
                                            <i class="far fa-clock"></i> Estimated: <span class="estimated-date"
                                                id="inl_date_1" style="font-weight: bold;">June
                                                12, 2023</span>
                                        </p>
                                    </div>
                                </div>

                                <!-- Shipped -->
                                <div class="status-item" id="statusShipped">
                                    <div class="status-icon">
                                        <i class="fas fa-shipping-fast"></i>
                                    </div>
                                    <div class="status-content">
                                        <span class="status-badge badge-pending">
                                            <i class="far fa-clock me-1"></i> Pending
                                        </span>
                                        <h6 class="fw-bold mb-2">Shipped</h6>
                                        <p class="text-muted mb-1">Your package has left our facility and is on its way.
                                        </p>
                                        <p class="status-date">
                                            <i class="far fa-clock"></i> Estimated: <span class="estimated-date"
                                                id="inl_date_2" style="font-weight: bold;">June
                                                13, 2023</span>
                                        </p>
                                    </div>
                                </div>

                                <!-- Out for Delivery -->
                                <div class="status-item" id="statusOutForDelivery">
                                    <div class="status-icon">
                                        <i class="fas fa-truck"></i>
                                    </div>
                                    <div class="status-content">
                                        <span class="status-badge badge-pending">
                                            <i class="far fa-clock me-1"></i> Pending
                                        </span>
                                        <h6 class="fw-bold mb-2">Out for Delivery</h6>
                                        <p class="text-muted mb-1">Your package is with the delivery driver and will
                                            arrive soon.</p>
                                        <p class="status-date">
                                            <i class="far fa-clock"></i> Estimated: <span class="estimated-date"
                                                id="inl_date_3" style="font-weight: bold;">June
                                                14, 2023</span>
                                        </p>
                                    </div>
                                </div>

                                <!-- Delivered -->
                                <div class="status-item" id="statusDelivered">
                                    <div class="status-icon">
                                        <i class="fas fa-home"></i>
                                    </div>
                                    <div class="status-content">
                                        <span class="status-badge badge-pending">
                                            <i class="far fa-clock me-1"></i> Pending
                                        </span>
                                        <h6 class="fw-bold mb-2">Delivered</h6>
                                        <p class="text-muted mb-1">Your package has been delivered.</p>
                                        <p class="status-date">
                                            <i class="far fa-clock"></i> Estimated: <span class="estimated-date"
                                                id="inl_date_4" style="font-weight: bold;">June
                                                15, 2025</span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4" style="position: fixed; bottom: 0px; width: 100%; z-index: 1;">
        <div class="container text-center">
            <p class="mb-2">© 2025 Package Tracker. All rights reserved.</p>
            <div class="d-flex justify-content-center">
                <a href="https://www.facebook.com/share/155uUJhs4B/" class="text-white mx-2"><i
                        class="fab fa-facebook-f"></i></a>
                <a href="https://x.com/MonaxBhadiyadra?t=ssi9lGROcdJ8ith999Wt9w&s=08" class="text-white mx-2"><i
                        class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/_monax29?igsh=MXEycjF4bW4wbnE3eA==" class="text-white mx-2"><i
                        class="fab fa-instagram"></i></a>
                <a href="#" class="text-white mx-2"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function () {
            $('#trackBtn').click(function (event) {
                event.preventDefault(); // Prevent default button behavior

                const trackingNumber = $('#trackingNumber').val().trim();

                if (!trackingNumber) {
                    alert('Please enter a valid tracking number!');
                    return;
                }

                $.ajax({
                    url: 'get_shipment_data.php',
                    method: 'POST',
                    data: { trackingNumber: trackingNumber },
                    dataType: 'json',
                    success: function (response) {
                        document.getElementById('displayTrackingNumber').innerHTML = response.delivery_id;
                        document.getElementById('trackNumber').innerHTML = response.tracking_number;
                        document.getElementById('shipDate').innerHTML = response.updated_at;
                        document.getElementById('delDate').innerHTML = response.estimated_delivery_date;
                        document.getElementById('agent').innerHTML = response.courier_name;
                        document.getElementById('shipAddress').innerHTML = response.shipping_address;
                        document.getElementById('shipCity').innerHTML = response.city;
                        document.getElementById('shipState').innerHTML = response.state;
                        document.getElementById('shipCountry').innerHTML = response.country;
                        document.getElementById('shipPinCode').innerHTML = response.pincode;
                        document.getElementById("inl_date_1").innerHTML = addDaysToDate(response.updated_at, 1);
                        document.getElementById("inl_date_2").innerHTML = addDaysToDate(response.updated_at, 2);
                        document.getElementById("inl_date_3").innerHTML = addDaysToDate(response.updated_at, 3);
                        document.getElementById("inl_date_4").innerHTML = addDaysToDate(response.updated_at, 4);
                        var differenceInDays = parseInt(response.days_left);
                        updateDeliveryStatus(parseInt(differenceInDays));

                        document.getElementById('loadingSpinner').style.display = 'block';
                        document.getElementById('resultContainer').style.display = 'none';

                        setTimeout(function () {
                            document.getElementById('loadingSpinner').style.display = 'none';
                            document.getElementById('resultContainer').style.display = 'block';
                            document.getElementById('displayTrackingNumber').textContent = trackingNumber;
                            document.getElementById('resultContainer').scrollIntoView({ behavior: 'smooth' });
                        }, 1000);
                    },
                    error: function (xhr, status, error) {
                        alert("No data found..!");
                    }
                });

            });
        });

        function addDaysToDate(dateTimeString, daysToAdd) {
            const datePart = dateTimeString.split(' ')[0];
            const dateObject = new Date(datePart);

            dateObject.setDate(dateObject.getDate() + daysToAdd);

            const updatedDate = dateObject.toISOString().split('T')[0];
            return updatedDate;
        }

        // Example Usage
        const updatedAt = '2025-04-24 05:48:27'; // Response date
        console.log(addDaysToDate(updatedAt, 1)); // Output: '2025-04-25'
        console.log(addDaysToDate(updatedAt, 5)); // Output: '2025-04-29'
        console.log(addDaysToDate(updatedAt, -3)); // Output: '2025-04-21' (subtract 3 days)


        function updateDeliveryStatus(daysDifference) {
            document.querySelectorAll('.status-item').forEach(item => {
                item.classList.remove('completed', 'active');
                let icon = item.querySelector('.status-icon');
                icon.style.borderColor = '#e0e0e0';
                icon.style.backgroundColor = 'white';
                icon.style.color = 'inherit';
                icon.style.animation = 'none';

                let badge = item.querySelector('.status-badge');
                badge.className = 'status-badge badge-pending';
                badge.innerHTML = '<i class="far fa-clock me-1"></i> Pending';
            });

            let progress = 0;
            let currentStatus = '';

            if (daysDifference == 0) {
                currentStatus = 'Delivered';
                fillTimelineProgress(100);
                progress = 100;
            } else if (daysDifference == 1) {
                currentStatus = 'Out for Delivery';
                fillTimelineProgress(55);
                progress = 75;
            } else if (daysDifference == 2) {
                currentStatus = 'Shipped';
                fillTimelineProgress(30);
                progress = 50;
            } else if (daysDifference >= 3) {
                currentStatus = 'Order Processed';
                fillTimelineProgress(0);
                progress = 25;
            }
            else {
                document.querySelectorAll('.status-item').forEach(item => {
                    item.classList.add('completed');
                    const icon = item.querySelector('.status-icon');
                    icon.style.borderColor = 'var(--secondary-color)';
                    icon.style.backgroundColor = 'var(--secondary-color)';
                    icon.style.color = 'white';

                    const badge = item.querySelector('.status-badge');
                    badge.className = 'status-badge badge-completed';
                    badge.innerHTML = '<i class="fas fa-check-circle me-1"></i> Completed';
                });
            }
            console.log('Day difference: ' + daysDifference + ', status: ' + currentStatus);

            const statusMap = {
                'Order Processed': 'statusOrderProcessed',
                'Shipped': 'statusShipped',
                'Out for Delivery': 'statusOutForDelivery',
                'Delivered': 'statusDelivered'
            };

            const statusOrder = ['Order Processed', 'Shipped', 'Out for Delivery', 'Delivered'];
            const currentIndex = statusOrder.indexOf(currentStatus);

            for (let i = 0; i < currentIndex; i++) {
                const statusId = statusMap[statusOrder[i]];
                const item = document.getElementById(statusId);
                item.classList.add('completed');

                const icon = item.querySelector('.status-icon');
                icon.style.borderColor = 'var(--secondary-color)';
                icon.style.backgroundColor = 'var(--secondary-color)';
                icon.style.color = 'white';

                const badge = item.querySelector('.status-badge');
                badge.className = 'status-badge badge-completed';
                badge.innerHTML = '<i class="fas fa-check-circle me-1"></i> Completed';
            }

            if (currentStatus) {
                const currentStatusId = statusMap[currentStatus];
                const currentItem = document.getElementById(currentStatusId);
                currentItem.classList.add('active');

                const currentIcon = currentItem.querySelector('.status-icon');
                currentIcon.style.borderColor = 'var(--secondary-color)';
                currentIcon.style.backgroundColor = 'var(--secondary-color)';
                currentIcon.style.color = 'white';
                currentIcon.style.animation = 'pulse 2s infinite';

                const currentBadge = currentItem.querySelector('.status-badge');
                currentBadge.className = 'status-badge badge-active';
                currentBadge.innerHTML = '<i class="fas fa-spinner fa-pulse me-1"></i> Active';
            }
        }

        function fillTimelineProgress(percent) {
            percent = Math.max(0, Math.min(100, percent));

            const timeline = document.querySelector('.status-timeline');

            let progressIndicator = timeline.querySelector('.progress-indicator');
            if (!progressIndicator) {
                progressIndicator = document.createElement('div');
                progressIndicator.className = 'progress-indicator';
                timeline.insertBefore(progressIndicator, timeline.firstChild);

                const style = document.createElement('style');
                style.textContent = `
            .status-timeline {
                position: relative;
                padding-left: 50px;
            }
            .status-timeline::before {
                content: '';
                position: absolute;
                left: 24px;
                top: 0;
                bottom: 0;
                width: 3px;
                background-color: #e0e0e0; /* Entire line light gray */
                z-index: 1;
            }
            .progress-indicator {
                position: absolute;
                left: 24px;
                top: 0;
                height: ${percent}%;
                width: 3px;
                background-color: #2ecc71; /* Green progress */
                z-index: 2;
                transition: height 0.5s ease;
            }
        `;
                document.head.appendChild(style);
            }
            progressIndicator.style.height = `${percent}%`;

            return percent;
        }
    </script>
</body>

</html>