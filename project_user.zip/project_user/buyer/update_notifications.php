<?php
session_start(); // Start the session to access the user ID
require_once("../bridge.php");

$user_id = $_SESSION['user_id']; // Use the session user ID

$sql = "UPDATE notification SET is_read = 1 WHERE user_id = '$user_id' AND is_read = 0";

if (mysqli_query($connect, $sql)) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error']);
}

mysqli_close($connect);
?>
