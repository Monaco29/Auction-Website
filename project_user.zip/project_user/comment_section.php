<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comment Section</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        /* styles.css */
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');

        body {
            background-color: #f8f9fa;
            font-family: 'Roboto', sans-serif;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
            animation: fadeIn 1s ease-in-out;
        }

        #comment-section {
            background-color: #f8f9fa;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-top: 20px;
        }

        .comment {
            padding: 10px;
            margin-bottom: 10px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .comment .comment-author {
            font-weight: bold;
            color: #007bff;
        }

        .comment .comment-text {
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <div class="container mt-5 p-4 rounded shadow-sm bg-white">
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <textarea class="form-control" id="comment" rows="3" placeholder="Add a public comment..."></textarea>
                </div>
                <button class="btn btn-primary" id="postComment">Post Comment</button>
                <div id="comment-section" class="mt-4">
                    <!-- Comments will be dynamically loaded here -->
                </div>
            </div>
        </div>
    </div>
    <script>
        /* script.js */
        $(document).ready(function() {
            $('#postComment').click(function() {
                let commentText = $('#comment').val();
                if (commentText !== '') {
                    // Dynamically create a comment element
                    let comment = $('<div class="comment"></div>');
                    let author = $('<div class="comment-author">User</div>');
                    let text = $('<div class="comment-text"></div>').text(commentText);
                    comment.append(author).append(text);

                    // Append the comment to the comment section
                    $('#comment-section').append(comment);

                    // Clear the textarea
                    $('#comment').val('');
                } else {
                    alert('Please enter a comment.');
                }
            });
        });
    </script>
</body>

</html>