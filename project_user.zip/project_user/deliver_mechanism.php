<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        :root
        {
            --body: #8c9eff;
            --cont: #eceff1;
            --line: #651fff;
            --txt: #007bfd;
            --light: #c5cae9;
        }
        *
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body
        {
            min-height: 100vh;
            width: 100%;
            background: var(--body);
            line-height: 1.4;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container
        {
            width: 1100px;
            max-width: 100%;
            padding: 40px;
            margin: 0 30px;
            background: var(--cont);
            position: relative;
        }
        .order h1
        {
            text-transform: uppercase;
        }
        .order span
        {
            color: var(--txt);
        }
        .date p
        {
            font-size: 1.1rem;
        }
        .track
        {
            margin: 4em 0 8em;
        }
        #progress
        {
            list-style: none;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            gap: 1em;
            position: relative;
            text-align: center;
        }
        #progress li
        {
            width: 20%;
            position: relative;
        }
        #progress li::before
        {
            content: '\2713';
            position:absolute;
            display: flex;
            justify-content: center;
            width: 50px;    
            align-items: center;
            font-size: 2rem;
            background: var(--line);
            height: 50px;
            color: #fff;
            border-radius: 50%;
            z-index: 11111;
        }
        #progress li:last-child::before
        {
            content: '\2713';
            font-weight: bold;
            background: var(--light);
        }
        #progress::before
        {
            content: '';
            position: absolute;
            top: 20px;
            width: 55%;
            margin-left: 35px;
            height: 10px;
            background: var(--line);
            z-index: 111;
        }
        #progress::after
        {
            content: '';
            position: absolute;
            top: 20px;
            width: 80%;
            height: 10px;
            background: #c5cae9;
        }
        .lists
        {
            display: flex;
            gap: 2em;
            flex-wrap: wrap;
            align-items: center;
        }
        .list
        {
            display: flex;
            gap: 1em;
            flex: 1 1 50px;
        }
        .list p{
            font-size: 1rem;
            font-family: 'Courier New', Courier, monospace;
            font-weight: bolder;
        }
        .list img{
            width: 50px;
        }
    </style>
</head>
<body>
    <div class="container">

        <div class="track">
            <ul id="progress" class="text-center">
                <li class="active"></li>
                <li class="active"></li>
                <li class="active"></li>
                <li class=""></li>
            </ul>
        </div>

        <div class="lists">
            <div class="list">
                <img src="iimg_2.png" alt="" srcset="" >
                <p>Order <br> Processed </p>
            </div>

            <div class="list">
                <img src="iimg_3.png" alt="" srcset="" >
                <p>Order <br> Shipped </p>
            </div>

            <div class="list">
                <img src="iimg_4.png" alt="" srcset="">
                <p>Order <br> Enroute </p>
            </div>

            <div class="list">
                <img src="iimg_5.png" alt="" srcset="">
                <p>Order <br> Arrived </p>
            </div>
        </div>
    </div>
</body>
</html>