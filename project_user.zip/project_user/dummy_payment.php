<?php
session_start();
require_once 'bridge.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bidID = $_POST['bidID'];
    $amount = $_POST['amount'];
    $paymentMethod = $_POST['paymentMethod'];
    $transactionDate = date('Y-m-d H:i:s');

    $sql = "INSERT INTO transactions (BidID, TransactionDate, Amount, PaymentMethod) VALUES ('$bidID', '$transactionDate', '$amount', '$paymentMethod')";
    if (mysqli_query($conn, $sql)) {
        echo "Payment recorded successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>
