<?php
require_once('bridge.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $contact_number = $_POST['contect_number'];
    $address = $_POST['address'];
    $profile_pic = basename($_FILES["profile_pic"]["name"]);
    $role = $_POST["role"];

    // Address fields
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pincode = $_POST['pincode'];
    $country = $_POST['country'];

    $target_dir = "../final_sem_project/uploaded_images/";
    $target_file = $target_dir . basename($_FILES["profile_pic"]["name"]);
    move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file);

    // Start transaction
    mysqli_begin_transaction($connect);

    try {
        // Insert into user table
        $sql = "INSERT INTO user (username, email, password, contect_number, address, profile_pic, role) 
                VALUES ('$username', '$email', '$password', '$contact_number', '$address', '$profile_pic','$role')";

        if (!mysqli_query($connect, $sql)) {
            throw new Exception(mysqli_error($connect));
        }

        $target_id = mysqli_insert_id($connect);

        if ($_POST["role"] == "Buyer") {
            // Insert into buyer table
            if (!mysqli_query($connect, "INSERT INTO buyer(user_id) VALUES($target_id)")) {
                throw new Exception(mysqli_error($connect));
            }

            // Insert into user_address table for buyer
            $address_sql = "INSERT INTO user_address (user_id, address, city, state, pincode, country)
                           VALUES ('$target_id', '$address', '$city', '$state', '$pincode', '$country')";

            if (!mysqli_query($connect, $address_sql)) {
                throw new Exception(mysqli_error($connect));
            }

            $message = 'Everything is on the way for a buyer..';
        } else {
            $businessName = $_POST["business_name"];
            $businessAdd = $_POST["business_address"];
            $businessEmail = $_POST["business_email"];

            // Insert into seller table
            if (
                !mysqli_query($connect, "INSERT INTO seller(user_id, business_name, business_address, business_email) 
                                        VALUES($target_id, '$businessName','$businessAdd','$businessEmail')")
            ) {
                throw new Exception(mysqli_error($connect));
            }

            $message = 'Everything is on the way for a seller..';
        }

        // Commit transaction
        mysqli_commit($connect);

        echo "<script>alert('$message')</script>";
        header("Location: user_login.php");
        exit();
    } catch (Exception $e) {
        // Rollback transaction on error
        mysqli_rollback($connect);
        echo "<script>alert('Error: " . $e->getMessage() . "')</script>";
        header("Location: user_registration.php");
        exit();
    }
}

mysqli_close($connect);
