<?php
session_start();
require_once('bridge.php'); // Check if the user is logged in 

// Get auction details....
$query_2 = $query = "SELECT item.item_id, auction.auction_id, item.name, item.start_price, item.picture, auction.auction_start, auction.status, auction.title, auction.description, category.name AS cat_name 
                        FROM item 
                        JOIN auction ON item.item_Id = auction.item_id 
                        JOIN category ON item.category_id = category.category_id 
                        WHERE auction.status = 'OnGoing' OR auction.status = 'Upcoming'";
$result_2 = mysqli_query($connect, $query_2);
$item_container = [];
$item_iterator = 0;
while ($data = mysqli_fetch_assoc($result_2)) {
    $item_container[] = $data;
}
$number_of_auctions = mysqli_num_rows($result_2); // Number of item cards
$number_of_rows = ceil($number_of_auctions / 4); // Number of rows in the grid
// }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Auction System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playwrite+IN:wght@100..400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap');

        /* Custom styles for the navbar */
        .navbar {
            background-color: #001f3f;
            transition: background-color 0.5s;
            position: fixed;
            /* Make navbar fixed */
            top: 0;
            /* Stick to top */
            width: 100%;
            /* Full width */
            z-index: 1000;
            /* Ensure navbar stays on top of other elements */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            /* Add subtle shadow */
        }

        .navbar-brand {
            font-size: 1.8rem;
            color: #00d4ff;
            font-weight: bold;
            transition: color 0.5s;
        }

        .navbar-nav .nav-link {
            color: #e0e0e0;
            transition: color 0.3s;
            padding: 0.5rem 1rem;
            /* Better spacing */
        }

        .navbar-nav .nav-link:hover {
            color: #00d4ff;
        }

        /* Dropdown menu styling */
        .dropdown-menu {
            background-color: #001f3f;
            border: none;
        }

        .dropdown-item {
            color: #e0e0e0;
        }

        .dropdown-item:hover {
            background-color: #003366;
            color: #00d4ff;
        }

        /* Active nav item */
        .navbar-nav .nav-item.active .nav-link {
            color: #00d4ff;
            font-weight: bold;
        }

        /* User image in navbar */
        .navbar .rounded-circle {
            border: 2px solid #00d4ff;
        }

        /* Toggle button styling */
        .navbar-toggler {
            border-color: rgba(0, 212, 255, 0.5);
        }

        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3e%3cpath stroke='rgba(0, 212, 255, 0.8)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }

        /* Custom styles for the banner */
        .banner {
            margin-top: -10px;
            padding-top: 120px;
            background: linear-gradient(135deg, #001f3f, #003c6e, #005f99, #00c9ff);
            background-size: 300% 300%;
            animation: oceanFlow 10s ease infinite;

            color: white;
            text-align: center;
            padding: 100px 20px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.2);
            /* border-bottom: 4px solid #00c9ff; */
        }

        .banner::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSg0NSkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSIvPjwvc3ZnPg==');
        }

        @keyframes oceanFlow {
            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }

        .banner h1 {
            margin-top: 50px;
            font-size: 3.5rem;
            font-weight: bold;
            animation: slideIn 2s ease-in-out;
        }

        .banner p {
            font-size: 1.5rem;
            margin-top: 15px;
            animation: fadeIn 3s ease-in-out;
        }

        /* Info box */
        .info-box {
            background: #e3f2fd;
            color: #01579b;
            border-left: 6px solid #00c9ff;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            width: 98%;
            margin: 20px auto;
        }

        h2 {
            background: #e3f2fd;
            color: #01579b;
            border-left: 6px solid #00c9ff;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 2rem;
            width: 98%;
            margin: 10px auto;
        }

        /* Animations */
        @keyframes slideIn {
            from {
                transform: translateX(-100%);
            }

            to {
                transform: translateX(0);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        /* Search bar */
        .search-container {
            width: 98%;
            margin: 20px auto;
        }

        /* Category icons */
        .category-icons {
            display: flex;
            justify-content: space-around;
            text-align: center;
            margin: 30px auto;
            width: 98%;
        }

        .category-icons i {
            font-size: 3rem;
            color: #00c9ff;
        }

        .category-icons p {
            margin-top: 10px;
            font-weight: 500;
        }

        .card {
            transition: transform 0.3s;
        }

        .card:hover {
            transform: scale(1.05);
        }

        /* Stats section */
        .stats {
            display: flex;
            justify-content: space-around;
            padding: 40px 0;
            background-color: #00c9ff;
            color: white;
            width: 100%;
            margin: 30px 0;
        }

        .stat {
            text-align: center;
        }

        .stat h3 {
            font-size: 2.5rem;
            font-weight: bold;
        }

        /* Why choose us section */
        .features {
            display: flex;
            justify-content: space-around;
            text-align: center;
            margin: 30px auto;
            width: 98%;
            font-size: 1.1rem;
            font-weight: 500;
        }

        /* Newsletter */
        .newsletter {
            width: 98%;
            margin: 30px auto;
            text-align: center;
        }

        /* ----------------------------------- footer --------------------------------- */
        .footer {
            background: #001f3f;

            color: white;
            padding: 30px 0;
            height: 13%;
            text-align: center;

            /* position: fixed; */
            bottom: 0;
            width: 100%;
        }

        .footer-contact {
            margin-top: 20px;
        }

        /* .footer a {
            color: #ffcc00;
            text-decoration: none;
            margin: 0 10px;
            transition: color 0.3s;
        }

        .footer a:hover {
            color: #ff9900;
        } */

        .footer a {
            color: #00d4ff;
            text-decoration: none;
            transition: color 0.3s;
        }

        .footer a:hover {
            color: #ffffff;

        }

        .footer-links {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 10px;
        }

        .footer-links div {
            margin: 5px 10px;
        }

        @media (max-width: 600px) {
            .footer-links {
                flex-direction: column;
            }

            .footer-links div {
                margin: 10px 0;
            }
        }

        /* Items container */
        .flex-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
            padding-bottom: 140px;
        }

        .items-container {
            display: flex;
            /* flex-wrap: wrap; */
            width: 98%;
            align-items: center;
            flex-direction: row;
            padding: 10px;
            justify-content: space-around;
            border-radius: 10px;
            margin: 20px auto;
        }

        .container {
            position: relative;
            width: 330px;
            height: 455px;
            text-align: center;
            border-radius: 5px;
            perspective: 950px;
        }

        .card {
            position: relative;
            width: 100%;
            height: 100%;
            transform-style: preserve-3d;
            transition: transform 0.8s ease-in-out;
        }

        .front-face {
            position: absolute;
            width: 100%;
            height: 100%;
            background: #ebf8f9;
            border-radius: 5px;
            backface-visibility: hidden;
            box-shadow: 0 2px 3px rgba(0, 0, 0, .2);
        }

        .cover {
            background: linear-gradient(135deg, #001f3f, #003c6e, #005f99, #00c9ff);
            height: 140px;
            width: 100%;
            border-radius: 5px 5px 0 0;
            background-size: 200% 200%;

            animation: oceanFlow 10s ease infinite;

        }

        @keyframes oceanFlow {
            0% {
                background-position: 0% 50%;
            }

            50% {
                background-position: 100% 50%;
            }

            100% {
                background-position: 0% 50%;
            }
        }

        .item-image {
            height: 173px;
            width: 173px;
            border-radius: 50%;
            padding: 5px;
            background: white;
            margin-top: -130px;
            margin-bottom: 10px;
        }


        .item-details {
            padding: 7px;
            text-align: center;
        }

        .item-table {
            width: 100%;
            margin-top: 8px;
            border-collapse: collapse;
            font-family: 'Arial', sans-serif;
            font-size: 1rem;
            color: #333;
            background-color: #ebf8f9;
            border: none;
        }

        .item-table th,
        .item-table td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: center;
            border: none;
        }

        .item-table th {
            background-color: #dbeef2;
            font-weight: bold;
            color: #2c3e50;
            font-style: italic;
        }

        .item-table td:first-child {
            font-weight: normal;
            background-color: #f0f8fa;
            font-family: 'Pacifico', cursive;
        }

        .item-name {
            font-size: 1.5rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 15px;
            font-family: "Playwrite IN", serif;
        }

        .item-category {
            font-weight: bold;
            color: rgb(59, 59, 59);
            font-family: 'Montserrat', sans-serif;
        }

        .starting-price {
            font-weight: bold;
            color: rgb(93, 114, 255);
            font-family: 'Montserrat', sans-serif;
            /* Red color for starting price */
        }

        .auction-start-time {
            font-weight: bold;
            color: #2980b9;
            font-family: 'Roboto', sans-serif;
            /* Blue color for auction start time */
        }

        .auction-status {
            font-weight: bold;
            color: #27ae60;
            /* Green color for status */
        }

        .front-face {
            transform: rotateY(0deg);
        }

        .button-container {
            display: flex;
            flex-direction: column;
        }

        .auction-button {
            background-color: #17a2b8;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 1em;
            margin: 10px 0;
            z-index: 1;
            /* Ensure buttons are above bubbles */
        }

        .auction-button:hover {
            background-color: #138496;
        }

        .bubbles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }

        .bubble {
            position: absolute;
            bottom: -100px;
            background-color: rgba(0, 191, 255, 0.6);
            border-radius: 50%;
            animation: bubble-animation 20s infinite;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        @keyframes bubble-animation {
            0% {
                transform: translateY(0) translateX(0);
            }

            100% {
                transform: translateY(-600px) translateX(0);
            }
        }

        button>a {
            text-decoration: none;
            color: inherit;
        }

        button>a:hover {
            text-decoration: none;
            color: inherit;
        }

        /* Handling scrollbar visibility */
        /* Hide scrollbar for Chrome, Safari, and Edge */
        ::-webkit-scrollbar {
            width: 0px;
            height: 0px;
        }

        /* Hide scrollbar for Firefox */
        html {
            scrollbar-width: none;
        }

        /* Hide scrollbar for Internet Explorer */
        body {
            overflow-x: hidden;
            overflow-y: auto;
        }

        .rounded-circle {
            border: 2px solid #ddd;
        }

        .banner-h1-title {
            font-family: "Playwrite IN", serif;
        }

        @media (max-width: 1200px) {
            .items-container {
                flex-wrap: wrap;
                justify-content: center;
            }

            .container {
                margin: 15px;
            }
        }

        @media (max-width: 768px) {
            .banner h1 {
                font-size: 2.5rem;
            }

            .banner p {
                font-size: 1.2rem;
            }

            .category-icons {
                flex-wrap: wrap;
            }

            .category-icons .col {
                flex: 0 0 50%;
                margin-bottom: 20px;
            }

            .features {
                flex-wrap: wrap;
            }

            .features div {
                flex: 0 0 50%;
                margin-bottom: 15px;
            }

            .stats {
                flex-direction: column;
            }

            .stat {
                margin-bottom: 20px;
            }
        }

        @media (max-width: 576px) {
            .category-icons .col {
                flex: 0 0 100%;
            }

            .features div {
                flex: 0 0 100%;
            }
        }

        .modal-content {
            border-radius: 10px;
            border: none;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            background-color: var(--primary);
            color: white;
            border-radius: 10px 10px 0 0 !important;
        }

        .close {
            color: white;
            text-shadow: none;
            opacity: 0.8;
        }

        .close:hover {
            opacity: 1;
            color: var(--secondary);
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .banner h1 {
                font-size: 2.5rem;
            }

            .banner p {
                font-size: 1.1rem;
            }

            .category-icon {
                font-size: 2rem;
            }
        }
    </style>
</head>

<body>
    <!-- Creative Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#"><i class="fas fa-gavel"></i>Auction House</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href=""><i class="fas fa-home"></i> Home <span
                            class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link trigger-login-check" href=""><i class="fas fa-gavel"></i> Auctions </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link trigger-login-check" href=""><i class="fas fa-user"></i> My Account</a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <!-- <?php if ($loggedIn): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="../final_sem_project/uploaded_images/<?php echo htmlspecialchars($userImage); ?>"
                                class="rounded-circle" alt="User Image" width="48" height="48" style="object-fit: cover;">
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?php
                            if (isset($sellerId)) {
                                echo "<a class='dropdown-item' href='seller/home.php'>Profile</a>";
                            }
                            if (isset($buyerId)) {
                                echo "<a class='dropdown-item' href='buyer/home.php'>Profile</a>";
                            }
                            echo "<a class='dropdown-item' href='logout.php'>Logout</a>";
                            ?>
                        </div>
                    </li>
                <?php else: ?> -->
                <li class="nav-item">
                    <a class="nav-link" href="user_login.php"><i class="fas fa-sign-in-alt"></i> Sign In</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="user_registration.php"><i class="fas fa-user-plus"></i> Sign Up</a>
                </li>
                <!-- <?php endif; ?> -->
            </ul>
        </div>
    </nav>

    <!-- Creative Banner with Gradient Background -->
    <div class="banner">
        <h1 class="banner-h1-title">Welcome to Auction
            !</h1>
        <p>Discover unique items and bid on your favorites!</p>
        <!-- <button class="btn btn-primary mt-3 trigger-login-check">Learn More</button> -->
        <span id="noteSection"></span>

    </div>
    <!-- Homepage Content -->
    <div class="flex-container">

        <!-- Info Box -->
        <div class="info-box" id="info">
            <strong><i class="fas fa-info-circle"></i> Note:</strong> Welcome to our auction platform! Browse through
            our featured items below or use the search to find specific items.
        </div>

        <!-- Search Bar -->
        <div class="search-container">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Search auctions...">
                <div class="input-group-append">
                    <button class="btn btn-info trigger-login-check">Search</button>
                </div>
            </div>
        </div>


        <!-- Categories -->
        <h2 class="mt-4" style="width: 98%;">Top Categories</h2>
        <div class="row text-center category-icons">
            <div class="col"><i class="fas fa-gem"></i>
                <p>Jewelry</p>
            </div>
            <div class="col"><i class="fas fa-car"></i>
                <p>Vehicles</p>
            </div>
            <div class="col"><i class="fas fa-laptop"></i>
                <p>Electronics</p>
            </div>
            <div class="col"><i class="fas fa-paint-brush"></i>
                <p>Art</p>
            </div>
        </div>

        <!-- Featured Auctions Title -->
        <h2 class="mt-4" style="width: 98%;">Featured Auctions</h2>

        <!-- Item Cards (preserved from original) -->
        <?php for ($i = 0; $i < $number_of_rows; $i++): ?> <!-- Number of rows-->
            <?php $j = 0; ?>
            <div class="items-container">
                <?php
                while ($j < 4) {
                    $current_item = $item_container[$item_iterator];
                    echo "<div class='container'>
                                <div class='card'>
                                    <div class='front-face'>
                                        <div class='cover'></div>
                                        <img src='../final_sem_project/uploaded_images/" . htmlspecialchars($current_item["picture"]) . "' class='item-image' alt='Item Image'>
                                        <div class='item-details'>
                                            <h5 class='item-name'>" . htmlspecialchars($current_item["name"]) . "</h5>
                                                <table class='item-table'>
                                                    <tr>
                                                        <td>Category:</td>
                                                        <td class='item-category'>" . htmlspecialchars($current_item["cat_name"]) . "</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Starting Price:</td>
                                                        <td class='starting-price'>₹ " . number_format($current_item["start_price"]) . "</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Auction Starts:</td>
                                                        <td class='auction-start-time'>" . htmlspecialchars($current_item["auction_start"]) . "</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Status:</td>
                                                        <td class='auction-status'>" . htmlspecialchars($current_item["status"]) . "</td>
                                                    </tr>
                                                </table>
                                        </div>
                                    </div>
                                </div>
                            </div>";
                    if ($item_iterator == ($number_of_auctions - 1)) {
                        break;
                    }
                    $j++;
                    $item_iterator++;
                }
                ?>
            </div>
        <?php endfor; ?>
    </div>
    <!-- Why Choose Us Section -->
    <h2 class="mt-5" style="width: 98%;">Why Choose Us?</h2>
    <div class="features">
        <div><i class="fas fa-lock"></i> Secure Bidding</div>
        <div><i class="fas fa-check-circle"></i> Verified Sellers</div>
        <div><i class="fas fa-headset"></i> 24/7 Support</div>
        <div><i class="fas fa-globe"></i> Global Reach</div>
    </div>

    <!-- Stats Section -->
    <div class="stats">
        <div class="stat">
            <h3>2500+</h3>
            <p>Auctions Held</p>
        </div>
        <div class="stat">
            <h3>10,000+</h3>
            <p>Registered Users</p>
        </div>
        <div class="stat">
            <h3>500+</h3>
            <p>Live Auctions</p>
        </div>
    </div>

    <!-- Newsletter -->
    <div class="newsletter">
        <h4>Subscribe for Updates</h4>
        <form class="form-inline justify-content-center">
            <input type="email" class="form-control mr-2" placeholder="Enter your email">
            <button class="btn btn-outline-primary trigger-login-check">Subscribe</button>
        </form>
    </div>

    <footer class="footer">
        <div class="footer-links">
            <div><a href="support_files/about_us.htm">About Us</a></div>
            <div><a href="support_files/contact-us.htm">Contact Us</a></div>
            <div><a href="support_files/help-support.htm">Help & Support</a></div>
            <div><a href="support_files/privacy-policy.htm">Privacy Policy</a></div>
            <div><a href="support_files/review.htm">Reviews</a></div>
            <div><a href="support_files/t&c.htm">Terms & Conditions</a></div>
        </div>
        <div class="footer-contact">
            <p>Email: support@auctionhouse.com</p>
            <p>Phone: +1 234 567 890</p>
            <div class="social-icons">
                <a href="https://www.facebook.com/share/155uUJhs4B/"><i class="fab fa-facebook mr-1"></i></a>
                <a href="https://x.com/MonaxBhadiyadra?t=ssi9lGROcdJ8ith999Wt9w&s=08"><i class="fab fa-twitter mr-1"></i></a>
                <a href="https://www.instagram.com/_monax29?igsh=MXEycjF4bW4wbnE3eA=="><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <hr style="background-color: rgba(255,255,255,0.1);">

        <p>&copy; 2025 AuctionHouse . All rights reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        const isLoggedIn = <?php echo isset($_SESSION['user']) || isset($_SESSION['buyer_id']) || isset($_SESSION['seller_id']) ? 'true' : 'false'; ?>;

        document.querySelectorAll('.trigger-login-check').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (!isLoggedIn) {
                    e.preventDefault();
                    alert("⚠️ You must login first to access this feature!");

                    const redirectSection = document.getElementById("noteSection");
                    redirectSection.scrollIntoView({
                        behavior: "smooth"
                    });
                    const noteBox = document.getElementById("info");

                    const originalText = noteBox.innerHTML;
                    noteBox.innerHTML = `<strong><i class="fas fa-info-circle"></i> Note:</strong> ⚠️ Please <strong>login</strong> to access this feature.`;

                    // Highlight animation
                    noteBox.style.transition = "box-shadow 0.5s, transform 0.3s";
                    noteBox.style.boxShadow = "0 0 25px 5px #00c3ff";
                    noteBox.style.transform = "scale(1.03)";

                    // Revert text and style after a delay
                    setTimeout(() => {
                        noteBox.innerHTML = originalText;
                        noteBox.style.boxShadow = "none";
                        noteBox.style.transform = "scale(1)";
                    }, 3000);
                }
            });
        });
    </script>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>

</html>