<?php
require_once("bridge.php");
$item_id = $_GET["item_id"];

$qry = "SELECT a.name AS item_name, a.description, a.start_price, a.picture,
            b.name AS category_name, 
            c.seller_id, c.business_name, c.business_email, c.business_address, c.average_rating,
            d.username, d.email, d.contect_number, d.address, d.profile_pic 
            FROM item a 
            INNER JOIN category b ON a.category_id = b.category_id
            INNER JOIN seller c ON a.seller_id = c.seller_id 
            INNER JOIN user d ON d.user_id = c.user_id 
            WHERE a.item_id = $item_id";

$result = mysqli_query($connect, $qry);
$product = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item Details</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        /* styles.css */
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&family=Open+Sans:wght@400;600&family=Roboto:wght@400;700&display=swap');

        body {
            background-color: #f8f9fa;
            font-family: 'Roboto', sans-serif;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            margin-bottom: 20px;
            animation: fadeIn 1s ease-in-out;
        }

        .row {
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
        }

        #item-image {
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            animation: slideInLeft 1s ease-in-out;
        }

        .product-title {
            font-size: 2.5em;
            color: #343a40;
            font-family: 'Montserrat', sans-serif;
            animation: fadeIn 1s ease-in-out;
        }

        .product-description,
        .product-category {
            font-size: 1.2em;
            color: #6c757d;
            font-family: 'Open Sans', sans-serif;
            animation: fadeIn 1s ease-in-out;
        }

        .product-price {
            color: #28a745;
            font-size: 1.5em;
            font-family: 'Montserrat', sans-serif;
            animation: fadeIn 1s ease-in-out;
        }

        .seller-header {
            font-size: 1.8em;
            color: #343a40;
            font-family: 'Montserrat', sans-serif;
            animation: fadeIn 1s ease-in-out;
        }

        .seller-name,
        .seller-info {
            font-family: 'Open Sans', sans-serif;
            animation: fadeIn 1s ease-in-out;
        }

        #product-details,
        #seller-details {
            margin-bottom: 20px;
        }

        #seller-details h4 {
            margin-top: 20px;
        }

        .progressSection .holder {
            display: flex;
            flex-direction: column;
            margin-bottom: 1em;
        }

        .progressSection .holder>div {
            display: flex;
            justify-content: space-between;
        }

        .star-light,
        .text-warning {
            font-size: 2em;
            /* Increase the size of the stars */
            color: #bbb5 !important;
        }

        .text-warning {
            color: rgb(250, 143, 43) !important;
        }

        .submit_star {
            cursor: pointer;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes slideInLeft {
            from {
                transform: translateX(-100%);
            }

            to {
                transform: translateX(0);
            }
        }

        /* Comment sections */
        #comment-section {
            background-color: #f8f9fa;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-top: 20px;
        }

        .comment {
            padding: 10px;
            margin-bottom: 10px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .comment .comment-author {
            font-weight: bold;
            color: #007bff;
        }

        .comment .comment-text {
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <div class="container mt-5 p-4 rounded shadow-sm bg-white animate-container">
        <div class="row">
            <div class="col-md-6">
                <img id="item-image" src="../final_sem_project/uploaded_images/<?php echo $product['picture']; ?>" alt="Item Image" class="img-fluid rounded animate-image">
            </div>
            <div class="col-md-6">
                <div id="product-details" class="mb-4 animate-details">
                    <h2 class="product-title"><?php echo $product['item_name']; ?></h2>
                    <p><strong>Description:</strong> <span class="product-description"><?php echo $product['description']; ?></span></p>
                    <h4><strong>Price:</strong> <span class="product-price">$<?php echo $product['start_price']; ?></span></h4>
                    <p><strong>Category:</strong> <span class="product-category"><?php echo $product['category_name']; ?></span></p>
                </div>
                <div id="seller-details" class="animate-details">
                    <h4 class="seller-header">Seller Details</h4>
                    <p><strong>Seller:</strong> <span class="seller-name"><strong><u><?php echo $product['business_name']; ?></u></strong></span></p>
                    <p><strong>Email:</strong> <span class="seller-info"><em><?php echo $product['business_email']; ?></em></span></p>
                    <p><strong>Address:</strong> <span class="seller-info"><u><?php echo $product['business_address']; ?></u></span></p>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-sm-4 text-center m-auto">
                <h1><span id="avg_rating">0.0</span>/5.0</h1>
                <div>
                    <i class="fa fa-star star-light main_star mr-1"></i>
                    <i class="fa fa-star star-light main_star mr-1"></i>
                    <i class="fa fa-star star-light main_star mr-1"></i>
                    <i class="fa fa-star star-light main_star mr-1"></i>
                    <i class="fa fa-star star-light main_star mr-1"></i>
                </div>
                <span id="total_review">0</span> Reviews
            </div>
            <div class="col-sm-4 progressSection">
                <div class='holder'>
                    <div>
                        <div class="progress-label-left">
                            <b>5</b> <i class="fa fa-star mr-1 text-warning"></i>
                        </div>
                        <div class="progress-label-right">
                            <span id="total_five_star_review"> 0 </span> Reviews
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-warning" id='five_star_progress'></div>
                    </div>
                </div>
                <div class='holder'>
                    <div>
                        <div class="progress-label-left">
                            <b>4</b> <i class="fa fa-star mr-1 text-warning"></i>
                        </div>
                        <div class="progress-label-right">
                            <span id="total_four_star_review"> 0 </span> Reviews
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-warning" id='four_star_progress'></div>
                    </div>
                </div>
                <div class='holder'>
                    <div>
                        <div class="progress-label-left">
                            <b>3</b> <i class="fa fa-star mr-1 text-warning"></i>
                        </div>
                        <div class="progress-label-right">
                            <span id="total_three_star_review"> 0 </span> Reviews
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-warning" id='three_star_progress'></div>
                    </div>
                </div>
                <div class='holder'>
                    <div>
                        <div class="progress-label-left">
                            <b>2</b> <i class="fa fa-star mr-1 text-warning"></i>
                        </div>
                        <div class="progress-label-right">
                            <span id="total_two_star_review"> 0 </span> Reviews
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-warning" id='two_star_progress'></div>
                    </div>
                </div>
                <div class='holder'>
                    <div>
                        <div class="progress-label-left">
                            <b>1</b> <i class="fa fa-star mr-1 text-warning"></i>
                        </div>
                        <div class="progress-label-right">
                            <span id="total_one_star_review"> 0 </span> Reviews
                        </div>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-warning" id='one_star_progress'></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 text-center m-auto">
                <button class="btn-primary" id='add_review'> Add Review </button>
            </div>
        </div>
        <div id="display_review"></div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Write your Review</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <!-- Modal body -->
                <div class="modal-body text-center">
                    <h4>
                        <i class="fa fa-star star-light submit_star mr-1" id='submit_star_1' data-rating='1'></i>
                        <i class="fa fa-star star-light submit_star mr-1" id='submit_star_2' data-rating='2'></i>
                        <i class="fa fa-star star-light submit_star mr-1" id='submit_star_3' data-rating='3'></i>
                        <i class="fa fa-star star-light submit_star mr-1" id='submit_star_4' data-rating='4'></i>
                        <i class="fa fa-star star-light submit_star mr-1" id='submit_star_5' data-rating='5'></i>
                    </h4>
                    <div class="form-group">
                        <textarea name="userMessage" id="userMessage" class="form-control" placeholder="Enter message"></textarea>
                    </div>
                    <div class="form-group">
                        <button class="btn-primary" id='sendReview'>Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        /* script.js */
        $(document).ready(function() {
            let rating_value = 0;
            const urlParams = new URLSearchParams(window.location.search);
            const itemId = urlParams.get("item_id");

            $('#add_review').click(function() {
                $('#myModal').modal('show');
            });

            $(document).on('mouseenter', '.submit_star', function() {
                let rating = $(this).data('rating');
                resetStar();
                for (let i = 1; i <= rating; i++) {
                    $('#submit_star_' + i).addClass('text-warning');
                }
            });

            function resetStar() {
                for (let i = 1; i <= 5; i++) {
                    $('#submit_star_' + i).removeClass('text-warning').addClass('star-light');
                }
            }

            $(document).on('click', '.submit_star', function() {
                rating_value = $(this).data('rating');
                resetStar();
                for (let i = 1; i <= rating_value; i++) {
                    $('#submit_star_' + i).addClass('text-warning').removeClass('star-light');
                }
            });

            $('#sendReview').click(function() {
                let userMessage = $('#userMessage').val();
                    $.ajax({
                        url: 'submit_final_reviews.php',
                        method: 'POST',
                        data: {
                            rating_value: rating_value,
                            userMessage: userMessage,
                            item_id: itemId
                        },
                        success: function(data) {
                            $('#myModal').modal('hide');
                            console.log(data);
                            loadData();
                        }
                    });
            });

            function loadData() {
                $.ajax({
                    url: 'submit_final_reviews.php',
                    method: 'POST',
                    data: {
                        action: 'load_data',
                        item_id : itemId
                    },
                    success: function(data) 
                    {
                        console.log(data);
                        let parsedData = JSON.parse(data);
                        
                        $('#avg_rating').text(parsedData.avgUserRatings);
                        $('#total_review').text(parsedData.totalReviews);
                        $('#total_five_star_review').text(parsedData.totalRatings5);
                        $('#total_four_star_review').text(parsedData.totalRatings4);
                        $('#total_three_star_review').text(parsedData.totalRatings3);
                        $('#total_two_star_review').text(parsedData.totalRatings2);
                        $('#total_one_star_review').text(parsedData.totalRatings1);

                        $('#five_star_progress').css('width', (parsedData.totalRatings5 / parsedData.totalReviews) * 100 + '%');
                        $('#four_star_progress').css('width', (parsedData.totalRatings4 / parsedData.totalReviews) * 100 + '%');
                        $('#three_star_progress').css('width', (parsedData.totalRatings3 / parsedData.totalReviews) * 100 + '%');
                        $('#two_star_progress').css('width', (parsedData.totalRatings2 / parsedData.totalReviews) * 100 + '%');
                        $('#one_star_progress').css('width', (parsedData.totalRatings1 / parsedData.totalReviews) * 100 + '%');

                        let countStar = 0;
                        $('.main_star').each(function() {
                            countStar++;
                            if (Math.ceil(parsedData.avgUserRatings) >= countStar) {
                                $(this).addClass('text-warning').removeClass('star-light');
                            }
                        });

                        if (parsedData.ratingsList.length > 0) {
                            let html = '';
                            for (let count = 0; count < parsedData.ratingsList.length; count++) {
                                html += `<div class='row mt-2'>`;
                                html += `<div class='col-1'>`;
                                html += `<h1><div class='bg-danger rounded-circle text-center text-white text-uppercase pt-2 pb-2'>${parsedData.ratingsList[count].name.charAt(0)}</div></h1>`;
                                html += `</div>`;
                                html += `<div class='col-11'>`;
                                html += `<div class='card'>`;
                                html += `<div class='card-header'>${parsedData.ratingsList[count].name}</div>`;
                                html += `<div class='card-body'>`;
                                for (let star = 1; star <= 5; star++) {
                                    let className = (parsedData.ratingsList[count].rating >= star) ? 'text-warning' : 'star-light';
                                    html += `<i class="fa fa-star mr-1 ${className}"></i>`;
                                }
                                html += `<br>${parsedData.ratingsList[count].message}</div>`;
                                html += `<div class='card-footer'>${parsedData.ratingsList[count].datetime}</div>`;
                                html += `</div>`;
                                html += `</div>`;
                                html += `</div>`;
                            }
                            $('#display_review').html(html);
                        }
                    }
                });
            }

            loadData();
        });
    </script>
</body>

</html>