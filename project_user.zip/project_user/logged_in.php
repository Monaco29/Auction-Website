<?php
session_start();
ob_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$mail = new PHPMailer(true);

require('bridge.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST["role"];

    $email = mysqli_real_escape_string($connect, $email);
    $password = mysqli_real_escape_string($connect, $password);

    if ($role == "Buyer") {
        $result = mysqli_query($connect, "SELECT a.*, b.buyer_id FROM user a INNER JOIN buyer b ON a.user_id = b.user_id WHERE a.email = '$email' AND a.role = 'Buyer'");
        if ($result) {
            $user = mysqli_fetch_assoc($result);
            if ($user && $password == $user['password']) {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $name = $user['username'];

                $_SESSION['buyer_id'] = $user['buyer_id'];

                try {
                    //Server settings
                    $mail->isSMTP();
                    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'parthkachhadiya04@gmail.com';
                    $mail->Password = 'lipzndqphillnujo';
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                    $mail->Port = 465;

                    $mail->setFrom('parthkachhadiya04@gmail.com', 'Mailer');
                    $mail->addAddress($email, 'Receiver');

                    $mail->isHTML(true);
                    $mail->Subject = "Woohoo! You're In!";
                    $mail->Body = "<p>Hey <strong>" . $email . "</strong>!</p>
                                        <p>Congrats, you nailed it—login success! 💻✨ Go ahead, explore, and make magic happen! Need help? We’ve got your back. 💪</p>
                                        <p>Cheers,<br>
                                        <strong>" . $email . "</strong> 🌟</p>";
                    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

                    $mail->send();
                    header("Location: home.php");
                    exit();
                } catch (Exception $e) {
                    echo "<script>alert('Message could not be sent. Mailer Error: {$mail->ErrorInfo}')</script>";
                }

            } else {
                echo "<script>alert('Invalid email or password')</script>";
                header("Location: user_login.php");
                exit();
            }
        } else {
            echo "<script>alert('Error in query execution.')</script>";
            header("Location: user_login.php");
            exit();
        }
    } else if ($role == "Seller") {
        $result = mysqli_query($connect, "SELECT a.*, b.seller_id FROM user a INNER JOIN seller b ON a.user_id = b.user_id WHERE a.email = '$email' AND a.role = 'Seller'");
        if ($result) {
            $user = mysqli_fetch_assoc($result);
            if ($user && $password == $user['password']) {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['seller_id'] = $user['seller_id'];
                header("Location: seller/home.php");
                exit();
            } else {
                echo "<script>alert('Invalid email or password')</script>";
                header("Location: user_login.php");
                exit();
            }
        } else {
            echo "<script>alert('Error in query execution.')</script>";
            header("Location: user_login.php");
            exit();
        }
    }
}
ob_end_flush();
?>