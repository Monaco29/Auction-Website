<?php

// if (!isset($_GET["auction_id"]) && !isset($_GET["bid_id"]) && !isset($_GET["amount"]))
// {
//     echo "Invalid data..!";
// }
$calculatedAmount = (120 + ((120 * 18) / 100));
$auction_id = $_GET["auction_id"] ?? 9;
$bid_id = $_GET["bid_id"] ?? 39;
$amount = $_GET["amount"] ?? $calculatedAmount;
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <title>Checkout - Razorpay</title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</head>

<body>

    <h2>Proceed to Payment</h2>

    <button id="pay-btn">Pay ₹<?= $amount ?></button>

    <script>
        document.getElementById('pay-btn').onclick = function () {
            var options = {
                "key": "rzp_test_2pM5U6DtYhIKDT", // Replace with your Razorpay Key ID
                "amount": <?= $amount * 100; ?>,
                "currency": "INR",
                "name": "Auction Payment",
                "description": "Payment for winning bid",
                "image": "https://yourdomain.com/logo.png",
                "handler": function (response) {
                    // Redirect or AJAX to record payment
                    window.location.href = "payment_success.php?auction_id=<?= $auction_id ?>&bid_id=<?= $bid_id ?>";
                },
                "prefill": {
                    "name": "Buyer",
                    "email": "buyer@example.com",
                    "contact": "9000000000"
                },
                "theme": {
                    "color": "#3399cc"
                }
            };
            var rzp = new Razorpay(options);
            rzp.open();
        };
    </script>

</body>

</html>