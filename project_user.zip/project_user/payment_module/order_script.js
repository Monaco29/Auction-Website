$(".order").click(function (e) {
  let button = $(this);

  if (!button.hasClass("animate")) {
    button.addClass("animate");
    setTimeout(() => {
      button.removeClass("animate");
      alert("Your package is ready for shipment");
      window.location.href = "track_delivery.php";
    }, 10000);
    alert("Processing your delivery");
  }
});
