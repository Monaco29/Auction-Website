<?php
$auction_id = $_GET['auction_id'] ?? 0;
$bid_id = $_GET['bid_id'] ?? 0;
?>
<!DOCTYPE html>
<html>

<head>
    <title>Payment Failed</title>
</head>

<body>
    <h1>Payment Failed</h1>
    <p>Your payment was not successful. Please try again.</p>
    <a href="checkout.php?auction_id=<?= $auction_id ?>&bid_id=<?= $bid_id ?>">Try Again</a>
</body>

</html>