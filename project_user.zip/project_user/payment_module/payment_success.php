<?php
$auction_id = $_GET['auction_id'] ?? 0;
$bid_id = $_GET['bid_id'] ?? 0;

require_once("../bridge.php");

mysqli_set_charset($connect, "utf8mb4");

// Fetch bid details
$sql = "SELECT * FROM bid WHERE bid_id = ? AND auction_id = ?";
$stmt = mysqli_prepare($connect, $sql);
if (!$stmt) {
    die("<p>Preparation failed: " . mysqli_error($connect) . "</p>");
}
mysqli_stmt_bind_param($stmt, "ii", $bid_id, $auction_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$bid = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if ($bid) {
    // Fetch seller_id from auction -> item -> seller
    $sql = "SELECT i.seller_id, i.name FROM auction a JOIN item i ON a.item_id = i.item_id WHERE a.auction_id = ?";
    $stmt = mysqli_prepare($connect, $sql);
    if (!$stmt) {
        die("<p>Preparation failed: " . mysqli_error($connect) . "</p>");
    }
    mysqli_stmt_bind_param($stmt, "i", $auction_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $seller = mysqli_fetch_assoc($result);
    $t_inv_item_name = $seller["name"];
    mysqli_stmt_close($stmt);

    if ($seller) {
        $t_inv_seller_id = $seller["seller_id"];
        $t_inv_buyer_id = $bid["buyer_id"];

        $with_gst = (($bid["bid_amount"] * 18) / 100);
        $with_platform_charges = ($bid["bid_amount"] * 0.04);
        $final_amount = $bid["bid_amount"] + $with_gst + $with_platform_charges;
        // Insert into transections table
        $sql = "INSERT INTO transections (bid_id, transection_date, amount, buyer_id, seller_id)
                VALUES (?, NOW(), ?, ?, ?)";
        $stmt = mysqli_prepare($connect, $sql);
        if (!$stmt) {
            die("<p>Preparation failed: " . mysqli_error($connect) . "</p>");
        }
        // Assuming bid_amount is numeric; using "d" for a decimal value.
        mysqli_stmt_bind_param($stmt, "idii", $bid_id, $final_amount, $bid['buyer_id'], $seller['seller_id']);
        mysqli_stmt_execute($stmt);
        $transaction_id = mysqli_insert_id($connect);
        mysqli_stmt_close($stmt);

        // Update statuses
        // Update bid: set has_won = 1
        $sql = "UPDATE bid SET has_won = 1 WHERE bid_id = ?";
        $stmt = mysqli_prepare($connect, $sql);
        if (!$stmt) {
            die("<p>Preparation failed: " . mysqli_error($connect) . "</p>");
        }
        mysqli_stmt_bind_param($stmt, "i", $bid_id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Update buyer: deduct bid amount from wallet_balance
        $sql = "UPDATE buyer SET wallet_balance = wallet_balance - ? WHERE buyer_id = ?";
        $stmt = mysqli_prepare($connect, $sql);
        if (!$stmt) {
            die("<p>Preparation failed: " . mysqli_error($connect) . "</p>");
        }
        mysqli_stmt_bind_param($stmt, "di", $bid['bid_amount'], $bid['buyer_id']);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Update seller: add bid amount to total_sales
        $sql = "UPDATE seller SET total_sales = total_sales + ? WHERE seller_id = ?";
        $stmt = mysqli_prepare($connect, $sql);
        if (!$stmt) {
            die("<p>Preparation failed: " . mysqli_error($connect) . "</p>");
        }
        $totalSales = 1;
        mysqli_stmt_bind_param($stmt, "di", $totalSales, $seller['seller_id']);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Fetch buyer's shipping address from user_address
        $sql = "
            SELECT ua.*, ab.username, ab.contect_number, ab.email  
            FROM buyer b
            JOIN user_address ua ON b.user_id = ua.user_id 
            JOIN user ab ON ua.user_id = ab.user_id
            WHERE b.buyer_id = ?
            LIMIT 1
        ";

        $dummy_stmt = "SELECT transection_id FROM transections WHERE buyer_id = $t_inv_buyer_id AND seller_id = $t_inv_seller_id AND bid_id = $bid_id";
        $rrsst = mysqli_fetch_assoc(mysqli_query($connect, $dummy_stmt));
        $t_inv_transection_id = $rrsst["transection_id"];

        $in_revenue = "INSERT INTO revenue(revenue_amount, transection_id) VALUES($with_platform_charges, $t_inv_transection_id)";
        mysqli_query($connect, $in_revenue);

        $sql2_seller_details = "SELECT * FROM seller WHERE seller_id = $t_inv_seller_id";
        $seller_address = mysqli_fetch_assoc(mysqli_query($connect, $sql2_seller_details));


        $insert_into_invoice = "INSERT INTO invoice(transaction_id, total_amount, status, buyer_id, seller_id) VALUES($t_inv_transection_id, $final_amount, 'Paid', $t_inv_buyer_id, $t_inv_seller_id)";
        mysqli_query($connect, $insert_into_invoice);

        $stmt = mysqli_prepare($connect, $sql);
        if (!$stmt) {
            die("<p>Preparation failed: " . mysqli_error($connect) . "</p>");
        }
        mysqli_stmt_bind_param($stmt, "i", $bid['buyer_id']);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $address = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        $getInvoiceData = "SELECT * FROM invoice WHERE buyer_id = $t_inv_buyer_id AND seller_id = $t_inv_seller_id AND total_amount = $final_amount AND transaction_id = $t_inv_transection_id";
        $resultOfInvoice = mysqli_fetch_assoc(mysqli_query($connect, $getInvoiceData));


        if ($address) {
            // Generate delivery tracking data
            $tracking_number = 'TRK' . strtoupper(uniqid());
            $courier_name = 'DemoCourier';
            $courier_api_url = 'https://demo.courier.api/track/' . $tracking_number;
            $estimated_delivery_date = date('Y-m-d', strtotime('+4 days'));
            $current_status = 'Pending';

            // Insert into delivery_tracking
            $sql = "INSERT INTO delivery_tracking (
                        transaction_id, buyer_id, shipping_address, city, state, pincode, country,
                        current_status, tracking_details, estimated_delivery_date, updated_at,
                        tracking_number, courier_name, courier_api_url
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, NOW(),
                        ?, ?, ?
                    )";
            $stmt = mysqli_prepare($connect, $sql);
            if (!$stmt) {
                die("<p>Preparation failed: " . mysqli_error($connect) . "</p>");
            }
            $desc = 'Package is being prepared for shipment.';
            mysqli_stmt_bind_param(
                $stmt,
                "iisssssssssss",
                $transaction_id,
                $bid['buyer_id'],
                $address['address'],
                $address['city'],
                $address['state'],
                $address['pincode'],
                $address['country'],
                $current_status,
                $desc,
                $estimated_delivery_date,
                $tracking_number,
                $courier_name,
                $courier_api_url
            );
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }

        // echo "<h1>Payment Successful!</h1><p>Transaction and Delivery tracking have been recorded.</p>";
        // echo "<p><a href='track_delivery.php'>Track Your Order</a></p>";
    } else {
        echo "Seller not found!";
    }
} else {
    echo "Invalid bid or auction!";
}

// Close the database connection
mysqli_close($connect);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>CodeByGaurav - Order confirm animation</title>
    <link rel="stylesheet" href="order_style.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&amp;display=swap" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 15px;
            flex-direction: column;
        }

        :root {
            --blue-color: #0c2f54;
            --dark-color: #535b61;
            --white-color: #fff;
        }

        ul {
            list-style-type: none;
        }

        ul li {
            margin: 2px 0;
        }

        /* text colors */
        .text-dark {
            color: var(--dark-color);
        }

        .text-blue {
            color: var(--blue-color);
        }

        .text-end {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .text-start {
            text-align: left;
        }

        .text-bold {
            font-weight: 700;
        }

        /* hr line */
        .hr {
            height: 1px;
            background-color: rgba(0, 0, 0, 0.1);
        }

        /* border-bottom */
        .border-bottom {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }


        .invoice-wrapper {
            min-height: 100vh;
            padding-top: 20px;
            padding-bottom: 20px;
        }

        .invoice {
            max-width: 850px;
            margin-right: auto;
            margin-left: auto;
            background-color: var(--white-color);
            padding: 70px;
            border: 1px solid rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            min-height: 920px;
        }

        .invoice-head-top-left img {
            width: 130px;
        }

        .invoice-head-top-right h3 {
            font-weight: 500;
            font-size: 27px;
            color: var(--blue-color);
        }

        .invoice-head-middle,
        .invoice-head-bottom {
            padding: 16px 0;
        }

        .invoice-body {
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 4px;
            overflow: hidden;
        }

        .invoice-body table {
            border-collapse: collapse;
            border-radius: 4px;
            width: 100%;
        }

        .invoice-body table td,
        .invoice-body table th {
            padding: 12px;
        }

        .invoice-body table tr {
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }

        .invoice-body table thead {
            background-color: rgba(0, 0, 0, 0.02);
        }

        .invoice-body-info-item {
            display: grid;
            grid-template-columns: 80% 20%;
        }

        .invoice-body-info-item .info-item-td {
            padding: 12px;
            background-color: rgba(0, 0, 0, 0.02);
        }

        .invoice-foot {
            padding: 30px 0;
        }

        .invoice-foot p {
            font-size: 12px;
        }

        .invoice-btns {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }

        .invoice-btn {
            padding: 3px 9px;
            color: var(--dark-color);
            font-family: inherit;
            border: 1px solid rgba(0, 0, 0, 0.1);
            cursor: pointer;
        }

        .invoice-head-top,
        .invoice-head-middle,
        .invoice-head-bottom {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            padding-bottom: 10px;
        }

        @media screen and (max-width: 992px) {
            .invoice {
                padding: 40px;
            }
        }

        @media screen and (max-width: 576px) {

            .invoice-head-top,
            .invoice-head-middle,
            .invoice-head-bottom {
                grid-template-columns: repeat(1, 1fr);
            }

            .invoice-head-bottom-right {
                margin-top: 12px;
                margin-bottom: 12px;
            }

            .invoice * {
                text-align: left;
            }

            .invoice {
                padding: 28px;
            }
        }

        .overflow-view {
            overflow-x: scroll;
        }

        .invoice-body {
            min-width: 600px;
        }

        @media print {
            .print-area {
                visibility: visible;
                width: 100%;
                position: absolute;
                left: 0;
                top: 0;
                overflow: hidden;
            }

            .overflow-view {
                overflow-x: hidden;
            }

            .invoice-btns {
                display: none;
            }
        }

        .custom-button {
            width: 40%;
            padding: 12px;
            font-size: 1rem;
            font-weight: bold;
            font-family: 'Poppins', sans-serif;
            border-radius: 8px;
            cursor: pointer;
            color: white;
            /* Button text color */
            border: 2px solid #007bff;
            /* Blue border */
            background: #007bff;
            /* Blue background */
            margin-top: 20px;
            /* Space between buttons */
            transition: all 0.3s ease-in-out;
            /* Smooth hover effects */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            /* Subtle shadow */
        }

        /* Hover Effect */
        .custom-button:hover {
            background: white;
            /* Invert colors on hover */
            color: #007bff;
            /* Blue text on hover */
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            /* Enhance shadow on hover */
        }

        /* Active Effect */
        .custom-button:active {
            background: #0056b3;
            /* Darker blue when clicked */
            color: white;
            transform: scale(0.98);
            /* Slightly shrink the button */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            /* Reduce shadow */
        }

        .business-name {
            font-size: 36px;
            font-weight: bold;
            color: #4A90E2;
            text-transform: uppercase;
            letter-spacing: 2px;
            font-family: "Poetsen One", sans-serif;
            font-weight: 400;
            font-style: normal;
        }
    </style>

</head>

<body>

    <div class="invoice-wrapper" id="print-area">
        <div class="invoice">
            <div class="invoice-container">
                <div class="invoice-head">
                    <div class="invoice-head-top">
                        <div class="invoice-head-top-left text-start">
                            <div class="business-name"><?= $seller_address["business_name"]; ?></div>
                        </div>
                        <div class="invoice-head-top-right text-end">
                            <h3>Invoice</h3>
                        </div>
                    </div>
                    <div class="hr"></div>
                    <div class="invoice-head-middle">
                        <div class="invoice-head-middle-left text-start">
                            <p><span class="text-bold">Date: </span><?= $resultOfInvoice["invoice_date"]; ?></p>
                        </div>
                        <div class="invoice-head-middle-right text-end">
                            <p>
                                <spanf class="text-bold">Invoice No: </span><?= $resultOfInvoice["invoice_id"]; ?>
                            </p>
                        </div>
                    </div>
                    <div class="hr"></div>
                    <div class="invoice-head-bottom">
                        <div class="invoice-head-bottom-left">
                            <ul>
                                <li class='text-bold'>Invoiced To:</li>
                                <li><?= $address["username"]; ?></li>
                                <li><?= $address["address"]; ?></li>
                                <li><?= $address["city"]; ?> : <?= $address["pincode"]; ?></li>
                                <li><?= $address["state"]; ?>, <?= $address["country"]; ?></li>
                                <li><?= $address["email"]; ?>, <?= $address["contect_number"]; ?></li>
                            </ul>
                        </div>
                        <div class="invoice-head-bottom-right">
                            <ul class="text-end">
                                <li class='text-bold'>Pay To:</li>
                                <li><?= $seller_address["business_name"]; ?></li>
                                <li><?= $seller_address["business_address"]; ?></li>
                                <li><?= $seller_address["business_email"]; ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="overflow-view">
                    <div class="invoice-body">
                        <table>
                            <thead>
                                <tr>
                                    <td class="text-bold">Invoice number</td>
                                    <td class="text-bold">Name</td>
                                    <td class="text-bold">QTY</td>
                                    <td class="text-bold">Amount</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?= $resultOfInvoice["invoice_id"]; ?></td>
                                    <td><?= $t_inv_item_name; ?></td>
                                    <td>1</td>
                                    <td><?= $bid["bid_amount"]; ?></td>
                                </tr>

                            </tbody>
                        </table>
                        <div class="invoice-body-bottom">
                            <div class="invoice-body-info-item border-bottom">
                                <div class="info-item-td text-end text-bold">Sub Total:</div>
                                <div class="info-item-td text-end"><?= $bid["bid_amount"]; ?></div>
                            </div>
                            <div class="invoice-body-info-item border-bottom">
                                <div class="info-item-td text-end text-bold">GST(18%):</div>
                                <div class="info-item-td text-end"><?= $with_gst; ?></div>
                            </div>
                            <div class="invoice-body-info-item border-bottom">
                                <div class="info-item-td text-end text-bold">Pltform Charge(4%):</div>
                                <div class="info-item-td text-end"><?= $with_platform_charges; ?></div>
                            </div>
                            <div class="invoice-body-info-item">
                                <div class="info-item-td text-end text-bold">Total:</div>
                                <div class="info-item-td text-end"><?= $resultOfInvoice["total_amount"]; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="invoice-foot text-center">
                    <p><span class="text-bold text-center">NOTE:&nbsp;</span>This is computer generated receipt and does
                        not require physical signature.</p>

                    <div class="invoice-btns">
                        <button type="button" class="invoice-btn custom-button" onclick="downloadInvoice()">
                            <span>
                                <i class="fa-solid fa-print"></i>
                            </span>
                            <span>🖨️ or 📁</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <button class="order">
        <span class="default">Complete Order</span>
        <span class="success">Order Placed
            <svg viewbox="0 0 12 10">
                <polyline points="1.5 6 4.5 9 10.5 1"></polyline>
            </svg>
        </span>
        <div class="box"></div>
        <div class="truck">
            <div class="back"></div>
            <div class="front">
                <div class="window"></div>
            </div>
            <div class="light top"></div>
            <div class="light bottom"></div>
        </div>
        <div class="lines"></div>
    </button>
    <script>
        function downloadInvoice() {
            const element = document.getElementById('print-area');
            let ele = document.getElementsByClassName("invoice-btns")[0].style.display = 'none';
            var opt = {
                margin: 0.5,
                filename: 'invoice_<?= $t_inv_buyer_id; ?>.pdf',
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }

        $(".order").click(function (e) {
            let button = $(this);

            if (!button.hasClass("animate")) {
                button.addClass("animate");
                setTimeout(() => {
                    button.removeClass("animate");
                    alert("Your package is ready for shipment");
                    window.location.href = "track_delivery.php";
                }, 10000);
                alert("Processing your delivery");
            }
        });
    </script>
</body>

</html>