<?php
session_start();
require_once('../bridge.php');

$user_id = $_SESSION['user_id'] ?? 3;

// Determine if user is a buyer
$stmt = mysqli_prepare($connect, "SELECT * FROM buyer WHERE user_id = ?");
if (!$stmt) {
    die("<div class='container mt-5 alert alert-warning'>Preparation failed: " . mysqli_error($connect) . "</div>");
}
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$isBuyer = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$isBuyer) {
    echo "<div class='container mt-5 alert alert-warning'>Only buyers can access delivery tracking.</div>";
    exit();
}

// Fetch delivery record
$sql = "
    SELECT dt.*, u.user_id AS buyer_name, u.email AS buyer_email
    FROM delivery_tracking dt
    JOIN buyer b ON dt.buyer_id = b.buyer_id
    JOIN user u ON b.user_id = u.user_id
    WHERE dt.buyer_id = ?
";
$stmt = mysqli_prepare($connect, $sql);
if (!$stmt) {
    die("<div class='container mt-5 alert alert-warning'>Preparation failed: " . mysqli_error($connect) . "</div>");
}
mysqli_stmt_bind_param($stmt, "i", $isBuyer['buyer_id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$delivery = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Auto update delivery status based on estimated delivery date
if ($delivery) {
    $today = date_create(date('Y-m-d'));
    $delivery_date = date_create($delivery['estimated_delivery_date']);
    $diff = date_diff($today, $delivery_date);
    $days_left = (int) $diff->format("%R%a");

    if ($days_left <= 0) {
        $new_status = 'Delivered';
    } elseif ($days_left == 1) {
        $new_status = 'Out for Delivery';
    } elseif ($days_left == 2) {
        $new_status = 'Shipped';
    } else {
        $new_status = 'Pending';
    }

    // Update only if status changed
    if ($new_status !== $delivery['current_status']) {
        $update = mysqli_prepare($connect, "UPDATE delivery_tracking SET current_status = ?, updated_at = NOW() WHERE delivery_id = ?");
        if (!$update) {
            die("<div class='container mt-5 alert alert-warning'>Preparation failed: " . mysqli_error($connect) . "</div>");
        }
        mysqli_stmt_bind_param($update, "si", $new_status, $delivery['delivery_id']);
        mysqli_stmt_execute($update);
        mysqli_stmt_close($update);

        // Refresh the delivery object after update by re-preparing the SELECT query
        $stmt = mysqli_prepare($connect, $sql);
        if (!$stmt) {
            die("<div class='container mt-5 alert alert-warning'>Preparation failed: " . mysqli_error($connect) . "</div>");
        }
        mysqli_stmt_bind_param($stmt, "i", $isBuyer['buyer_id']);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $delivery = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);
    }
}

// Progress bar helper function
function getProgressPercentage($status)
{
    $map = [
        'Pending' => 12,
        'Shipped' => 25,
        'Out for Delivery' => 75,
        'Delivered' => 100,
        'Cancelled' => 100
    ];
    return isset($map[$status]) ? $map[$status] : 0;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Track Your Delivery</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --success-color: #4cc9f0;
            --dark-color: #2b2d42;
            --light-color: #f8f9fa;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f1f5f9;
        }

        .delivery-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease;
        }

        .delivery-card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 1.5rem;
            border-bottom: none;
        }

        .progress {
            height: 30px;
            border-radius: 15px;
            background-color: #e9ecef;
        }

        .progress-bar {
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: width 1s ease;
        }

        .info-badge {
            background-color: #e9f7fe;
            color: var(--primary-color);
            padding: 0.5rem 1rem;
            border-radius: 50px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .rating-form {
            background-color: #f8fafc;
            border-radius: 10px;
            padding: 1.5rem;
            margin-top: 1.5rem;
        }

        .btn-track {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 0.5rem 1.5rem;
            border-radius: 50px;
            transition: all 0.3s ease;
        }

        .btn-track:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(67, 97, 238, 0.3);
        }

        .delivery-details {
            background-color: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .detail-label {
            color: #64748b;
            font-weight: 500;
            margin-bottom: 0.25rem;
        }

        .detail-value {
            font-weight: 600;
            color: var(--dark-color);
            margin-bottom: 1rem;
        }

        #exit-button {
            position: fixed;
            top: 10px;
            right: 10px;
            z-index: 1000;
            padding: 10px 20px;
            background: #e91e63;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-family: "Poppins", sans-serif;
            font-weight: bold;
            cursor: pointer;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        #exit-button:hover {
            transform: scale(1.05);
            box-shadow: 0px 6px 10px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>

<button id="exit-button"
    style="padding: 10px; background: #e91e63; color: #fff; border: none; border-radius: 8px; font-size: 1rem; font-weight: bold; cursor: pointer;">
    Home
</button>

<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card delivery-card">
                    <div class="card-header">
                        <h2 class="mb-0"><i class="fas fa-truck me-2"></i>Track Your Delivery</h2>
                    </div>

                    <div class="card-body p-4">
                        <?php if ($delivery): ?>
                            <div class="delivery-details">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="detail-label">Transaction ID</div>
                                        <div class="detail-value">
                                            <span class="info-badge">
                                                <i class="fas fa-receipt"></i>
                                                <?= htmlspecialchars($delivery['transaction_id']) ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="detail-label">Estimated Delivery</div>
                                        <div class="detail-value">
                                            <i class="far fa-calendar-alt me-2 text-primary"></i>
                                            <?= htmlspecialchars($delivery['estimated_delivery_date']) ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-4">
                                    <div class="detail-label">Shipping Address</div>
                                    <div class="detail-value">
                                        <i class="fas fa-map-marker-alt text-danger me-2"></i>
                                        <?= nl2br(htmlspecialchars($delivery['shipping_address'])) ?>, <br>
                                        <?= htmlspecialchars($delivery['city']) ?>,
                                        <?= htmlspecialchars($delivery['state']) ?> -
                                        <?= htmlspecialchars($delivery['pincode']) ?>
                                    </div>
                                </div>

                                <div class="mb-4">
                                    <div class="detail-label">Delivery Status</div>
                                    <div class="progress mt-2">
                                        <div class="progress-bar <?= ($delivery['current_status'] == 'Cancelled') ? 'bg-danger' : 'bg-success' ?>"
                                            role="progressbar"
                                            style="width: <?= getProgressPercentage(($delivery['current_status'])) ?>%;"
                                            aria-valuenow="<?= getProgressPercentage($delivery['current_status']) ?>"
                                            aria-valuemin="0" aria-valuemax="100">
                                            <?= htmlspecialchars($delivery['current_status']) ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <div class="detail-label">Tracking Number</div>
                                        <div class="detail-value">
                                            <span class="info-badge">
                                                <i class="fas fa-barcode"></i>
                                                <?= htmlspecialchars($delivery['tracking_number']) ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="detail-label">Courier Service</div>
                                        <div class="detail-value">
                                            <i class="fas fa-shipping-fast me-2 text-primary"></i>
                                            <?= htmlspecialchars($delivery['courier_name']) ?>
                                        </div>
                                    </div>
                                </div>

                                <?php if (!empty($delivery['courier_api_url'])): ?>
                                    <div class="text-center mt-4">
                                        <a href="<?= htmlspecialchars($delivery['courier_api_url']) ?>" target="_blank"
                                            class="btn btn-track">
                                            <i class="fas fa-external-link-alt me-2"></i>
                                            Track via <?= htmlspecialchars($delivery['courier_name']) ?> Website
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <?php if ($delivery['current_status'] == 'Delivered'): ?>
                                <div class="rating-form">
                                    <h5 class="mb-3"><i class="fas fa-star text-warning me-2"></i>Rate Your Delivery Experience
                                    </h5>
                                    <form action="submit_rating.php" method="post">
                                        <input type="hidden" name="delivery_id" value="<?= $delivery['delivery_id'] ?>">

                                        <div class="mb-3">
                                            <label for="rating" class="form-label">Rating</label>
                                            <select name="rating" class="form-select" required>
                                                <option value="">Select Rating</option>
                                                <option value="5">⭐️⭐️⭐️⭐️⭐️ Excellent</option>
                                                <option value="4">⭐️⭐️⭐️⭐️ Good</option>
                                                <option value="3">⭐️⭐️⭐️ Average</option>
                                                <option value="2">⭐️⭐️ Poor</option>
                                                <option value="1">⭐️ Bad</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="review" class="form-label">Review (Optional)</label>
                                            <textarea name="review" class="form-control" rows="3"
                                                placeholder="How was your delivery experience?"></textarea>
                                        </div>

                                        <div class="text-end">
                                            <button type="submit" class="btn btn-warning px-4">
                                                <i class="fas fa-paper-plane me-2"></i>Submit Rating
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>

                        <?php else: ?>
                            <div class="alert alert-info d-flex align-items-center">
                                <i class="fas fa-info-circle me-2"></i>
                                No delivery record found for your account.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById("exit-button").addEventListener("click", function () {
            window.location.href = '../buyer/home.php';
        });
    </script>
</body>

</html>