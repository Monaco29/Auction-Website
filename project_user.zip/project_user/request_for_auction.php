<?php
require_once("bridge.php");

if (isset($_GET["item_id"]) && isset($_GET["buyer_id"])) {
    $buyer = $_GET["buyer_id"];
    $product = $_GET["item_id"];
    $result = mysqli_query($connect, "SELECT * FROM auction_registration WHERE item_id = $product AND buyer_id = $buyer");
    if (mysqli_num_rows($result) > 0) {
        $stat = mysqli_fetch_assoc($result)["status"];
        echo json_encode(['status' => 'sent', 'message' => "Your request is currently $stat"]);
    } else {
        $auction_id = mysqli_fetch_assoc(mysqli_query($connect, "SELECT auction_id FROM auction WHERE item_id = $product"))["auction_id"];

        $query = "INSERT INTO auction_registration(auction_id, buyer_id, item_id, status) VALUES($auction_id, $buyer, $product, 'Pending')";
        if (mysqli_query($connect, $query)) {
            echo json_encode(['status' => 'success', 'message' => 'Your request for auction has been sent..']);
        } else {
            echo json_encode(['status' => 'failure', 'message' => 'Something went wrong.!!']);
        }
    }
} else {
    echo json_encode(['status' => 'err', 'message' => 'Value not found !!']);
}
?>