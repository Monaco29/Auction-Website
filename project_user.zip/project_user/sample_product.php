<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advanced Product Details</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .product-card {
            display: flex;
            flex-direction: row;
            border: 1px solid #ccc;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .product-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .product-image {
            flex: 1;
        }

        .product-details {
            flex: 2;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .product-title {
            margin-top: 0;
            font-size: 2rem;
        }

        .product-price {
            font-size: 1.5rem;
            color: #28a745;
        }

        .product-description {
            margin-top: 10px;
            font-size: 1rem;
            color: #555;
        }

        .buy-now {
            margin-top: 20px;
            align-self: flex-start;
            transition: background-color 0.3s, transform 0.3s;
        }

        .buy-now:hover {
            background-color: #218838;
            transform: translateY(-2px);
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="product-card">
            <div class="product-image">
                <img src="../final_sem_project/uploaded_images/figher.jpg" class="img-fluid">
            </div>
            <div class="product-details">
                <h1 class="product-title">Product Title</h1>
                <p class="product-price">$99.99</p>
                <p class="product-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis nec risus dapibus, tincidunt libero at, aliquet mauris.</p>
                <button class="btn btn-primary buy-now">Buy Now</button>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const button = document.querySelector('.buy-now');
            button.addEventListener('click', function() {
                alert('Thank you for your purchase!');
            });
        });
    </script>
</body>

</html>