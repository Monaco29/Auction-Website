<?php
require_once("../bridge.php");
session_start();


if (isset($_SESSION["seller_id"]) && isset($_SESSION["item_id"]) && isset($_SESSION["auction_id"])) {
    $sellerID = $_SESSION["seller_id"];
    $itemID = $_SESSION["item_id"];
    $auctionID = $_SESSION["auction_id"];
} else {
    header("Location: home.php");
    exit();
}

$query = "SELECT * FROM item WHERE item_id = $itemID";
$result = mysqli_query($connect, $query);
$item = mysqli_fetch_assoc($result);

$currentBidQuery = "SELECT MAX(bid_amount) AS highest_bid FROM bid WHERE auction_id = $auctionID";
$currentBidResult = mysqli_query($connect, $currentBidQuery);
$currentBidRow = mysqli_fetch_assoc($currentBidResult);
$highestBid = $currentBidRow["highest_bid"] ?? $item["start_price"];

// -----------------
$qry1 = "SELECT p.name, p.description, p.start_price, p.picture, c.name AS category_name 
              FROM item p
              LEFT JOIN category c ON p.category_id = c.category_id
              JOIN auction_registration d ON d.item_id = p.item_id 
              WHERE d.auction_id = $auctionID";
$qry2 = "SELECT a.*, b.business_name, b.business_email FROM user a JOIN seller b ON a.user_id = b.user_id JOIN item c ON b.seller_id = c.seller_id WHERE c.item_id = $itemID";
$rst = mysqli_query($connect, $qry1);
$row1 = mysqli_fetch_assoc($rst);
$rst2 = mysqli_query($connect, $qry2);
$row2 = mysqli_fetch_assoc($rst2);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Side Auction Room</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=FontName&display=swap">
    <link rel="stylesheet" href="../auction_room/base_style.css">
    <style>
        .product {
            position: relative;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 600px;
            height: 400px;
            background: #fff;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.25);
            border: 1px solid black;
            border-radius: 5px;
            overflow: hidden;
        }

        .product .imgbox {
            height: 100%;
            box-sizing: border-box;
        }

        .product .imgbox img {
            display: block;
            width: 90%;
            margin: 20px auto 0px;
        }

        .details {
            position: absolute;
            width: 100%;
            bottom: -314px;
            background: #fff;
            padding: 10px;
            box-sizing: border-box;
            box-shadow: 0 0 0 rgba(0, 0, 0, 0);
            transition: .5s;
        }

        .product:hover .details {
            bottom: -100px;
            box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.25);
        }

        .details h2 {
            margin: 0;
            padding: 0;
            font-size: 17px;
            width: 100%;
            font-weight: bold;
            font-family: cursive, 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
        }

        .details h2 span {
            font-size: 14px;
            font-family: "Gill Sans", "Gill Sans MT", Calibri, "Trebuchet MS", sans-serif;
            font-weight: lighter;
        }

        .details .price {
            position: absolute;
            top: 10px;
            right: 20px;
            font-weight: bold;
            color: green;
            font-family: "Courier New", Courier, monospace;
        }

        #seller-block {
            display: block;
            position: relative;
            width: 300px;
            padding: 15px;
            bottom: 120px;
            left: 250px;
            border: 1px solid black;
            border-radius: 10px;
        }

        .live-bid-panel {
            height: 90px;
            width: 270px;
            font-weight: bolder;
            padding: 10px;
            font-family: "Courier New", Courier, monospace;
            color: green;
            position: fixed;
            z-index: 1;
            background-color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 36px;
            top: 57%;
            border: 1px solid black;
            left: 41%;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <div class="live-bid-panel"></div>

    <div class="container-fluid">
        <div class="row h-100">
            <!-- LEFT COLUMN: JOINED BUYERS -->
            <div class="col-md-3 full-height">
                <div class="block full-height">
                    <h5 class="text-center">JOINED BUYERS</h5>
                    <div id="buyer-list" class="mt-3" style="max-height: 80%; overflow-y: auto; padding: 10px;"></div>
                </div>
            </div>

            <!-- CENTER COLUMN  style="background: #e3edf7;" -->
            <div class="col-md-6 mid-col">
                <!-- TOP: PRODUCT DETAILS -->
                <div class="block product-block">
                    <!-- Product Image -->
                    <div class="product">
                        <div class="imgbox">
                            <img src="../../final_sem_project/uploaded_images/<?= $row1['picture'] ?>"
                                alt="No image found..!">
                        </div>
                        <div class="details">
                            <h2>Product Name: <br><span><?= $row1["name"]; ?></span></h2>
                            <div class="price">₹ <?= number_format($row1["start_price"]); ?></div><br>
                            <h2>Product Category: <br><span><?= $row1["category_name"]; ?></span></h2><br>
                            <h2>Description: <br><span><?= $row1["description"]; ?></span></h2>
                            <span id="seller-block">
                                <h2 style="font-size: 16px;">Seller details</h2>
                                <hr>
                                <h3 style="font-size: 13px; font-family: cursive; font-weight: bold;">Name: <span
                                        style="font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif; font-weight: normal;"><?= $row2['username']; ?></span>
                                </h3>
                                <h3 style="font-size: 13px; font-family: cursive; font-weight: bold;">Mobilenumber:
                                    <span
                                        style="font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif; font-weight: normal;"><?= $row2['contect_number']; ?></span>
                                </h3>
                                <h3 style="font-size: 13px; font-family: cursive; font-weight: bold;">Business Name:
                                    <span
                                        style="font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif; font-weight: normal;"><?= $row2['business_name']; ?></span>
                                </h3>
                                <h3 style="font-size: 13px; font-family: cursive; font-weight: bold;">Business Email:
                                    <span
                                        style="font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif; font-weight: normal;"><?= $row2['business_email']; ?></span>
                                </h3>
                            </span>
                        </div>
                    </div>
                </div>


                <!-- BELOW: Horizontal Alignment of BID TIMER and PUT BID FORM -->
                <div class="block timer_form" style="background:rgb(243, 248, 252);">
                    <div class="vertical-block"
                        style="display: flex; flex-direction: row; align-items: center; justify-content: center; margin-top: 30px;">
                        <!-- Top Section: Timer -->
                        <div class="timer-section" style="margin-left: 10px; padding: 10px;">
                            <div class="skill">
                                <div class="outer">
                                    <div class="inner">
                                        <div id="number"></div>
                                    </div>
                                </div>
                                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="160px" height="160px">
                                    <defs>
                                        <linearGradient id="GradientColor">
                                            <stop offset="0%" stop-color="#e91e63" />
                                            <stop offset="100%" stop-color="#673ab7" />
                                        </linearGradient>
                                    </defs>
                                    <circle cx="80" cy="80" r="70" stroke-linecap="round"
                                        transform="rotate(-90 80 80)" />
                                </svg>
                            </div>
                        </div>

                        <!-- Bottom Section: Bid Form -->
                        <div class="bid-form-section" style="padding-top: 20px; margin-left: 160px;">
                            <form class="seller-control-form">
                                <button type="button" id="start-auction" class="custom-button start-btn">
                                    Start Auction
                                </button>
                                <button type="button" id="end-auction" class="custom-button end-btn">
                                    End Auction
                                </button>
                            </form>
                        </div>


                    </div>

                </div>
            </div>

            <button id="exit-button"
                style="padding: 10px 20px; background: #e91e63; color: #fff; border: none; border-radius: 8px; font-size: 1rem; font-weight: bold; cursor: pointer;">
                Exit
            </button>

            <!-- RIGHT COLUMN: UPLOADED BIDS -->
            <!-- Component 2: UPLOADED BIDS Section -->
            <div class="col-md-3 full-height">
                <div class="block full-height">
                    <h5 class="text-center" style="font-family: 'Poppins', sans-serif; font-weight: bold; color: #333;">
                        UPLOADED BIDS</h5>

                    <!-- Container for dynamically updated bids -->
                    <ul id="bid-feed" class="list-group"
                        style="margin-top: 10px; padding: 3; list-style: none; background: #ffffff; border-radius: 10px;">
                        <!-- Dynamic bids will be appended here -->
                    </ul>
                </div>
            </div>

        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(function () {

            document.getElementById("exit-button").addEventListener("click", function () {
                if (confirm("Auction will be officially terminated, do you want to proceed ??")) {
                    stopTimer();
                    endAuction();
                    window.location.href = "../auction_room/winner_panel.php";
                }
            });

            function fetchActiveBuyers() {
                $.ajax({
                    url: '../auction_room/fetch_buyers.php', // Endpoint to fetch buyer data
                    method: 'GET',
                    data: { auction_id: "<?php echo $auctionID; ?>" },
                    success: function (response) {
                        var buyerList = $('#buyer-list');
                        buyerList.empty();

                        response.forEach(function (buyer) {
                            var statusText = buyer.is_typing == "1" ? "Typing..." : "👁️";
                            var statusColor = buyer.is_typing == "1" ? "green" : "#666";

                            var buyerDiv = `
                            <div class="d-flex align-items-center mb-4 user_data_container">
                                <!-- Left-Side Image -->
                                <img src="../../final_sem_project/uploaded_images/${buyer.profile_pic}" alt="${buyer.buyer_name}" 
                                    style="width: 50px; height: 50px; border-radius: 50%; margin-right: 20px; object-fit: cover;">
                                
                                <!-- Buyer Details -->
                                <div>
                                    <div style="font-family: 'Raleway', sans-serif; font-weight: bold; font-size: 1.2rem;">${buyer.buyer_name}</div>
                                    <div style="font-size: 0.9rem; color: ${statusColor};">${statusText}</div>
                                </div>
                            </div>`;
                            buyerList.append(buyerDiv);
                        });
                    },
                    error: function (xhr, status, error) {
                        console.error("Error fetching buyers:", error);
                    }
                });
            }

            let number = document.getElementById("number");
            let circle = document.querySelector("circle");
            let timerInterval = undefined;

            function startCountdownFromAuction(auctionStart, auctionEnd, totalStroke = 472) {
                clearInterval(timerInterval);

                const totalDuration = auctionEnd - auctionStart;

                circle.style.strokeDashoffset = 472;

                const updateTimerDisplay = (time) => {
                    const minutes = Math.floor(time / 60);
                    const seconds = time % 60;
                    number.innerHTML = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                };

                let cTime = Math.floor(Date.now() / 1000);
                let rTime = auctionEnd - cTime;
                updateTimerDisplay(rTime);

                timerInterval = setInterval(() => {
                    let currentTime = Math.floor(Date.now() / 1000);
                    let remainedTime = auctionEnd - currentTime;
                    let passedTime = currentTime - auctionStart;
                    let passedStroke = ((passedTime * totalStroke) / totalDuration);
                    console.log(`CurrentTime: ${currentTime}, TotalTime: ${totalDuration}, RemainedTime: ${remainedTime}, PassedTime: ${passedTime}, AuctionStart: ${auctionStart}, AuctionEnd: ${auctionEnd}`);
                    if (remainedTime <= 0) {
                        clearInterval(timerInterval);
                        number.innerHTML = "00:00";
                        circle.style.strokeDashoffset = totalStroke;
                        alert("Auction closed..!");
                        endAuction();
                    } else {
                        updateTimerDisplay(remainedTime);
                        circle.style.strokeDashoffset = (totalStroke - passedStroke);
                    }
                }, 1000);
            }

            function stopTimer() {
                if (timerInterval) {
                    clearInterval(timerInterval);
                    timerInterval = null;
                }

                number.innerHTML = "00:00";
                circle.style.strokeDashoffset = 0;
                console.log("Timer has been stopped and reset to 00:00.");
            }


            function fetchAuctionTimer() {
                $.ajax({
                    url: '../auction_room/initialize_timer.php',
                    method: 'GET',
                    success: function (response) {
                        console.log(response);
                        const result = JSON.parse(response);

                        if (result.success) {
                            const auctionStart = Math.floor(Date.parse(result.auction_start) / 1000); // Convert to Unix timestamp
                            const auctionEnd = Math.floor(Date.parse(result.auction_end) / 1000);
                            startCountdownFromAuction(auctionStart, auctionEnd);
                        } else {
                            alert("Failed to fetch timer data: " + result.message);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error("Error fetching timer data:", error);
                    }
                });
            }

            function endAuction() {
                $.ajax({
                    url: 'end_auction.php',
                    method: 'POST',
                    data: { auction_id: "<?php echo $_SESSION['auction_id']; ?>", item_id: "<?= $itemID; ?>" },
                    success: function (response) {
                        const result = JSON.parse(response);

                        if (result.status == "success") {
                            alert("Auction has ended successfully!");
                            window.location.href = "winner_panel.php";
                        } else {
                            alert("Error ending the auction: " + result.message);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error("Error ending auction:", error);
                    }
                });
            }

            function fetchCurrentBid(callback) {
                $.ajax({
                    url: '../auction_room/fetch_highest_bid.php',
                    method: 'GET',
                    data: { auction_id: "<?php echo $auctionID; ?>" },
                    dataType: 'json',
                    success: function (response) {
                        console.log("Parsed Response:", response);
                        var currentBid = response.highest_bid || <?php echo $item["start_price"]; ?>;
                        console.log("Current Bid:", currentBid);
                        callback(currentBid);
                    },
                    error: function (xhr, status, error) {
                        console.error("AJAX Error:", {
                            status: status,
                            error: error,
                            responseText: xhr.responseText
                        });
                        alert("Error fetching the current bid. Please check the console.");
                    }
                });
            }

            function fetchLiveBids() {
                $.ajax({
                    url: '../auction_room/fetch_bid_feed.php',
                    method: 'GET',
                    data: { auction_id: "<?php echo $auctionID; ?>" },
                    success: function (response) {
                        var bids = JSON.parse(response);
                        var bidFeed = $('#bid-feed');
                        bidFeed.empty();

                        bids.forEach(function (bid) {
                            var bidItem = `
                    <li class="list-group-item" 
                        style="font-family: 'Poppins', sans-serif; font-size: 1rem; color: #333; padding: 13px; border-radius: 5px; margin-bottom: 15px; background: #f7f9fc; box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); margin-top: 10px; border: none;">
                        <div class="d-flex align-items-center">
                            <img src="../../final_sem_project/uploaded_images/${bid.profile_pic}" alt="${bid.buyer_name}" 
                                style="width: 40px; height: 40px; border-radius: 50%; margin-right: 25px; object-fit: cover;">
                            <div>
                                <strong style="font-weight: normal; font-family: cursive;">${bid.buyer_name}:</strong><span class="few-more">₹ ${bid.bid_amount} </span>
                                <div style="font-size: 0.8rem; color: #666;">${bid.bid_time}</div>
                            </div>
                        </div>
                    </li>`;
                            bidFeed.append(bidItem);
                        });
                    },
                    error: function (xhr, status, error) {
                        console.error("Error fetching live bids:", error);
                    }
                });
            }

            document.getElementById("start-auction").addEventListener("click", function () {
                const auctionID = "<?php echo $auctionID; ?>";

                $.ajax({
                    url: 'start_auction.php',
                    method: 'POST',
                    data: { auction_id: auctionID },
                    success: function (response) {
                        const result = JSON.parse(response);

                        if (result.status == "success") {
                            alert(result.message); // Show success message
                            fetchAuctionTimer();
                        } else if (result.status == "failure") {
                            alert(result.message); // Show error message
                        }
                    },
                    error: function (xhr, status, error) {
                        alert("An error occurred while starting the auction. Please try again.");
                    }
                });
            });


            document.getElementById("end-auction").addEventListener("click", function () {
                stopTimer();
                endAuction();
            });

            function updateLiveBid(auctionID) {
                setInterval(() => {
                    $.ajax({
                        url: '../auction_room/update_bid_panel.php',
                        method: 'GET',
                        data: { auction_id: auctionID },
                        success: function (response) {
                            const result = JSON.parse(response);
                            if (result.success) {
                                document.querySelector(".live-bid-panel").innerHTML = `₹ ${Number(result.bid_amount).toLocaleString()}`;
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error("Error fetching bid data:", error);
                        }
                    });
                }, 1000); // Interval of 1 second
            }

            // Call the function with the dynamic auction ID
            const auctionID = "<?= $auctionID; ?>"; // Replace with dynamic auction ID
            updateLiveBid(auctionID);


            let auctionStatus = false;
            fetchActiveBuyers();
            fetchLiveBids();
            setInterval(fetchActiveBuyers, 2000);
            setInterval(fetchLiveBids, 2000);
        });


    </script>
</body>

</html>