<?php
require_once("../bridge.php");

if (isset($_POST['auction_id'])) {
    $auctionID = $_POST['auction_id'];
    $itemID = $_POST['item_id'];

    $checkQuery = "UPDATE auction_permission SET start_auction = 0 WHERE auction_id = $auctionID";
    $setWinner = "UPDATE bid SET has_won = 1 WHERE bid_id = ( SELECT bid_id FROM bid ORDER BY bid_amount DESC LIMIT 1 )";
    $qry1 = "UPDATE auction SET status = 'Closed' WHERE auction_id = $auctionID";
    $result3 = mysqli_query($connect, $setWinner);
    $result = mysqli_query($connect, $checkQuery);
    $result2 = mysqli_query($connect, $qry1);

    if ($result && $result2 && $result3) {
        echo json_encode(["status" => "success", "message" => "Auction closed successfully"]);
    } else {
        echo json_encode(["status" => "failure", "message" => "Failed to update auction"]);
    }
} else {
    echo json_encode(["status" => "failure", "message" => "Auction ID not provided"]);
}
?>