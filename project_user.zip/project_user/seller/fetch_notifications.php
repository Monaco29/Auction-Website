<?php
    session_start();
    require_once("../bridge.php");

    $user_id = $_SESSION["user_id"];
    $seller_id = $_SESSION["seller_id"];
    $result = mysqli_query($connect, "SELECT a.* FROM notification a INNER JOIN seller b ON a.user_id = b.user_id WHERE b.seller_id = $seller_id");

    $notifications = array();
    if(mysqli_num_rows($result) > 0)
    {
        while($data = mysqli_fetch_assoc($result))
        {
            $notifications[] = $data;
        }
    }
    echo json_encode($notifications);
    mysqli_close($connect);
?>