<?php
session_start();
require_once("../bridge.php");
if (!isset($_SESSION["user_id"])) {
    header("Location: /project_user/user_login.php");
    exit();
}
$user_id = $_SESSION["user_id"];
$user_name = $_SESSION["username"];
$seller_id = $_SESSION["seller_id"];

$result = mysqli_query($connect, "SELECT * FROM user u JOIN seller s ON s.user_id = u.user_id WHERE s.seller_id = $seller_id");
$data = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Playwrite+IN:wght@100..400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&family=Playwrite+IN:wght@100..400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&family=Playwrite+IN:wght@100..400&family=Playwrite+VN:wght@100..400&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .sidebar {
            height: 100vh;
            background-color: #343a40;
            color: white;
            padding-top: 20px;
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            transition: all 0.3s;
        }

        .profile-pic {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin: 0 auto;
            border: 3px dashed rgb(100, 100, 100);
            padding: 5px;
        }

        .profile-pic img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .profile-pic-2 {
            width: 250px;
            height: 250px;
            border-radius: 50%;
            margin: 0 50px;
            border: 5px solid rgb(227, 12, 255);
            padding: 10px;
            /* Adjusted padding */
        }

        .profile-pic-2 img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .username {
            text-align: center;
            margin: 10px 0;
            font-family: cursive;
        }

        .divider {
            border-bottom: 2px solid #495057;
            margin: 10px 20px;
        }

        .sidebar a {
            color: white;
            display: block;
            padding: 10px;
            text-decoration: none;
            position: relative;
            transition: all 0.3s;
        }

        .sidebar a:hover {
            background-color: #495057;
            transform: translateX(10px);
        }

        .sidebar .icon {
            margin-right: 10px;
        }

        .content {
            margin-left: 200px;
            padding: 20px;
        }

        .card {
            margin-bottom: 20px;
        }

        .welcome-message {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 20px;
            font-family: cursive;
        }

        .user-card {
            display: flex;
            align-items: center;
            justify-content: space-evenly;
            flex-direction: row;
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .profile-pic-container {
            flex: 0 0 100px;
        }

        .vertical-line {
            border-left: 2px solid rgb(138, 138, 138);
            height: 240px;
            margin: 0 90px;
            flex: 0 0 2px;
        }

        .user-info {
            flex: 1;
            padding-left: 20px;
            font-family: 'Verdana', sans-serif;
        }

        .user-card h2 {
            font-size: 28px;
            font-weight: bold;
            font-family: "Playwrite IN", serif;
        }

        #header-username {
            margin-bottom: 10px;
        }

        .user-card p {
            font-size: 16px;
            margin: 5px 0;
            font-family: 'Courier New', monospace;
        }

        /* ------------------------ Scrollbar editing --------------------- */
        .stats-box::-webkit-scrollbar {
            width: 8px;
        }

        .stats-box::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .stats-box::-webkit-scrollbar-thumb:hover {
            background-color: rgba(0, 0, 0, 0.2);
        }

        /* ------------------------ Statistical section --------------------- */
        /* first row */
        .stats-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .stats-box {
            width: 48%;
            height: 300px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            word-wrap: break-word;
        }

        img {
            border-radius: 5px;
        }

        /* second row */
        .stats-box-full {
            width: 100%;
            height: 400px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            word-wrap: break-word;
        }

        .stats-box-full::-webkit-scrollbar {
            width: 8px;
        }

        .stats-box-full::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .stats-box-full::-webkit-scrollbar-thumb:hover {
            background-color: rgba(0, 0, 0, 0.2);
        }

        /* third and fourth row */
        .third-fourth-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .notification-panel {
            width: 48%;
            height: 800px;
            /* Adjusted height to align with the second box in the 4th row */
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: white;
            padding: 20px;
            /* Added padding */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .notification-box {
            border: 1px solid #ddd;
            padding: 10px 15px;
            display: flex;
            flex-direction: column;
            position: relative;
            margin: 10px;
            border-radius: 10px;
        }

        .notification-box:last-child {
            border-bottom: none;
        }

        .notification-title {
            font-weight: bold;
            font-family: 'Arial', sans-serif;
            font-size: 18px;
            margin: 0;
        }

        .notification-message {
            margin: 10px 0;
            font-size: 16px;
        }

        .notification-time {
            font-size: 12px;
            color: grey;
            position: absolute;
            bottom: 5px;
            right: 10px;
        }

        .graphs-container {
            width: 48%;
        }

        .graph-card {
            width: 100%;
            height: 390px;
            /* Adjusted height for individual graph cards */
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: white;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }


        .notification-panel::-webkit-scrollbar {
            width: 8px;
        }

        .notification-panel::-webkit-scrollbar-thumb {
            background-color: rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .notification-panel::-webkit-scrollbar-thumb:hover {
            background-color: rgba(0, 0, 0, 0.2);
        }

        .tickmark {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 18px;
            color: gray;
            /* Default color for unread notifications */
        }

        .read .tickmark {
            color: blue;
            /* Color for read notifications */
        }

        .bottom-sentinel {
            height: 1px;
        }

        .mini-pic {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 5px;
            border: 1px solid black;
        }

        strong {
            font-weight: 100;
            font-family: "Pacifico", serif;
        }
    </style>
</head>

<body>
    <div class="d-flex">
        <div class="sidebar">
            <div class="text-center">
                <div class="profile-pic">
                    <img src="/final_sem_project/uploaded_images/<?= $data["profile_pic"]; ?>" alt="No img">
                </div>
                <div class="username"><?= $data["username"]; ?></div>
                <div class="divider"></div>
            </div>
            <a href="register_room.php"><i class="fas fa-home icon"></i>New Auction Room</a>
            <a href="list_item.php"><i class="fas fa-box-open icon"></i>Upload items</a>
            <a href="request_auction.php"><i class="fas fa-box-open icon"></i>Auction requests</a>
            <a href="upcoming_auctions.php"><i class="fas fa-box-open icon"></i>Upcomings</a>
            <a href="../logout.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a>
        </div>
        <div class="content container-fluid">
            <div class="welcome-message">
                Welcome, <?= $data["username"]; ?>! We're so happy to have you here. 😊
            </div>
            <div class="card user-card">
                <div class="profile-pic-container">
                    <div class="profile-pic-2">
                        <img src="/final_sem_project/uploaded_images/<?= $data["profile_pic"]; ?>" alt="No img">
                    </div>
                </div>
                <div class="vertical-line"></div>
                <div class="user-info">
                    <h2 id="header-username"><?= $data["username"]; ?></h2>
                    <p><strong>Email:</strong> <?= $data["email"]; ?></p>
                    <p><strong>Address:</strong> <?= $data["address"]; ?></p>
                    <p><strong>Contact Number:</strong> <?= $data["contect_number"]; ?></p>
                    <p><strong>Role:</strong> <?= $data["role"]; ?></p>
                </div>
            </div>
            <!-- Additional sections for statistics and other information can be added here -->
            <!-- First row -->
            <div class="stats-row">
                <div class="stats-box">
                    <h3>Uploaded Items</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Item ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Start Price</th>
                                <th>End Price</th>
                                <th>Picture</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = mysqli_query($connect, "SELECT * FROM item WHERE seller_id = $seller_id");
                            if (mysqli_num_rows($result) > 0) {
                                while ($data = mysqli_fetch_assoc($result)) {
                                    echo "<tr>
                                                <td>" . $data["item_id"] . "</td>
                                                <td>" . $data["name"] . "</td>
                                                <td>" . $data["description"] . "</td>
                                                <td>" . $data["start_price"] . "</td>
                                                <td>" . $data["end_price"] . "</td>
                                                <td><img src='../../final_sem_project/uploaded_images/" . $data["picture"] . "' alt='⚠️' class='mini-pic'></td>
                                            </tr>";
                                }
                            } else {
                                echo "<tr>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                        </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="stats-box">
                    <h3>Reviews</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>User/Buyer ID</th>
                                <th>Item</th>
                                <th>Rating</th>
                                <th>Comment</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = mysqli_query($connect, "SELECT a.*, b.picture FROM reviews a INNER JOIN item b ON a.item_id = b.item_id WHERE b.seller_id = $seller_id");
                            if (mysqli_num_rows($result) > 0) {
                                while ($data = mysqli_fetch_assoc($result)) {
                                    echo "<tr>
                                                <td>" . $data["buyer_id"] . "</td>
                                                <td><img src='../../final_sem_project/uploaded_images/" . $data["picture"] . "' alt='⚠️' class='mini-pic'></td>
                                                <td>" . $data["rating"] . "</td>
                                                <td>" . $data["comment"] . "</td>
                                                <td>" . $data["created_at"] . "</td>
                                            </tr>";
                                }
                            } else {
                                echo "<tr>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                        </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Second row -->
            <div class="stats-row">
                <div class="stats-box-full">
                    <h3>Brief overview</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Category Name</th>
                                <th>Item Name</th>
                                <th>Seller ID</th>
                                <th>Start Price</th>
                                <th>End Price</th>
                                <th>Transaction ID</th>
                                <th>Bid ID</th>
                                <th>Transaction Date</th>
                                <th>Amount</th>
                                <th>Buyer ID</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT a.name AS category_name, b.name AS item_name,b.seller_id,b.start_price,b.end_price,c.transection_id,c.bid_id,c.transection_date,c.amount,c.buyer_id 
                                 FROM category a INNER JOIN item b ON a.category_id = b.category_id
                                 INNER JOIN transections c ON b.seller_id = c.seller_id WHERE b.seller_id = $seller_id";

                            $result = mysqli_query($connect, $query);

                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<tr>";
                                    echo "<td>" . $row['category_name'] . "</td>";
                                    echo "<td>" . $row['item_name'] . "</td>";
                                    echo "<td>" . $row['seller_id'] . "</td>";
                                    echo "<td>" . $row['start_price'] . "</td>";
                                    echo "<td>" . $row['end_price'] . "</td>";
                                    echo "<td>" . $row['transection_id'] . "</td>";
                                    echo "<td>" . $row['bid_id'] . "</td>";
                                    echo "<td>" . $row['transection_date'] . "</td>";
                                    echo "<td>" . $row['amount'] . "</td>";
                                    echo "<td>" . $row['buyer_id'] . "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                            <td>❗</td>
                                        </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Third and fourth row -->
            <!-- Combined Notification Panel and Graphs -->
            <div class="third-fourth-row">
                <div class="notification-panel" id="notification-panel">
                    <h3>Notifications</h3>
                    <div class="notification-container">
                        <!-- Notifications will be dynamically inserted here by JavaScript -->
                    </div>
                    <div class="bottom-sentinel"></div> <!-- Sentinel element at the bottom -->
                </div>

                <div class="graphs-container">
                    <div class="graph-card">
                        <h4>Category distribution</h4>
                        <canvas id="categoryChart"></canvas>
                    </div>
                    <div class="graph-card">
                        <h4>Trasections</h4>
                        <!-- Placeholder for the graph (e.g., using a canvas element for Chart.js) -->
                        <canvas id="salesTimeChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    // Fetch category data
    $category_result = mysqli_query($connect, "SELECT c.name AS category_name, COUNT(i.item_id) AS item_count
                                                    FROM category c
                                                    LEFT JOIN item i ON c.category_id = i.category_id
                                                    GROUP BY c.name");
    $categories = [];
    $counts = [];
    while ($category = mysqli_fetch_assoc($category_result)) {
        $categories[] = $category['category_name'];
        $counts[] = $category['item_count'];
    }
    ?>

    <?php
    // Fetch sales data and aggregate by month
    $sales_result = mysqli_query($connect, "SELECT DATE_FORMAT(transection_date, '%Y-%m') AS month, SUM(amount) AS total_sales
                                        FROM transections
                                        GROUP BY DATE_FORMAT(transection_date, '%Y-%m')
                                        ORDER BY transection_date");
    $sales_months = [];
    $sales_totals = [];
    while ($sales = mysqli_fetch_assoc($sales_result)) {
        $sales_months[] = $sales['month'];
        $sales_totals[] = $sales['total_sales'];
    }
    ?>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels"></script>

    <script>
        // Fetch data from PHP
        const categoryLabels = <?php echo json_encode($categories); ?>;
        const categoryCounts = <?php echo json_encode($counts); ?>;

        // Calculate total number of items
        const totalItems = categoryCounts.reduce((sum, count) => sum + count, 0);

        // Create 3D Pie Chart
        const ctx = document.getElementById('categoryChart').getContext('2d');
        const categoryChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: categoryLabels,
                datasets: [{
                    data: categoryCounts,
                    backgroundColor: [
                        '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'
                    ],
                    borderColor: '#FFFFFF',
                    borderWidth: 2
                }]
            },
            options: {
                plugins: {
                    legend: {
                        display: true,
                        position: 'right',
                        labels: {
                            boxWidth: 20,
                            padding: 20,
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function (tooltipItem) {
                                const value = tooltipItem.raw;
                                const percentage = ((value / totalItems) * 100).toFixed(2) + '%';
                                return tooltipItem.label + ': ' + value + ' (' + percentage + ')';
                            }
                        }
                    },
                    datalabels: {
                        color: '#FFF',
                        formatter: (value, ctx) => {
                            const percentage = ((value / totalItems) * 100).toFixed(2) + '%';
                            return percentage;
                        }
                    }
                }
            },
            plugins: [ChartDataLabels]
        });
    </script>

    <script>
        // Fetch data from PHP
        const salesMonths = <?php echo json_encode($sales_months); ?>;
        const salesTotals = <?php echo json_encode($sales_totals); ?>;

        // Define colors for the bars
        const barColors = [
            '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40',
            '#FF6347', '#4682B4', '#9ACD32', '#E9967A', '#8A2BE2', '#DEB887'
        ];

        // Create Bar Chart
        const ctxSales = document.getElementById('salesTimeChart').getContext('2d');
        const salesTimeChart = new Chart(ctxSales, {
            type: 'bar',
            data: {
                labels: salesMonths,
                datasets: [{
                    label: 'Total Sales',
                    data: salesTotals,
                    backgroundColor: barColors,
                    borderColor: barColors.map(color => color.replace(/[^,]+(?=\))/, '1')), // Matching border color
                    borderWidth: 1
                }]
            },
            options: {
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        callbacks: {
                            label: function (tooltipItem) {
                                return 'Total Sales: $' + tooltipItem.raw.toFixed(2);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Month'
                        }
                    },
                    y: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Total Sales ($)'
                        }
                    }
                }
            }
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            console.log("DOM fully loaded and parsed");

            // Fetch and render notifications when the page loads
            fetchNotifications();

            // Create an IntersectionObserver to detect the bottom of the page
            const observer = new IntersectionObserver(handleIntersect, {
                root: null,
                rootMargin: '0px',
                threshold: 1.0
            });

            // Observe the bottom sentinel
            const sentinel = document.querySelector('.bottom-sentinel');
            if (sentinel) {
                observer.observe(sentinel);
            }
        });

        async function fetchNotifications() {
            try {
                const response = await fetch('fetch_notifications.php');
                const notifications = await response.json();
                renderNotifications(notifications);
            } catch (error) {
                console.error('Error fetching notifications:', error);
            }
        }

        function renderNotifications(notifications) {
            const notificationContainer = document.querySelector('.notification-container');
            notificationContainer.innerHTML = ''; // Clear previous notifications

            notifications.forEach(notification => {
                const notificationBox = document.createElement('div');
                notificationBox.className = 'notification-box';
                notificationBox.dataset.id = notification.notification_id;
                notificationBox.dataset.read = notification.is_read ? 'true' : 'false';
                if (notification.is_read === '1') {
                    notificationBox.classList.add('read');
                }
                notificationBox.innerHTML = `
            <p class="notification-title">${notification.message}</p>
            <span class="notification-time">${new Date(notification.sent_time).toLocaleTimeString()}</span>
            <i class="fas fa-check tickmark"></i> <!-- Tickmark icon -->
        `;

                notificationContainer.appendChild(notificationBox);
            });

            console.log("Notifications rendered");
        }

        function handleIntersect(entries, observer) {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Delay of 3 seconds before marking notifications as read
                    setTimeout(() => {
                        markAllNotificationsAsRead();
                    }, 3000); // 3-second delay
                }
            });
        }

        function markAllNotificationsAsRead() {
            const notifications = document.querySelectorAll('.notification-box[data-read="false"]');
            notifications.forEach(notification => {
                notification.dataset.read = 'true';
                notification.classList.add('read');
                notification.querySelector('.tickmark').classList.add('read');
            });

            // Send AJAX request to update notifications in the database
            updateNotificationsInDatabase();
        }

        async function updateNotificationsInDatabase() {
            try {
                const response = await fetch('update_notifications.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    }
                });
                const result = await response.json();
                if (result.status === 'success') {
                    console.log("All unread notifications marked as read in the database.");
                } else {
                    console.error("Failed to update notifications in the database.");
                }
            } catch (error) {
                console.error('Error updating notifications in the database:', error);
            }
        }
    </script>

</body>

</html>