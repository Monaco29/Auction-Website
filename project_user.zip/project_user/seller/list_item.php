<?php
// Include database connection
$host = 'Localhost:3307'; // Update with your database host
$dbname = 'project_auction'; // Update with your database name
$username = 'root'; // Update with your database username
$password = '';

session_start();

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $start_price = $_POST['start_price'];
    $category_id = $_POST['category_id'];
    $seller_id = $_SESSION["seller_id"];

    // Handle file upload for item image
    $image = $_FILES['item_image'];
    $image_name = $image['name'];
    $image_tmp_name = $image['tmp_name'];
    $image_folder = '../../final_sem_project/uploaded_images/' . $image_name;

    if (move_uploaded_file($image_tmp_name, $image_folder)) {
        try {
            // Insert item into database
            $query = "INSERT INTO item (name, description, start_price, category_id, seller_id, picture) 
                      VALUES (:name, :description, :start_price, :category_id, :seller_id, :item_image)";
            $stmt = $conn->prepare($query);
            $stmt->execute([
                ':name' => $name,
                ':description' => $description,
                ':start_price' => $start_price,
                ':category_id' => $category_id,
                ':seller_id' => $seller_id,
                ':item_image' => $image_name
            ]);

            echo "<script>alert('Item listed successfully!');</script>";
        } catch (PDOException $e) {
            echo "<script>alert('Error listing item: " . $e->getMessage() . "');</script>";
        }
    } else {
        echo "<script>alert('Failed to upload image.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List New Item</title>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgb(130, 106, 251);
        }

        .container {
            position: relative;
            max-width: 700px;
            width: 100%;
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .container header {
            font-size: 1.5rem;
            color: #333;
            font-weight: 500;
            text-align: center;
        }

        .container .form {
            margin-top: 30px;
        }

        .form .input-box {
            width: 100%;
            margin-top: 20px;
        }

        .input-box label {
            color: #333;
        }

        .form :where(.input-box input, .select-box) {
            position: relative;
            height: 40px;
            width: 100%;
            outline: none;
            font-size: 1rem;
            color: #707070;
            margin-top: 8px;
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 0 15px;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .input-box input:focus {
            box-shadow: 0 1px 0 rgba(0, 0, 0, 0.1);
        }

        .input-box textarea {
            min-height: 70px;
            min-width: 100%;
            resize: vertical;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ddd;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .form button {
            height: 50px;
            width: 100%;
            color: #fff;
            font-size: 1rem;
            font-weight: 400;
            margin-top: 30px;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
            background: rgb(130, 106, 251);
        }

        .form button:hover {
            background: rgb(88, 56, 250);
        }
    </style>
</head>

<body>
    <section class="container">
        <header>List a New Item for Auction</header>
        <form action="" method="POST" enctype="multipart/form-data" class="form">
            <div class="input-box">
                <label for="name">Item Name:</label>
                <input type="text" id="name" name="name" placeholder="Enter item name" required>
            </div>
            <div class="input-box">
                <label for="description">Description:</label>
                <textarea id="description" name="description" placeholder="Describe your item" required></textarea>
            </div>
            <div class="input-box">
                <label for="start_price">Starting Price (₹):</label>
                <input type="number" step="0.01" , min="0" id="start_price" name="start_price"
                    placeholder="Enter item price" step="0.01" required>
            </div>
            <div class="input-box">
                <label for="category_id">Category:</label>
                <select id="category_id" name="category_id" required>
                    <?php
                    // Fetch categories from the database
                    $category_query = "SELECT * FROM category";
                    $categories = $conn->query($category_query);

                    while ($row = $categories->fetch(PDO::FETCH_ASSOC)) {
                        echo "<option value='" . $row['category_id'] . "'>" . $row['name'] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="input-box">
                <label for="item_image">Upload Item Image:</label>
                <input type="file" id="item_image" name="item_image" accept="image/*" required>
            </div>
            <button type="submit">List Item</button>
        </form>
    </section>
</body>

</html>