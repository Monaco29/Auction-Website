<?php
session_start();
require_once("../bridge.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $connect = mysqli_connect("localhost:3307", "root", "", "project_auction");

    if (!$connect) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    // Fetch inputs
    $a_item = mysqli_real_escape_string($connect, $_POST["target_item_id"]);
    $a_auction_start = mysqli_real_escape_string($connect, $_POST["start_time"]);
    $a_auction_end = mysqli_real_escape_string($connect, $_POST["end_time"]);
    $a_category = mysqli_real_escape_string($connect, $_POST["target_category_id"]);
    $a_title = mysqli_real_escape_string($connect, $_POST["auction_title"]);
    $a_description = mysqli_real_escape_string($connect, $_POST["auction_description"]);
    $seller_Id = mysqli_real_escape_string($connect, $_SESSION["seller_id"]);

    // Validate inputs
    if (empty($a_item) || empty($a_auction_start) || empty($a_auction_end) || empty($a_category) || empty($a_title) || empty($a_description) || empty($seller_Id)) {
        echo "Error: Some fields are missing!";
        exit();
    }

    // Determine auction status based on date-time
    $current_datetime = date("Y-m-d H:i:s");
    if ($a_auction_start > $current_datetime) {
        $status = "Upcoming";
    } elseif ($a_auction_start <= $current_datetime && $a_auction_end > $current_datetime) {
        $status = "OnGoing";
    } else {
        $status = "Closed";
    }

    // Insert data into auction table
    $query = "INSERT INTO auction (item_id, auction_start, auction_end, status, seller_id, category_id, title, description) 
              VALUES ($a_item, '$a_auction_start', '$a_auction_end', '$status', $seller_Id, $a_category, '$a_title', '$a_description')";

    if (mysqli_query($connect, $query)) {
        echo "Success: Your auction room is created successfully!";
    } else {
        echo "Error: " . mysqli_error($connect);
    }

    mysqli_close($connect);
}
?>