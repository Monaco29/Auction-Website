<?php
session_start();
require_once("../bridge.php");
if (!isset($_SESSION["seller_id"])) {
    header("Location: /project_user/user_login.php");
}
$seller_id = $_SESSION["seller_id"];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background: rgb(130, 106, 251);
        }

        .container {
            position: relative;
            max-width: 700px;
            width: 100%;
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        .container header {
            font-size: 1.5rem;
            color: #333;
            font-weight: 500;
            text-align: center;
        }

        .container .form {
            margin-top: 30px;
        }

        .form .input-box {
            width: 100%;
            margin-top: 20px;
        }

        .input-box label {
            color: #333;
        }

        .form :where(.input-box input, .select-box) {
            position: relative;
            height: 36px;
            /* Reduced the height of input type 'text' */
            width: 100%;
            outline: none;
            font-size: 1rem;
            color: #707070;
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 0 15px;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
            /* Added shadow effect inside the input box */
        }

        .input-box input:focus {
            box-shadow: 0 1px 0 rgba(0, 0, 0, 0.1);
        }

        .input-box textarea {
            min-height: 65px;
            min-width: 100%;
            resize: vertical;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #ddd;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .form .column {
            display: flex;
            column-gap: 15px;
        }

        .form .gender-box {
            margin-top: 20px;
        }

        .gender-box h3 {
            color: #333;
            font-size: 1rem;
            font-weight: 400;
            margin-bottom: 8px;
        }

        .form :where(.gender-option, .gender) {
            display: flex;
            align-items: center;
            column-gap: 50px;
            flex-wrap: wrap;
        }

        .form .gender {
            column-gap: 5px;
        }

        .gender input {
            accent-color: rgb(130, 106, 251);
        }

        .form :where(.gender input, .gender label) {
            cursor: pointer;
        }

        .gender label {
            color: #707070;
        }

        .address :where(input, .select-box) {
            margin-top: 15px;
        }

        .select-box select {
            height: 100%;
            width: 100%;
            outline: none;
            border: none;
            color: #707070;
            font-size: 1rem;
        }

        .form input[type=submit] {
            height: 40px;
            width: 100%;
            color: #fff;
            font-size: 1rem;
            font-weight: 400;
            margin-top: 30px;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
            background: rgb(130, 106, 251);
            border-radius: 10px;
        }

        .form button:hover {
            background: rgb(88, 56, 250);
        }

        /* Popup and overlay styles */
        #registrationSection.blur {
            filter: blur(5px);
            /* Apply blur effect */
        }

        .success-container {
            display: none;
            /* Initially hidden */
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.5);
            width: 300px;
            /* Small container size */
            padding: 20px;
            border-radius: 10px;
            background-color: #f8f9fa;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            z-index: 9999;
            text-align: center;
            transition: transform 0.3s ease-out;
        }

        .success-container.show {
            display: block;
            transform: translate(-50%, -50%) scale(1);
        }

        .success-icon {
            font-size: 50px;
            color: #28a745;
        }

        .success-message {
            font-size: 14px;
            color: #28a745;
            margin-top: 10px;
        }

        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 20px;
            cursor: pointer;
            color: #888;
        }

        .overlay {
            display: none;
            /* Initially hidden */
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            /* Darker background effect */
            z-index: 9998;
        }

        .overlay.show {
            display: block;
        }
    </style>
    <title>Register Auction</title>
</head>

<body>
    <section class="container" id="registrationSection">
        <header>Make your auction room</header>
        <form action="load_to_auction.php" class="form" id="registrationForm" method="POST">
            <div class="input-box">
                <label for="item_id">Item ID</label>
                <select id="item_id" name="target_item_id" required>
                    <?php
                    $result = mysqli_query($connect, "SELECT item_id, name FROM item WHERE seller_id = $seller_id and item_id NOT IN (SELECT item_id FROM auction WHERE seller_id = $seller_id)");
                    if (mysqli_num_rows($result) > 0) {
                        while ($data = mysqli_fetch_assoc($result)) {
                            echo "<option value='" . $data["item_id"] . "'>" . $data["item_id"] . " - " . $data["name"] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No item found !!</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="input-box">
                <label for="auction_start">Auction Start</label>
                <input type="datetime-local" id="auction_start" name="start_time" required />
            </div>
            <div class="input-box">
                <label for="auction_end">Auction End</label>
                <input type="datetime-local" id="auction_end" name="end_time" required />
            </div>
            <div class="input-box">
                <label for="category">Category</label>
                <select id="category" name="target_category_id" required>
                    <?php
                    $result = mysqli_query($connect, "SELECT category_id, name FROM category");
                    if (mysqli_num_rows($result) > 0) {
                        while ($data = mysqli_fetch_assoc($result)) {
                            echo "<option value='" . $data["category_id"] . "'>" . $data["category_id"] . " - " . $data["name"] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No category found !!</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="input-box">
                <label for="auction_title">Auction Title</label>
                <input type="text" id="auction_title" placeholder="Enter auction title" name="auction_title" required />
            </div>
            <div class="input-box">
                <label for="description">Description</label>
                <textarea id="description" placeholder="Enter description" name="auction_description" required></textarea>
            </div>
            <input type="submit"></input>
        </form>
    </section>

    <div class="overlay" id="overlay"></div>
    <div class="success-container" id="successContainer">
        <div class="close-btn" onclick="closePopup()">&times;</div>
        <div class="success-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="success-message">
            Success! Your auction room is created successfully
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>

    <script>
        document.getElementById("registrationForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission

            var formData = new FormData(event.target);

            var xhr = new XMLHttpRequest();
            xhr.open("POST", "load_to_auction.php", true);

            xhr.onload = function() {
                if (xhr.status === 200) {
                    var response = xhr.responseText;
                    // Assuming the server responds with a success message
                    if (response.includes("Success")) {
                        showPopup(response);
                    } else {
                        alert("Error: " + response);
                    }
                } else {
                    alert("Error: Server response " + xhr.status);
                }
            };

            xhr.send(formData);
        });

        function showPopup(response) {
            document.getElementById("overlay").classList.add("show");
            document.getElementById("successContainer").classList.add("show");
            document.getElementById("registrationSection").classList.add("blur"); // Add blur effect

            // Display server response in the success message
            document.querySelector(".success-message").textContent = response;
        }

        function closePopup() {
            document.getElementById("overlay").classList.remove("show");
            document.getElementById("successContainer").classList.remove("show");
            document.getElementById("registrationSection").classList.remove("blur"); // Remove blur effect
            window.location.href = "home.php";
        }
    </script>
</body>
</html>