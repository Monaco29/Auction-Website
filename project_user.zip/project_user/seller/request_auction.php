<?php
require_once("../bridge.php");

// Fetch auction registrations with active auctions
$query = "
    SELECT 
        ar.auction_registration_id, 
        ar.auction_id, 
        ar.buyer_id, 
        ar.registered_at, 
        ar.status AS registration_status, 
        ar.item_id, 
        a.title, 
        a.description, 
        a.status AS auction_status 
    FROM 
        auction_registration AS ar
    INNER JOIN 
        auction AS a 
    ON 
        ar.auction_id = a.auction_id
    WHERE 
        a.status IN ('OnGoing', 'Upcoming')
";

$result = mysqli_query($connect, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Auction Registration Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .table-card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
        }

        .hover-row:hover {
            background-color: #e9ecef;
            transition: background-color 0.3s ease;
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Auction request manager</a>
    </nav>

    <div class="container mt-5">
        <div class="card table-card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Auction Request Management</h4>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-hover table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>Auction Reg ID</th>
                            <th>Auction ID</th>
                            <th>Buyer ID</th>
                            <th>Registered At</th>
                            <th>Status</th>
                            <th>Item ID</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (!$result) {
                            echo "<tr><td colspan='7'>Error fetching data: " . mysqli_error($connect) . "</td></tr>";
                        } else {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr class='hover-row' id='row_" . $row['auction_registration_id'] . "'>";
                                echo "<td>" . $row['auction_registration_id'] . "</td>";
                                echo "<td>" . $row['auction_id'] . "</td>";
                                echo "<td>" . $row['buyer_id'] . "</td>";
                                echo "<td>" . $row['registered_at'] . "</td>";
                                echo "<td id='status_" . $row['auction_registration_id'] . "'>" . $row['registration_status'] . "</td>";
                                echo "<td>" . $row['item_id'] . "</td>";
                                echo "<td>
                                        <button class='btn btn-warning btn-sm' onclick='updateStatus(" . $row['auction_registration_id'] . ", \"Pending\")'>Pending</button>
                                        <button class='btn btn-success btn-sm' onclick='updateStatus(" . $row['auction_registration_id'] . ", \"Approved\")'>Approve</button>
                                        <button class='btn btn-danger btn-sm' onclick='updateStatus(" . $row['auction_registration_id'] . ", \"Rejected\")'>Reject</button>
                                      </td>";
                                echo "</tr>";
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer text-center">
                <small>Powered by Team Auction</small>
            </div>
        </div>
    </div>

    <script>
        function updateStatus(registrationId, newStatus) {
            $.ajax({
                url: "update_status.php",
                type: "POST",
                data: {
                    auction_registration_id: registrationId,
                    status: newStatus
                },
                success: function (response) {
                    if (response === "success") {
                        alert("Status updated successfully!");
                        $("#status_" + registrationId).text(newStatus);
                    } else {
                        alert("Error updating status!");
                    }
                }
            });
        }
    </script>

</body>

</html>

<?php mysqli_close($connect); ?>