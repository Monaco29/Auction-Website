<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sellers</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }

        .card {
            margin-bottom: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .logout {
            text-align: right;
            margin-bottom: 20px;
        }

        .accordion {
            width: 80px;
            /* Reduced the width */
            margin: 10px auto;
            /* Added space between menus */
            border-radius: 5px;
            display: flex;
            flex-direction: column;
        }

        .accordion-item {
            cursor: pointer;
            padding: 8px;
            /* Reduced the padding */
            margin-bottom: 5px;
            /* Added space between items */
            border-radius: 5px;
            /* Added border radius for individual items */
            transition: background-color 0.3s ease, box-shadow 0.3s ease, background-color 0.3s ease-in-out;
            text-align: center;
            /* Centered the text */
            font-size: 12px;
            /* Reduced the font size */
            font-weight: bold;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2), -2px -2px 5px rgba(255, 255, 255, 0.5);
            /* 3D-like shadow effect */
            position: relative;
            /* Added for ripple effect */
            overflow: hidden;
            /* Added for ripple effect */
            background: linear-gradient(135deg,rgb(114, 154, 255));
            /* Light purple and light red gradient background */
        }

        .accordion-item:hover {
            background: linear-gradient(135deg,rgb(156, 98, 255));
            /* Slightly lighter gradient for hover */
        }

        .accordion-item.active {
            background: linear-gradient(135deg,rgb(234, 115, 254),rgb(255, 95, 95));
            /* Slightly darker gradient for active state */
            color: white;
            animation: click-effect 1s;
        }

        @keyframes ripple {
            100% {
                transform: translate(-50%, -50%) scale(100);
                opacity: 0;
            }
        }

        @keyframes click-effect {
            0% {
                background: linear-gradient(135deg, #E1BEE7, #FFCDD2);
                box-shadow: 0 0 10px #E1BEE7;
            }

            50% {
                background: linear-gradient(135deg, #F3E5F5, #FFEBEE);
                box-shadow: 0 0 20px #F3E5F5;
            }

            100% {
                background: linear-gradient(135deg, #E1BEE7, #FFCDD2);
                box-shadow: 0 0 10px #E1BEE7;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="logout">
            <a href="../admin_logout.php" class="btn btn-danger">Logout</a>
        </div>
        <h1 class="mb-4">Manage Sellers</h1>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Seller List</h5>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Seller ID</th>
                            <th>User ID</th>
                            <th>Business Name</th>
                            <th>Business Address</th>
                            <th>Business Email</th>
                            <th>Average Rating</th>
                            <th>Total Sales</th>
                            <th>Verified</th>
                            <th>Created On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require_once("../bridge.php");
                        session_start();
                        $seller = $_SESSION["seller_id"];
                        $f_query = "SELECT a.*, b.status AS schedule, b.title, b.auction_start, d.username   
                        FROM auction_registration a 
                        INNER JOIN auction b ON a.auction_id = b.auction_id 
                        INNER JOIN buyer c ON a.buyer_id = c.buyer_id 
                        INNER JOIN user d ON c.user_id = d.user_id
                        WHERE b.status = 'Upcoming' OR b.status = 'Active'";
                        print_r(mysqli_query($connect, $f_query));
                        $result = mysqli_query($connect, "SELECT * FROM seller");
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['seller_id'] . "</td>";
                            echo "<td>" . $row['user_id'] . "</td>";
                            echo "<td>" . $row['business_name'] . "</td>";
                            echo "<td>" . $row['business_address'] . "</td>";
                            echo "<td>" . $row['business_email'] . "</td>";
                            echo "<td>" . $row['average_rating'] . "</td>";
                            echo "<td>" . $row['total_sales'] . "</td>";
                            echo "<td>";
                            echo "<div class='accordion'>";
                            echo "<div class='accordion-item ripple' data-ripple-color='#E1BEE7' data-value='Pending'><span>Pending</span></div>";
                            echo "<div class='accordion-item ripple' data-ripple-color='#E1BEE7' data-value='Approved'><span>Approved</span></div>";
                            echo "<div class='accordion-item ripple' data-ripple-color='#E1BEE7' data-value='Rejected'><span>Rejected</span></div>";
                            echo "</div>";
                            echo "</td>";
                            echo "<td>" . $row['created_on'] . "</td>";
                            echo "<td>";
                            echo "<form id='form_" . $row['seller_id'] . "' action='edit_seller_verification.php' method='POST' style='display:inline;'>";
                            echo "<input type='hidden' name='seller_id' value='" . $row['seller_id'] . "'>";
                            echo "<input type='hidden' name='user_id' value='" . $row['user_id'] . "'>";
                            echo "<input type='hidden' name='verified_status' value='" . ($row['verified'] ? "1" : "0") . "'>";
                            echo "<button type='submit' class='btn btn-warning btn-sm'>Update</button>";
                            echo "</form>";
                            echo "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.accordion-item').click(function() {
                $(this).siblings().removeClass('active');
                $(this).addClass('active');
                var status = $(this).data('value');
                $(this).closest('td').find('input[name="verified_status"]').val(status === 'Approved' ? '1' : '0');
            });

            // Ripple effect logic
            (function() {
                document.querySelectorAll('.ripple').forEach(setRippleElement);
            })();

            function setRippleElement(el) {
                el.addEventListener('click', function(e) {
                    const dot = document.createElement('SPAN');
                    const largestSide = Math.sqrt(
                        Math.pow(el.offsetWidth, 2) +
                        Math.pow(el.offsetHeight, 2)
                    );
                    const dotSize = Math.ceil((largestSide * 2) / 100);
                    const rippleColor = el.dataset.rippleColor || '#E1BEE7';

                    dot.style.position = 'absolute';
                    dot.style.left = `${e.clientX - el.getBoundingClientRect().left}px`;
                    dot.style.top = `${e.clientY - el.getBoundingClientRect().top}px`;
                    dot.style.width = `${dotSize}px`;
                    dot.style.height = `${dotSize}px`;
                    dot.style.borderRadius = '50%';
                    dot.style.background = rippleColor;
                    dot.style.transform = 'translate(-50%, -50%) scale(1)';
                    dot.style.opacity = '0.5';
                    dot.style.animation = 'ripple 1s ease-out forwards';
                    dot.style.pointerEvents = 'none';
                    el.appendChild(dot);

                    setTimeout(() => {
                        dot.remove();
                    }, 1000);
                });
            }
        });
    </script>
</body>

</html>