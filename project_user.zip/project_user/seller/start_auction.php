<?php
require_once("../bridge.php");

if (isset($_POST['auction_id'])) {
    $auctionID = $_POST['auction_id'];

    $checkQuery = "SELECT * FROM auction_permission WHERE auction_id = $auctionID";
    $result = mysqli_query($connect, $checkQuery);

    $qry_1 = "SELECT * FROM auction_registration WHERE auction_id = $auctionID and status = 'Approved'";
    $result_1 = mysqli_query($connect, $qry_1);
    while ($row = mysqli_fetch_assoc($result_1)) {
        $current_buyer_id = $row["buyer_id"];
        $sub_query = "SELECT a.user_id FROM buyer b JOIN user a ON a.user_id = b.user_id WHERE b.buyer_id = $current_buyer_id";
        $sub_result = mysqli_query($connect, $sub_query);
        $rw = mysqli_fetch_assoc($sub_result);
        $current_user_id = $rw["user_id"];
        $final_insert_qry = "INSERT INTO notification(user_id, message) VALUES($current_user_id, '🚀 Auction Kickoff! The seller has just launched the auction. Get your bids ready and join the excitement!')";
        $sub_results = mysqli_query($connect, $final_insert_qry);
    }

    $setStatus = "UPDATE auction SET status = 'OnGoing' WHERE auction_id = $auctionID";
    mysqli_query($connect, $setStatus);
    
    if (mysqli_num_rows($result) == 0) {
        $updateQuery = "INSERT INTO auction_permission(auction_id, start_auction) VALUES($auctionID, 1)";
        $stmtUpdate = mysqli_query($connect, $updateQuery);

        if ($stmtUpdate) {
            echo json_encode(["status" => "success", "message" => "Auction started successfully"]);
        } else {
            echo json_encode(["status" => "failure", "message" => "Failed to update auction"]);
        }
    } else {
        $updateQuery = "UPDATE auction_permission SET start_auction = 1 WHERE auction_id = $auctionID";
        $stmtUpdate = mysqli_query($connect, $updateQuery);

        if ($stmtUpdate) {
            echo json_encode(["status" => "success", "message" => "Auction started successfully"]);
        } else {
            echo json_encode(["status" => "failure", "message" => "Failed to update auction"]);
        }
    }
} else {
    echo json_encode(["status" => "failure", "message" => "Auction ID not provided"]);
}
?>