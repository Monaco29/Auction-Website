<?php
    session_start();
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $_SESSION["auction_id"] = $_POST["auction_id"];
        $_SESSION["item_id"] = $_POST["item_id"];
        echo "success";
    }
    else
    {
        echo "failure";
    }
?>