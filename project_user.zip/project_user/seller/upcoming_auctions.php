<?php
require_once("../bridge.php");

$query = "
SELECT 
    a.auction_id, 
    a.title, 
    a.description, 
    a.status, 
    a.item_id,
    a.auction_start
FROM 
    auction AS a
WHERE 
    a.status = 'Upcoming'
ORDER BY 
    a.auction_start ASC
";
$result = mysqli_query($connect, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Seller Auctions Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
        }

        .table-card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
        }

        .hover-row:hover {
            background-color: #e9ecef;
            transition: background-color 0.3s ease;
        }

        /* Common styles for all buttons */
        .custom-button {
            width: 80%;
            padding: 10px;
            font-size: 1rem;
            font-weight: bold;
            font-family: 'Poppins', sans-serif;
            border-radius: 8px;
            cursor: pointer;
            color: white;
            /* Text color */
            border: 2px solid #007bff;
            /* Blue border */
            background: #007bff;
            /* Blue background */
            margin-top: 10px;
            /* Add spacing around the button */
            transition: all 0.3s ease-in-out;
            /* Hover and active animations */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            /* Subtle shadow */
        }

        /* Hover effect */
        .custom-button:hover {
            background: white;
            /* Invert colors on hover */
            color: #007bff;
            /* Blue text on hover */
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            /* Enhance shadow */
        }

        /* Active button effect */
        .custom-button:active {
            background: #0056b3;
            /* Darker blue when clicked */
            color: white;
            /* White text */
            transform: scale(0.98);
            /* Shrink button slightly */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            /* Reduce shadow */
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">Seller Auction Management</a>
    </nav>

    <div class="container mt-5">
        <div class="card table-card">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Upcoming Auctions</h4>
            </div>
            <div class="card-body">
                <table class="table table-bordered table-hover table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>Auction ID</th>
                            <th>Title</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Start Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (!$result) {
                            echo "<tr><td colspan='6'>Error fetching data: " . mysqli_error($connect) . "</td></tr>";
                        } else {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr class='hover-row' id='row_" . $row['auction_id'] . "'>";
                                echo "<td>" . $row['auction_id'] . "</td>";
                                echo "<td>" . $row['title'] . "</td>";
                                echo "<td>" . $row['description'] . "</td>";
                                echo "<td id='status_" . $row['auction_id'] . "'>" . $row['status'] . "</td>";
                                echo "<td>" . $row['auction_start'] . "</td>";
                                echo "<td>
                                        <button class='custom-button join-btn' onclick='joinAuction(" . $row['item_id'] . "," . $row['auction_id'] . ")'>
                                            Join
                                        </button>
                                    </td>
                                    ";
                                echo "</tr>";
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer text-center">
                <small>Powered by Team Auction</small>
            </div>
        </div>
    </div>

    <script>
        function joinAuction(itemId, auctionId) {
            $.ajax({
                url: 'tester.php',
                method: 'POST',
                data: {
                    auction_id: auctionId,
                    item_id: itemId
                },
                success: function (response) {
                    window.location.href = 'auction_room_seller.php';
                },
                error: function (xhr, status, error) {
                    console.error("Error setting session:", error);
                }
            });
        }

    </script>

</body>

</html>