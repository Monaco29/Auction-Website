<?php
require_once("../bridge.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
    $registrationId = $_POST['auction_registration_id'];
    $newStatus = $_POST['status'];
    
    // Update query
    $query = "UPDATE auction_registration SET status = '$newStatus' WHERE auction_registration_id = $registrationId";
    $s_query = "SELECT a.user_id FROM auction_registration c JOIN buyer b on c.buyer_id = b.buyer_id JOIN user a ON a.user_id = b.user_id WHERE c.auction_registration_id = $registrationId";
    $s_result = mysqli_query($connect, $s_query);
    $row = mysqli_fetch_assoc($s_result);
    $user_id = $row["user_id"];
    $msg = "";
    if($newStatus == 'Approved')
    {
        $msg = '🎉 Green Light! Your auction request is approved. Prepare your best bid - the auction floor awaits your brilliance 🥳!';
    }
    else if($newStatus == 'Pending')
    {
        $msg = "⏳ Almost There... Your auction request is under review. Sit tight – the seller's decision is just a heartbeat away!";
    }
    else
    {
        $msg = '😔 Request Denied: Your auction request was declined. It’s a minor setback – dust off and get ready for the next big bidding adventure!';
    }
    $msg = mysqli_real_escape_string($connect, $msg);
    $insertQry = "INSERT INTO notification(user_id, message) VALUES($user_id, '$msg')";
    
    if (mysqli_query($connect, $query) && mysqli_query($connect, $insertQry)) 
    {
        echo "success";
    } else {
        echo "error" . mysqli_error($connect);
    }
}
?>