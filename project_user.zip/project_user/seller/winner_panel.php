<?php
    session_start();
    if(!isset($_SESSION["auction_id"]))
    {
        header("Location: home.php");
    }
    $auction_ID = $_SESSION["auction_id"];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winner Announcement</title>
    <style>
        /* Body Styles */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        /* Background Blur */
        body:before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            backdrop-filter: blur(10px);
            /* Background blur */
            background-color: rgba(0, 0, 0, 0.4);
            /* Adds a slight dark overlay */
            z-index: 1;
        }

        /* Canvas for Confetti */
        #my-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 2;
            /* Ensure it overlaps the blurred background */
        }

        /* Centered Card */
        .winner-card {
            position: relative;
            z-index: 3;
            /* Ensure it stays above the confetti */
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.25);
            width: 400px;
            height: 450px;
            padding: 20px;
            text-align: center;
            animation: scaleUp 0.5s ease-in-out;
            /* Add a smooth scale animation */
        }

        /* Winner Profile Image */
        .winner-img {
            width: 200px;
            height: 200px;
            border: 2px solid black;
            border-radius: 10px;
            object-fit: cover;
            margin-bottom: 15px;
        }

        /* Winner Details */
        .winner-name {
            font-size: 1.5rem;
            font-weight: bold;
            font-family: cursive;
            color: #673ab7;
            margin-bottom: 10px;
        }

        .winner-bid {
            font-size: 26px;
            font-weight: bolder;
            color: green;
            font-family: "Courier New", Courier, monospace;
        }

        /* Close Button */
        .close-btn {
            position: absolute;
            top: -10px;
            right: -10px;
            width: 40px;
            height: 40px;
            background-color: #ff5252;
            color: #fff;
            border: none;
            border-radius: 50%;
            font-size: 1.2rem;
            font-weight: bold;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(255, 82, 82, 0.6);
            /* Red box shadow */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .close-btn:hover {
            background-color: #ff1744;
            /* Darker red on hover */
        }

        .custom-button:hover {
            background: white;
            color: #007bff;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .custom-button:active {
            background: #0056b3;
            color: white;
            transform: scale(0.98);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        @keyframes scaleUp {
            from {
                transform: scale(0.8);
                opacity: 0.5;
            }

            to {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>
</head>

<body>
    <!-- Confetti Canvas -->
    <canvas id="my-canvas"></canvas>

    <!-- Winner Announcement Card -->
    <div class="winner-card">
        <button class="close-btn" onclick="closeWinnerPage()">x</button>
        <p
            style="color: green; font-size: 30px; font-weight: bolder; font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;">
            💐💐 Congratulations 💐💐</p>
        <img id="winner-img" class="winner-img" src="" alt="Winner">
        <p id="winner-name" class="winner-name">Winner Name</p>
        <p id="winner-bid" class="winner-bid">Final Bid: ₹ 0.00</p>
    </div>

    <script src="../auction_room/index.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // Initialize Confetti Effect
        var confettiSettings = { target: 'my-canvas' };
        var confetti = new ConfettiGenerator(confettiSettings);
        confetti.render();

        // Fetch Winner Details Dynamically
        function fetchWinnerDetails(auctionID) {
            $.ajax({
                url: '../auction_room/winner_announcement.php',
                method: 'GET',
                data: { auction_id: auctionID },
                success: function (response) {
                    const result = JSON.parse(response);
                    console.log(auctionID);
                    console.log(result);
                    if (result.success) {
                        document.getElementById("winner-img").src = "../../final_sem_project/uploaded_images/" + result.profile_pic;
                        document.getElementById("winner-name").textContent = result.username;
                        document.getElementById("winner-bid").textContent = `₹ ${result.bid_amount}`;
                    } else {
                        alert(result.message);
                    }
                },
                error: function (xhr, status, error) {
                    console.error("Error fetching winner details:", error);
                }
            });
        }

        // Close Winner Page
        function closeWinnerPage() {
            window.location.href = 'home.php'; // Redirect back to auction room
        }

        // Trigger Winner Details Fetch (Use dynamic auction ID)
        const auctionID = <?= $auction_ID; ?>; // Replace with dynamic auction ID
        fetchWinnerDetails(auctionID);
    </script>
</body>

</html>