<?php
require_once("bridge.php");
session_start();
$buyer_id = $_SESSION["buyer_id"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST['rating_value'])) {
    $rating_value = $_POST['rating_value'];
    $userMessage = $_POST['userMessage'];
    $itemId = $_POST['item_id'];

    $checker = "SELECT * FROM reviews WHERE item_id = $itemId AND buyer_id = $buyer_id";
    if(mysqli_num_rows(mysqli_query($connect, $checker)) > 0)
    {
         $qr = null;
         if($rating_value == '' && $userMessage != '')
         {
            $qr = "UPDATE reviews SET comment = '$userMessage' WHERE item_id = $itemId AND buyer_id = $buyer_id";            
         }
         else if($rating_value != '' && $userMessage == '')
         {
            $qr = "UPDATE reviews SET rating = $rating_value WHERE item_id = $itemId AND buyer_id = $buyer_id";            
         }
         else if($rating_value != '' && $userMessage != '')
         {
            $qr = "UPDATE reviews SET rating = $rating_value, comment = '$userMessage' WHERE item_id = $itemId AND buyer_id = $buyer_id";
         }
         if(mysqli_query($connect,$qr))
         {
           echo "Reviews updated..";
         }
    }
    else
    {

      $sql = "INSERT INTO reviews (buyer_id, rating, comment, item_id) 
      VALUES ('$buyer_id', $rating_value, '$userMessage', '$itemId')";

      if (mysqli_query($connect, $sql)) {
        echo "New Review Added Successfully";
      } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($connect);
      }
    }

    mysqli_close($connect);
  }

  if (isset($_POST['action'])) {
    $targetId = $_POST["item_id"];
    $avgRatings = 0;
    $avgUserRatings = 0;
    $totalReviews = 0;
    $totalRatings5 = 0;
    $totalRatings4 = 0;
    $totalRatings3 = 0;
    $totalRatings2 = 0;
    $totalRatings1 = 0;
    $ratingsList = array();
    $totalRatings_avg = 0;

    $sql = "SELECT a.*, d.username 
            FROM reviews a
            INNER JOIN item b ON a.item_id = b.item_id 
            INNER JOIN buyer c ON a.buyer_id = c.buyer_id 
            INNER JOIN user d ON c.user_id = d.user_id 
            WHERE b.item_id = $targetId 
            ORDER BY a.review_id DESC";
    $result = mysqli_query($connect, $sql);

    while ($row = mysqli_fetch_assoc($result)) {
      $strtime = strtotime($row['created_at']);
      $ratingsList[] = array(
        'review_id' => $row['review_id'],
        'name' => $row['username'],
        'rating' => $row['rating'],
        'message' => $row['comment'],
        'datetime' => date('l jS \of F Y h:i:s A', $strtime)
      );
      if ($row['rating'] == '5') {
        $totalRatings5++;
      }
      if ($row['rating'] == '4') {
        $totalRatings4++;
      }
      if ($row['rating'] == '3') {
        $totalRatings3++;
      }
      if ($row['rating'] == '2') {
        $totalRatings2++;
      }
      if ($row['rating'] == '1') {
        $totalRatings1++;
      }
      $totalReviews++;
      $totalRatings_avg = $totalRatings_avg + intval($row['rating']);
    }
    $avgUserRatings = ($totalReviews > 0) ? ($totalRatings_avg / $totalReviews) : 0;

    $output = array(
      'avgUserRatings' => number_format($avgUserRatings, 1),
      'totalReviews' => $totalReviews,
      'totalRatings5' => $totalRatings5,
      'totalRatings4' => $totalRatings4,
      'totalRatings3' => $totalRatings3,
      'totalRatings2' => $totalRatings2,
      'totalRatings1' => $totalRatings1,
      'ratingsList' => $ratingsList
    );
    echo json_encode($output);
  }
}
