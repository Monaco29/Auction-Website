<?php
require_once 'bridge.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid email address.']);
        exit;
    }

    $check = mysqli_query($connect, "SELECT * FROM newsletter_subscribers WHERE email = '$email'");
    if (mysqli_num_rows($check) > 0) {
        echo json_encode(['status' => 'info', 'message' => 'You are already subscribed.']);
        exit;
    }

    $query = "INSERT INTO newsletter_subscribers (email) VALUES ('$email')";
    if (mysqli_query($connect, $query)) {
        echo json_encode(['status' => 'success', 'message' => 'Subscribed successfully!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Subscription failed. Please try again.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}
