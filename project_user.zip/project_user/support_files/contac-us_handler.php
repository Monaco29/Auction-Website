<?php
// Database connection settings
$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "project_auction";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $message = $conn->real_escape_string($_POST['message']);

    // Insert data into database
    $sql = "INSERT INTO contact_us (username, email, message) VALUES ('$name', '$email', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Query reported!');</script>";
        header("Location: ../home.php");
    } else {
        echo "<script>alert('$conn->error');</script>";
        header("Location: contact-us.htm");
    }
}

// Close connection
$conn->close();
