<?php
// Database connection
$host = 'localhost'; // Update with your database host
$dbname = 'test'; // Update with your database name
$username = 'root'; // Update with your database username
$password = ''; // Update with your database password

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $buyer_id = $_POST['buyer_id'];
    $seller_id = $_POST['seller_id'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];

    // Validation
    if (!is_numeric($buyer_id) || !is_numeric($seller_id) || !is_numeric($rating) || $rating < 1 || $rating > 5) {
        die("Invalid input data.");
    }

    try {
        // Insert review into the database
        $sql = "INSERT INTO review (buyer_id, seller_id, rating, comment, created_at) VALUES (:buyer_id, :seller_id, :rating, :comment, NOW())";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':buyer_id', $buyer_id, PDO::PARAM_INT);
        $stmt->bindParam(':seller_id', $seller_id, PDO::PARAM_INT);
        $stmt->bindParam(':rating', $rating, PDO::PARAM_INT);
        $stmt->bindParam(':comment', $comment, PDO::PARAM_STR);

        if ($stmt->execute()) {
            echo "Review submitted successfully.";
        } else {
            echo "Failed to submit the review.";
        }
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
