<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $delivery_id = $_POST['delivery_id'];
    $rating = $_POST['rating'];
    $review = $_POST['review'] ?? null;

    $stmt = $conn->prepare("INSERT INTO delivery_rating (delivery_id, rating, review) VALUES (?, ?, ?)");
    $stmt->execute([$delivery_id, $rating, $review]);

    header("Location: track_delivery.php?rated=1");
    exit();
}
