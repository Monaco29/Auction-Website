<?php
session_start();
include 'db.php';

$user_id = $_SESSION['user_id'] ?? 1;

// Determine if user is a buyer
$stmt = $conn->prepare("SELECT * FROM buyer WHERE user_id = ?");
$stmt->execute([$user_id]);
$isBuyer = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$isBuyer) {
    echo "<div class='container mt-5 alert alert-warning'>Only buyers can access delivery tracking.</div>";
    exit();
}

// Fetch delivery record
$stmt = $conn->prepare("
    SELECT dt.*, u.user_id AS buyer_name, u.email AS buyer_email
    FROM delivery_tracking dt
    JOIN buyer b ON dt.buyer_id = b.buyer_id
    JOIN user u ON b.user_id = u.user_id
    WHERE dt.buyer_id = ?
");
$stmt->execute([$isBuyer['buyer_id']]);
$delivery = $stmt->fetch(PDO::FETCH_ASSOC);

// Auto update delivery status based on estimated delivery date
if ($delivery) {
    $today = date_create(date('Y-m-d'));
    $delivery_date = date_create($delivery['estimated_delivery_date']);
    $diff = date_diff($today, $delivery_date);
    $days_left = (int) $diff->format("%R%a");

    if ($days_left <= 0) {
        $new_status = 'Delivered';
    } elseif ($days_left == 1) {
        $new_status = 'Out for Delivery';
    } elseif ($days_left == 2) {
        $new_status = 'Shipped';
    } else {
        $new_status = 'Pending';
    }

    // Update only if status changed
    if ($new_status !== $delivery['current_status']) {
        $update = $conn->prepare("UPDATE delivery_tracking SET current_status = ?, updated_at = NOW() WHERE delivery_id = ?");
        $update->execute([$new_status, $delivery['delivery_id']]);

        // Refresh the delivery object after update
        $stmt->execute([$isBuyer['buyer_id']]);
        $delivery = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

// Progress bar helper
function getProgressPercentage($status)
{
    $map = [
        'Pending' => 12,
        'Shipped' => 25,
        'Out for Delivery' => 75,
        'Delivered' => 100,
        'Cancelled' => 100
    ];
    return $map[$status] ?? 0;
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Track Your Delivery</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container my-5">
        <div class="card shadow-lg rounded-4 p-4">
            <h2 class="mb-4 text-primary">📦 Delivery Tracking</h2>

            <?php if ($delivery): ?>
                <div class="mb-3">
                    <strong>Transaction ID:</strong> <?= htmlspecialchars($delivery['transaction_id']) ?><br>
                    <strong>Estimated Delivery:</strong> <?= htmlspecialchars($delivery['estimated_delivery_date']) ?>
                </div>

                <div class="mb-3">
                    <strong>Shipping Address:</strong><br>
                    <?= nl2br(htmlspecialchars($delivery['shipping_address'])) ?>, <br>
                    <?= htmlspecialchars($delivery['city']) ?>, <?= htmlspecialchars($delivery['state']) ?> -
                    <?= htmlspecialchars($delivery['pincode']) ?>
                </div>

                <div class="mb-4">
                    <label class="form-label">Status:</label>
                    <div class="progress" style="height: 30px;">
                        <div class="progress-bar <?= ($delivery['current_status'] == 'Cancelled') ? 'bg-danger' : 'bg-success' ?>"
                            role="progressbar" style="width: <?= getProgressPercentage(($delivery['current_status'])) ?>%;"
                            aria-valuenow="<?= getProgressPercentage($delivery['current_status']) ?>" aria-valuemin="0"
                            aria-valuemax="100">
                            <?= htmlspecialchars($delivery['current_status']) ?>
                        </div>
                    </div>
                </div>

                <div class="mt-3">
                    <p><strong>Tracking Number:</strong> <?= htmlspecialchars($delivery['tracking_number']) ?></p>
                    <p><strong>Courier:</strong> <?= htmlspecialchars($delivery['courier_name']) ?></p>

                </div>

                <?php if ($delivery['current_status'] == 'Delivered'): ?>
                    <form action="submit_rating.php" method="post" class="mt-4">
                        <input type="hidden" name="delivery_id" value="<?= $delivery['delivery_id'] ?>">
                        <label for="rating" class="form-label">Rate Your Experience:</label>
                        <select name="rating" class="form-select w-50 mb-3" required>
                            <option value="">Select Rating</option>
                            <option value="5">⭐️⭐️⭐️⭐️⭐️ Excellent</option>
                            <option value="4">⭐️⭐️⭐️⭐️ Good</option>
                            <option value="3">⭐️⭐️⭐️ Average</option>
                            <option value="2">⭐️⭐️ Poor</option>
                            <option value="1">⭐️ Bad</option>
                        </select>
                        <textarea name="review" class="form-control mb-3" rows="3"
                            placeholder="Leave a review (optional)"></textarea>
                        <button type="submit" class="btn btn-warning">Submit Rating</button>
                    </form>
                <?php endif; ?>

            <?php else: ?>
                <div class="alert alert-info">No delivery record found for your account.</div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>