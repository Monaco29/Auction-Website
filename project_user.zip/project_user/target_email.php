<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        .wrapper
        {
            background-color: #106fde;
            width: 100%;
            height: 100vh;
            padding: 15px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container
        {
            width: 500px;
            background-color: #fff;
            padding: 30px;
            border-radius: 16px;
            background-color: rgba(0,0,0,0.08) 0px 4px 12px;
        }
        .title-section
        {
            margin-bottom: 30px;
        }
        .title
        {
            color: #38475a;
            font-size: 25px;
            font-weight: 500;
            text-transform: capitalize;
            margin-bottom: 10px;
        }
        .para
        {
            color: #38475a;
            font-size: 16px;
            font-weight: 400;
            line-height: 1.5;
            margin-bottom: 20px;
            text-transform: capitalize;
        }
        .input-group
        {
            position: relative;
        }
        .input-group .label-title
        {
            color : #38475a;
            text-transform: capitalize;
            margin-bottom: 11px;
            font-size: 14px;
            display: block;
            font-weight: 500;
        }
        .input-group input
        {
            width: 100%;
            background-color: none;
            color:  #38475a;
            height: 50px;
            font-size: 16px;
            font-weight: 300;
            border: 1px solid #EAECF0;
            padding: 9px 18px 9px 52px;
            outline: none;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .input-group input::placeholder
        {
            color: #38475a;
            font-size: 16px;
            font-weight: 400;
        }
        .input-group .icon
        {
            position: absolute;
            color: #38475a;
            left: 13px;
            top: calc(50% - 11px);
            text-align: center;
            font-size: 23px;
        }
        .submit-btn
        {
            width: 100%;
            background-color: #106fde;
            border: 1px solid transparent;
            border-radius: 8px;
            font-size: 16px;
            color: #fff;
            padding: 13px 24px;
            font-weight: 500;
            text-align: center;
            text-transform: capitalize;
            cursor: pointer;
        }
        .submit-btn:hover
        {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="title-section">
                <h2 class="title">Reset Password</h2>
                <p class="para">Enter your email address and we will send you the link. Please check and verify if your mail before account create you have a link inbox. Click on link and reset your password..😊</p>
            </div>
            <form action="send_email.php" class="form" method="POST">
                <div class="input-group">
                    <label for="receiver" class="label-title">Enter your Email</label>
                    <input type="email" name="email" id="receiver" placeholder="Enter your email">
                    <span class="icon">&#9993;</span>
                </div>
                <div class="input-group">
                    <button class="submit-btn" type="submit">Send</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>