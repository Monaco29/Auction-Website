<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 250px;
            background-color: #343a40;
            padding-top: 20px;
            transition: all 0.3s;
        }
        .sidebar a {
            color: white;
            display: flex;
            align-items: center;
            padding: 10px 15px;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .sidebar a:hover {
            background-color: #007bff;
        }
        .sidebar a i {
            margin-right: 10px;
        }
        .sidebar .active {
            background-color: #007bff;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
            transition: all 0.3s;
        }
        .card {
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.05);
        }
        .card-body {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 20px;
            border-radius: 15px;
        }
        .manage-items-card {
            background: linear-gradient(135deg, #ff758c 0%, #ff7eb3 100%);
            color: white;
        }
        .wallet-card {
            background: linear-gradient(135deg, #43cea2 0%, #185a9d 100%);
            color: white;
        }
        .row.equal {
            display: flex;
            flex-wrap: wrap;
        }
        .row.equal > [class*='col-'] {
            display: flex;
            flex-direction: column;
            padding: 10px;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <?php
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header('Location: user_authentication.php');
            exit();
        }
        $user_id = $_SESSION['user_id'];
        include 'bridge.php';
    ?>
    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-3 col-lg-2 sidebar">
                <h3 class="text-center text-white">User Dashboard</h3>
                <a href="#" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                <a href="add_item.php"><i class="fas fa-box-open"></i> Add Item</a>
                <a href="manage_items.php"><i class="fas fa-edit"></i> Manage Items</a>
                <a href="wallet.php"><i class="fas fa-wallet"></i> Wallet</a>
                <a href="user_details.php"><i class="fas fa-user"></i> User Details</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>
            <main class="col-md-9 col-lg-10 content">
                <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
                <p>Here you can manage your auction items, view your wallet, and more.</p>
                <div class="row equal">
                    <div class="col-md-6">
                        <div class="card manage-items-card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-box-open"></i> Manage Items</h5>
                                <p class="card-text">Manage your auction items here.</p>
                                <a href="manage_items.php" class="btn btn-light mt-auto">Go to Manage Items</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card wallet-card">
                            <div class="card-body">
                                <h5 class="card-title"><i class="fas fa-wallet"></i> Wallet</h5>
                                <p class="card-text"><strong>Balance:</strong> $<?php echo $_SESSION['wallet_balance']; ?></p>
                                <a href="wallet.php" class="btn btn-light mt-auto">View Transactions</a>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
