<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            padding: 20px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .card-body {
            padding: 20px;
        }
    </style>
</head>
<body>
    <?php
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header('Location: login.php');
            exit();
        }
        $user_id = $_SESSION['user_id'];
        include 'bridge.php';

        // Fetch user details
        $user_sql = "SELECT username, email, profile_pic FROM user WHERE user_id = $user_id";
        $user_result = mysqli_query($connect, $user_sql);
        $user = mysqli_fetch_assoc($user_result);
    ?>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><i class="fas fa-user"></i> User Details</h5>
                <p class="card-text"><strong>Username:</strong> <?php echo $user['username']; ?></p>
                <p class="card-text"><strong>Email:</strong> <?php echo $user['email']; ?></p>
                <img src="../final_sem_project/uploaded_images/<? echo $user['profile_pic']; ?>" alt="Profile Picture" class="img-thumbnail">
            </div>
        </div>
    </div>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
