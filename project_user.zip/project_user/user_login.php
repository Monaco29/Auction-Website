<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LogIn</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Noto+Sans:wght@700&family=Poppins:wght@400;500;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(120deg, #2980b9, #8e44ad);
            height: 100vh;
            overflow: hidden;
        }

        .center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 400px;
            background: white;
            border-radius: 10px;
            box-shadow: 10px 10px 15px rgba(0, 0, 0, 0.05);
        }

        .center h1 {
            text-align: center;
            padding: 20px 0;
            border-bottom: 1px solid silver;
        }

        .center form {
            padding: 0 40px;
            box-sizing: border-box;
        }

        form .txt_field {
            position: relative;
            border-bottom: 2px solid #adadad;
            margin: 30px 0;
        }

        .txt_field input {
            width: 100%;
            padding: 0 5px;
            height: 40px;
            font-size: 16px;
            border: none;
            background: none;
            outline: none;
        }

        .txt_field label {
            position: absolute;
            top: 50%;
            left: 5px;
            color: #adadad;
            transform: translateY(-50%);
            font-size: 16px;
            pointer-events: none;
            transition: .5s;
        }

        .txt_field span::before {
            content: '';
            position: absolute;
            top: 40px;
            left: 0;
            width: 0%;
            height: 2px;
            background: #2691d9;
            transition: .5s;
        }

        .txt_field input:focus~label,
        .txt_field input:valid~label {
            top: -5px;
            color: #2691d9;
        }

        .txt_field input:focus~span::before,
        .txt_field input:valid~span::before {
            width: 100%;
        }

        .txt_field .show-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #adadad;
        }

        .txt_field .show-password:hover {
            color: #2691d9;
        }

        input[type="submit"] {
            width: 100%;
            height: 50px;
            border: 1px solid;
            background: #2691d9;
            border-radius: 25px;
            font-size: 18px;
            color: #e9f4fb;
            font-weight: 700;
            cursor: pointer;
            outline: none;
        }

        input[type="submit"]:hover {
            border-color: #2691d9;
            transition: .5s;
        }

        .signup_link {
            margin: 30px 0;
            text-align: center;
            font-size: 16px;
            color: #666666;
        }

        .signup_link a {
            color: #2691d9;
            text-decoration: none;
        }

        .signup_link a:hover {
            text-decoration: underline;
        }

        .pass {
            font-size: 16px;
            color: #666666;
        }

        .pass a {
            color: #2691d9;
            text-decoration: none;
        }

        .pass a:hover {
            text-decoration: underline;
        }

        /* Add styles for radio buttons and animation */
        .role {
            margin: 20px 0;
            text-align: center;
        }

        .role label {
            font-size: 16px;
            color: #666666;
            margin-right: 10px;
        }

        .role input[type="radio"] {
            display: none;
        }

        .role input[type="radio"]+label {
            padding: 10px 20px;
            border: 1px solid #adadad;
            border-radius: 20px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }

        .role input[type="radio"]:checked+label {
            background-color: #2691d9;
            color: #ffffff;
            transform: scale(1.1);
        }
    </style>
</head>

<body>
    <div class="center">
        <h1>Login</h1>
        <form action="logged_in.php" method="post">
            <div class="txt_field">
                <input type="email" name="email" required>
                <span></span>
                <label>Email</label>
            </div>
            <div class="txt_field">
                <input type="password" name="password" id="password" required>
                <span></span>
                <span class="show-password" onclick="togglePassword()">👁️</span>
                <label>Password</label>
            </div>
            <div class="role">
                <input type="radio" id="buyer" name="role" value="Buyer" required>
                <label for="buyer">Buyer</label>
                <input type="radio" id="seller" name="role" value="Seller" required>
                <label for="seller">Seller</label>
            </div>
            <div class="pass">
                Not remembered? <a href="target_email.php">Forgot Password</a>
            </div>
            <input type="submit" value="Login">
            <div class="signup_link">
                Not a member? <a href="user_registration.php">Signup</a>
            </div>
        </form>
    </div>

    <script>

        function togglePassword() {
            var passwordField = document.getElementById("password");
            var showPasswordIcon = document.querySelector(".show-password");
            if (passwordField.type === "password") {
                passwordField.type = "text";
                showPasswordIcon.textContent = "🙈";
            } else {
                passwordField.type = "password";
                showPasswordIcon.textContent = "👁️";
            }
        }
    </script>
</body>

</html>