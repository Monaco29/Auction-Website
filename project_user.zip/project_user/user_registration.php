<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration Form | CodingLab</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px;
            background: linear-gradient(135deg, #71b7e6, #9b59b6);
        }

        .container {
            max-width: 700px;
            width: 100%;
            background-color: #fff;
            padding: 25px 30px;
            border-radius: 5px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.15);
        }

        .container .title {
            font-size: 25px;
            font-weight: 500;
            position: relative;
        }

        .container .title::before {
            content: "";
            position: absolute;
            left: 0;
            bottom: 0;
            height: 3px;
            width: 30px;
            border-radius: 5px;
            background: linear-gradient(135deg, #71b7e6, #9b59b6);
        }

        .content form .user-details {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin: 20px 0 12px 0;
        }

        form .user-details .input-box {
            margin-bottom: 15px;
            width: calc(100% / 2 - 20px);
        }

        form .input-box span.details {
            display: block;
            font-weight: 500;
            margin-bottom: 5px;
        }

        .user-details .input-box input {
            height: 45px;
            width: 100%;
            outline: none;
            font-size: 16px;
            border-radius: 5px;
            padding-left: 15px;
            border: 1px solid #ccc;
            border-bottom-width: 2px;
            transition: all 0.3s ease;
        }

        .user-details .input-box input:focus,
        .user-details .input-box input:valid {
            border-color: #9b59b6;
        }

        .user-details .input-box input.inactive {
            background-color: #f0f0f0;
            cursor: not-allowed;
        }

        form .gender-details .gender-title {
            font-size: 20px;
            font-weight: 500;
        }

        form .category {
            display: flex;
            width: 80%;
            margin: 14px 0;
            justify-content: space-between;
        }

        form .category label {
            display: flex;
            align-items: center;
            cursor: pointer;
        }

        form .category label .dot {
            height: 18px;
            width: 18px;
            border-radius: 50%;
            margin-right: 10px;
            background: #d9d9d9;
            border: 5px solid transparent;
            transition: all 0.3s ease;
        }

        #dot-1:checked~.category label .one,
        #dot-2:checked~.category label .two {
            background: #9b59b6;
            border-color: #d9d9d9;
        }

        form input[type="radio"] {
            display: none;
        }

        form .button {
            height: 45px;
            margin: 35px 0
        }

        form .button input {
            height: 100%;
            width: 100%;
            border-radius: 5px;
            border: none;
            color: #fff;
            font-size: 18px;
            font-weight: 500;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, #71b7e6, #9b59b6);
        }

        form .button input:hover {
            background: linear-gradient(-135deg, #71b7e6, #9b59b6);
        }

        @media(max-width: 584px) {
            .container {
                max-width: 100%;
            }

            form .user-details .input-box {
                margin-bottom: 15px;
                width: 100%;
            }

            form .category {
                width: 100%;
            }

            .content form .user-details {
                max-height: 300px;
                overflow-y: scroll;
            }

            .user-details::-webkit-scrollbar {
                width: 5px;
            }
        }

        @media(max-width: 459px) {
            .container .content .category {
                flex-direction: column;
            }
        }
    </style>
    <script>
        function toggleBusinessFields() {
            const buyerRadio = document.getElementById('dot-1');
            const sellerRadio = document.getElementById('dot-2');
            const businessFields = document.querySelectorAll('.business-field');

            if (buyerRadio.checked) {
                businessFields.forEach(field => {
                    field.disabled = true;
                    field.classList.add('inactive');
                    field.value = "";
                });
            } else if (sellerRadio.checked) {
                businessFields.forEach(field => {
                    field.disabled = false;
                    field.classList.remove('inactive');
                });
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            const roleRadios = document.querySelectorAll('input[name="role"]');
            roleRadios.forEach(radio => {
                radio.addEventListener('change', toggleBusinessFields);
            });
            toggleBusinessFields();
        });
    </script>
</head>

<body>
    <div class="container">
        <div class="title">Register your self</div>
        <div class="content">
            <form action="get_registered.php" method="POST" enctype="multipart/form-data">
                <div class="user-details">
                    <div class="input-box">
                        <span class="details">Username</span>
                        <input type="text" placeholder="Enter your username" name="username" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Email</span>
                        <input type="email" placeholder="Enter your email" name="email" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Password</span>
                        <input type="password" placeholder="Enter your password" name="password" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Address</span>
                        <input type="text" placeholder="Enter your address" name="address" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Profile Picture</span>
                        <input type="file" name="profile_pic" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Business Name</span>
                        <input type="text" placeholder="Enter your business name" name="business_name"
                            class="business-field" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Business Address</span>
                        <input type="text" placeholder="Enter your business address" name="business_address"
                            class="business-field" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Business Email</span>
                        <input type="email" placeholder="Enter your business email" name="business_email"
                            class="business-field" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Contact Number</span>
                        <input type="text" placeholder="Enter your contact number" name="contect_number" required>
                    </div>
                    <div class="input-box">
                        <span class="details">City</span>
                        <input type="text" placeholder="Enter your city" name="city" required>
                    </div>
                    <div class="input-box">
                        <span class="details">State</span>
                        <input type="text" placeholder="Enter your state" name="state" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Pincode</span>
                        <input type="text" placeholder="Enter your pincode" name="pincode" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Country</span>
                        <input type="text" placeholder="Enter your country" name="country" value="India" required>
                    </div>
                </div>
                <div class="gender-details">
                    <input type="radio" name="role" id="dot-1" value="Buyer">
                    <input type="radio" name="role" id="dot-2" value="Seller">
                    <span class="gender-title">Role</span>
                    <div class="category">
                        <label for="dot-1">
                            <span class="dot one"></span>
                            <span class="gender">Buyer</span>
                        </label>
                        <label for="dot-2">
                            <span class="dot two"></span>
                            <span class="gender">Seller</span>
                        </label>
                    </div>
                </div>
                <div class="button">
                    <input type="submit" value="Register">
                </div>
            </form>
        </div>
    </div>
    <script>
        document.querySelector("form").addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent form submission for validation

            // Input elements
            const username = document.querySelector("input[name='username']").value.trim();
            const email = document.querySelector("input[name='email']").value.trim();
            const password = document.querySelector("input[name='password']").value.trim();
            const address = document.querySelector("input[name='address']").value.trim();
            const profilePic = document.querySelector("input[name='profile_pic']").files[0];
            const businessName = document.querySelector("input[name='business_name']").value.trim();
            const businessAddress = document.querySelector("input[name='business_address']").value.trim();
            const businessEmail = document.querySelector("input[name='business_email']").value.trim();
            const contactNumber = document.querySelector("input[name='contect_number']").value.trim();
            const city = document.querySelector("input[name='city']").value.trim();
            const state = document.querySelector("input[name='state']").value.trim();
            const pincode = document.querySelector("input[name='pincode']").value.trim();
            const country = document.querySelector("input[name='country']").value.trim();
            const roleBuyer = document.getElementById("dot-1").checked;
            const roleSeller = document.getElementById("dot-2").checked;

            // Validation errors
            let errors = [];

            // Username validation
            if (username === "") {
                errors.push("Username is required.");
            }

            // Email validation
            if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
                errors.push("Invalid email format.");
            }

            // Password validation
            if (password.length < 3) {
                errors.push("Password must be at least 8 characters long.");
            }

            // Address validation
            if (address === "") {
                errors.push("Address is required.");
            }

            // Profile picture validation
            if (!profilePic) {
                errors.push("Profile picture is required.");
            }

            // Contact number validation
            if (!contactNumber.match(/^\d{10}$/)) {
                errors.push("Contact number must be 10 digits.");
            }

            // City validation
            if (city === "") {
                errors.push("City is required.");
            }

            // State validation
            if (state === "") {
                errors.push("State is required.");
            }

            // Pincode validation
            if (!pincode.match(/^\d{6}$/)) {
                errors.push("Pincode must be 6 digits.");
            }

            // Country validation
            if (country === "") {
                errors.push("Country is required.");
            }

            // Role validation
            if (!roleBuyer && !roleSeller) {
                errors.push("Please select a role.");
            }

            // Display errors or submit form
            if (errors.length > 0) {
                alert(errors.join("\n"));
            } else {
                alert("User Registered successfully!");
                event.target.submit(); // Proceed with the form submission
            }
        });

    </script>
</body>

</html>